from feathersdk.robot.comms import CommsManagerConfig


comms_manager_config = CommsManagerConfig(
    teensy_ip="192.168.10.2",
    teensy_port=6613,
    teensy_operating_frequency=100.0,
    teensy_telemetry_update_frequency=100.0,
    max_can_rate=3500.0,
    can_leniency=100.0,
    server_run_time_nanos=100_000,
    can_read_run_time_nanos=100_000,
    result_operating_frequency=200.0,
    use_emulated_teensy=True,
)
