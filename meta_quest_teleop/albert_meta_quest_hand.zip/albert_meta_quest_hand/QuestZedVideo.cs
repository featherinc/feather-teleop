using System;
using System.Diagnostics;
using System.IO;
using System.Net.Sockets;
using System.Threading;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Serialization;
using UnityEngine.XR;
using Debug = UnityEngine.Debug;

/// <summary>Optional stereo video on TCP 5006. Does not change pose UDP or A/B control.</summary>
public sealed class QuestZedVideo : MonoBehaviour
{
    public int videoPort = 5006;
    [Tooltip("Click the right thumbstick to switch between 3D and comfortable 2D.")]
    [FormerlySerializedAs("stereoDepth")]
    public bool stereoVideo = true;
    private volatile float viewerIpd = 0f;
    private bool nativeStereoFrame;
    private double modeMessageUntil;
    private float[] projection;
    private float[] displayProjection;
    private Material projectionMaterial;
    private readonly RenderTexture[,] projected = new RenderTexture[2, 2];
    private readonly IntPtr[,] projectedPointers = new IntPtr[2, 2];
    private const int HeaderBytes = 24, MaxJpegBytes = 1048576;
    private const double StaleSeconds = 0.5;
    private readonly object frameLock = new object();
    private CancellationTokenSource cancellation;
    private Thread receiver;
    private Frame pending;
    private Record_CSV_BLE_NEW sender;
    private OVROverlay overlay;
    private GameObject screen, labelObject;
    private Text label;
    private readonly Texture2D[,] textures = new Texture2D[2, 2];
    private int buffer;
    private double expires;
    private bool everReceived, testPattern, teleopPaused = true;
    private static double Now => Stopwatch.GetTimestamp() / (double)Stopwatch.Frequency;

    private sealed class Frame
    {
        public byte[] left, right;
        public double expires;
        public bool testPattern;
        public bool paused;
        public bool nativeStereo;
        public float[] projection;
    }

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void Attach()
    {
        var source = UnityEngine.Object.FindFirstObjectByType<Record_CSV_BLE_NEW>();
        if (source != null && source.GetComponent<QuestZedVideo>() == null)
            source.gameObject.AddComponent<QuestZedVideo>();
    }

    private void OnEnable()
    {
        sender = GetComponent<Record_CSV_BLE_NEW>();
        if (!Application.isEditor && sender != null) StartReceiver();
    }

    private void StartReceiver()
    {
        if (cancellation != null) return;
        cancellation = new CancellationTokenSource();
        var token = cancellation.Token;
        string host = sender.receiverAddress;
        int port = videoPort;
        receiver = new Thread(() => Receive(host, port, token)) { IsBackground = true, Name = "Quest ZED video" };
        receiver.Start();
    }

    private static byte[] ReadExact(Stream stream, int count)
    {
        byte[] bytes = new byte[count];
        int offset = 0;
        while (offset < count)
        {
            int read = stream.Read(bytes, offset, count - offset);
            if (read == 0) throw new EndOfStreamException("Video connection closed");
            offset += read;
        }
        return bytes;
    }

    private void Receive(string host, int port, CancellationToken token)
    {
        bool nativeProtocol = true;
        while (!token.IsCancellationRequested)
        {
            try
            {
                using (var client = new TcpClient())
                using (token.Register(client.Close))
                {
                    client.NoDelay = true;
                    client.ReceiveTimeout = client.SendTimeout = 1000;
                    var connect = client.BeginConnect(host, port, null, null);
                    using (var ready = connect.AsyncWaitHandle)
                        if (WaitHandle.WaitAny(new[] { token.WaitHandle, ready }, 2000) != 1)
                            throw new IOException("Video connection unavailable");
                    client.EndConnect(connect);
                    using (var stream = client.GetStream())
                    {
                        uint sequence = 0;
                        while (!token.IsCancellationRequested)
                        {
                            double requested = Now;
                            byte[] request;
                            if (nativeProtocol)
                            {
                                request = new byte[8];
                                request[0] = (byte)'Q'; request[1] = (byte)'V';
                                request[2] = (byte)'R'; request[3] = (byte)'3';
                                Buffer.BlockCopy(BitConverter.GetBytes(sequence), 0, request, 4, 4);
                            }
                            else request = BitConverter.GetBytes(sequence);
                            stream.Write(request, 0, request.Length);
                            byte[] header = ReadExact(stream, HeaderBytes);
                            if (header[0] != 'Q' || header[1] != 'V' || header[2] != 'I' || header[3] != 'D'
                                || (header[4] != 1 && header[4] != 3))
                                throw new IOException("Invalid video header");
                            if (nativeProtocol && header[4] == 1)
                            {
                                nativeProtocol = false;
                                Debug.Log("QVID older video server: reconnecting in 2D mode.");
                                throw new IOException("Retry legacy video protocol");
                            }
                            int expectedHeader = header[4] == 3 ? 52 : HeaderBytes;
                            if (BitConverter.ToUInt16(header, 6) != expectedHeader)
                                throw new IOException("Invalid video header length");
                            float[] calibration = null;
                            if (header[4] == 3)
                            {
                                byte[] extra = ReadExact(stream, 28);
                                calibration = new float[7];
                                for (int i = 0; i < calibration.Length; i++)
                                    calibration[i] = BitConverter.ToSingle(extra, 4 * i);
                            }
                            bool nativeStereo = header[4] == 3 && (header[5] & 0x40) == 0
                                && ValidCameraProjection(calibration);
                            byte status = (byte)(header[5] & 0x3f);
                            uint seq = BitConverter.ToUInt32(header, 8);
                            float ageMs = BitConverter.ToSingle(header, 12);
                            uint leftBytes = BitConverter.ToUInt32(header, 16), rightBytes = BitConverter.ToUInt32(header, 20);
                            if (status > 3 || float.IsNaN(ageMs) || float.IsInfinity(ageMs) || ageMs < 0
                                || leftBytes > MaxJpegBytes || rightBytes > MaxJpegBytes
                                || (status != 0 && (leftBytes != 0 || rightBytes != 0))
                                || (status == 0 && (leftBytes == 0 || rightBytes == 0)))
                                throw new IOException("Invalid video lengths/status");
                            if (status == 0)
                            {
                                byte[] left = ReadExact(stream, (int)leftBytes), right = ReadExact(stream, (int)rightBytes);
                                sequence = seq;
                                // Server capture age plus the whole request RTT is a conservative age bound.
                                double deadline = requested + StaleSeconds - ageMs / 1000.0;
                                if (Now < deadline)
                                    lock (frameLock)
                                        if (!token.IsCancellationRequested)
                                            pending = new Frame { left = left, right = right, expires = deadline,
                                                testPattern = (header[5] & 0x80) != 0, nativeStereo = nativeStereo, projection = calibration };
                            }
                            else if (status == 1)
                            {
                                lock (frameLock)
                                    if (!token.IsCancellationRequested) pending = new Frame { expires = 0 };
                            }
                            else if (status == 3)
                            {
                                // READY/HOMING/STOPPED: restore the existing passthrough view.
                                sequence = 0;
                                lock (frameLock)
                                    if (!token.IsCancellationRequested) pending = new Frame { expires = 0, paused = true };
                            }
                            if (token.WaitHandle.WaitOne(2)) break;
                        }
                    }
                }
            }
            catch (Exception error) when (error is IOException || error is SocketException || error is ObjectDisposedException)
            {
                lock (frameLock)
                    if (!token.IsCancellationRequested) pending = new Frame { expires = 0 };
                if (token.WaitHandle.WaitOne(1000)) break;
            }
        }
    }

    private void CreateScreen()
    {
        screen = new GameObject("ZED native stereo video");
        screen.SetActive(false);
        screen.transform.SetParent(sender.mainCamera, false);
        screen.transform.localPosition = new Vector3(0, 0, 1.5f);
        screen.transform.localScale = new Vector3(2.4f, 1.35f, 1);
        overlay = screen.AddComponent<OVROverlay>();
        overlay.currentOverlayType = OVROverlay.OverlayType.Overlay;
        overlay.currentOverlayShape = OVROverlay.OverlayShape.Quad;
        overlay.isDynamic = true;
        Shader shader = Resources.Load<Shader>("QuestStereoProjection");
        if (shader == null) throw new IOException("Calibrated video shader is missing");
        projectionMaterial = new Material(shader);
        for (int i = 0; i < 2; i++)
            for (int eye = 0; eye < 2; eye++)
            {
                textures[i, eye] = new Texture2D(640, 360, TextureFormat.RGB24, false)
                    { wrapMode = TextureWrapMode.Clamp, filterMode = FilterMode.Bilinear };
                projected[i, eye] = new RenderTexture(640, 360, 0, RenderTextureFormat.ARGB32)
                    { wrapMode = TextureWrapMode.Clamp, filterMode = FilterMode.Bilinear };
                projected[i, eye].Create();
                projectedPointers[i, eye] = projected[i, eye].GetNativeTexturePtr();
            }

        labelObject = new GameObject("ZED video status", typeof(RectTransform), typeof(Canvas));
        labelObject.transform.SetParent(sender.mainCamera, false);
        labelObject.transform.localPosition = new Vector3(0, -0.6f, 1.5f);
        labelObject.transform.localScale = Vector3.one * .002f;
        labelObject.GetComponent<Canvas>().renderMode = RenderMode.WorldSpace;
        var textObject = new GameObject("Message", typeof(RectTransform), typeof(Text));
        textObject.transform.SetParent(labelObject.transform, false);
        textObject.GetComponent<RectTransform>().sizeDelta = new Vector2(1100, 80);
        label = textObject.GetComponent<Text>();
        label.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        label.fontSize = 28;
        label.alignment = TextAnchor.MiddleCenter;
        label.color = Color.yellow;
        label.text = "ZED video lost — check the camera connection";
        labelObject.SetActive(false);
    }

    private void LateUpdate()
    {
        if (sender == null || sender.mainCamera == null || cancellation == null) return;
        float ipd = OVRPlugin.ipd;
        if (Finite(ipd) && ipd >= .05f && ipd <= .085f) viewerIpd = ipd;
        if (OVRInput.GetDown(OVRInput.Button.SecondaryThumbstick))
        {
            stereoVideo = !stereoVideo;
            modeMessageUntil = Now + 3;
            if (screen != null && everReceived) Present(buffer);
        }
        Frame frame;
        lock (frameLock) { frame = pending; pending = null; }
        if (frame != null)
        {
            teleopPaused = frame.paused;
            expires = frame.expires;
            if (frame.left != null && Now < expires)
            {
                if (screen == null) CreateScreen();
                int next = 1 - buffer;
                try
                {
                    var left = textures[next, 0]; var right = textures[next, 1];
                    bool loaded = left.LoadImage(frame.left, false) && right.LoadImage(frame.right, false);
                    if (!loaded || left.width != 640 || left.height != 360 || right.width != 640 || right.height != 360)
                        throw new IOException("Invalid stereo image");
                    if (nativeStereoFrame != frame.nativeStereo)
                        Debug.Log("QVID source changed: nativeStereo=" + frame.nativeStereo
                            + ", IPD=" + viewerIpd);
                    nativeStereoFrame = frame.nativeStereo;
                    projection = frame.projection;
                    if (ValidCameraProjection(projection)) displayProjection = projection;
                    Present(next);
                    buffer = next;
                    if (!everReceived) Debug.Log("QVID video received; nativeStereo=" + nativeStereoFrame
                        + ", IPD=" + viewerIpd + ", 640x360 per eye. Pose UDP unchanged.");
                    everReceived = true;
                    testPattern = frame.testPattern;
                }
                catch (Exception error)
                {
                    expires = 0;
                    Debug.LogWarning("QVID image rejected: " + error.Message);
                }
            }
        }
        bool requested = sender.VideoRequested;
        bool fresh = requested && !teleopPaused && Now < expires;
        if (screen != null) screen.SetActive(fresh);
        if (labelObject != null)
        {
            bool usingStereo = stereoVideo && nativeStereoFrame && ValidCameraProjection(projection);
            label.text = !fresh ? "ZED video lost — check the camera connection"
                : testPattern ? "TEST PATTERN — no camera image"
                : usingStereo ? "3D view — click right stick for 2D"
                : stereoVideo ? "2D view — update the video server for native stereo"
                : "2D view — click right stick for 3D";
            labelObject.SetActive(requested && !teleopPaused && everReceived
                && (!fresh || testPattern || !usingStereo || Now < modeMessageUntil));
        }
    }

    private static bool Finite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);

    public static bool ValidCameraProjection(float[] p)
    {
        if (p == null || p.Length != 7) return false;
        for (int i = 0; i < 4; i++) if (!Finite(p[i])) return false;
        return p[0] >= 100 && p[0] <= 2000 && p[1] >= 100 && p[1] <= 2000
            && p[2] >= 0 && p[2] <= 640 && p[3] >= 0 && p[3] <= 360;
    }

    // Display FOV belongs to the camera, independent of depth validity or 2D/3D mode.
    public static Vector3 DisplayScale(float[] p, float distance)
        => ValidCameraProjection(p)
            ? new Vector3(distance * 640f / p[0], distance * 360f / p[1], 1)
            : new Vector3(2.4f, 1.35f, 1);

    // Convert the camera's calibrated pixel rays to this overlay's per-eye rays.
    // The horizontal correction removes convergence added by a head-centred quad.
    public static Vector2 ProjectionOffset(float[] p, float eyeX, float distance)
        => new Vector2(p[2] / 640f - .5f - eyeX * p[0] / (distance * 640f),
                       .5f - p[3] / 360f);

    private void Present(int next)
    {
        bool stereo = stereoVideo && nativeStereoFrame && ValidCameraProjection(projection);
        const float distance = 1.5f;
        screen.transform.localScale = DisplayScale(displayProjection, distance);
        for (int eye = 0; eye < 2; eye++)
        {
            Vector2 offset = ValidCameraProjection(displayProjection)
                ? ProjectionOffset(displayProjection,
                    stereo ? (eye == 0 ? -.5f : .5f) * viewerIpd : 0f, distance)
                : Vector2.zero;
            projectionMaterial.SetVector("_UvOffset", new Vector4(offset.x, offset.y, 0, 0));
            Graphics.Blit(textures[next, stereo ? eye : 0], projected[next, eye], projectionMaterial);
            overlay.OverrideOverlayTextureInfo(projected[next, eye], projectedPointers[next, eye],
                eye == 0 ? XRNode.LeftEye : XRNode.RightEye);
        }
    }

    private void StopReceiver()
    {
        if (cancellation == null) return;
        cancellation.Cancel();
        // Closing the registered socket unblocks I/O. Do not stall the Unity main thread.
        if (receiver == null || receiver.Join(100)) cancellation.Dispose();
        cancellation = null;
        lock (frameLock) pending = null;
        expires = 0;
        if (screen != null) screen.SetActive(false);
        if (labelObject != null) labelObject.SetActive(false);
    }

    private void OnApplicationPause(bool paused)
    {
        if (paused) StopReceiver();
        else if (isActiveAndEnabled && sender != null && !Application.isEditor) StartReceiver();
    }
    private void OnDisable() => StopReceiver();
    private void OnDestroy()
    {
        StopReceiver();
        if (screen != null) Destroy(screen);
        if (labelObject != null) Destroy(labelObject);
        foreach (Texture2D texture in textures) if (texture != null) Destroy(texture);
        foreach (RenderTexture texture in projected)
            if (texture != null) { texture.Release(); Destroy(texture); }
        if (projectionMaterial != null) Destroy(projectionMaterial);
    }
}
