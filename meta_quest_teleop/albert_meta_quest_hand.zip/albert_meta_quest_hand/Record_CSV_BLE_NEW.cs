using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using UnityEngine;
using UnityEngine.XR;
using Debug = UnityEngine.Debug;

/// <summary>Pose telemetry only. Never sends robot, BLE, CAN, or haptic commands.</summary>
public sealed class Record_CSV_BLE_NEW : MonoBehaviour
{
    [Header("Head tracking reference (existing CenterEyeAnchor)")]
    public Transform mainCamera;
    [Header("AGX pose-only UDP") ]
    public string receiverAddress = "10.42.0.1";
    public int receiverPort = 5005;
    private const int sendHz = 30;
    public bool streamInEditor = false;

    // QPOS v9: A start/stop toggle, Y/B whole-hand/pinch counters plus recenter epoch; left stick translates; right stick X rotates the base and Y moves the torso.
    private const uint Magic = 0x534F5051;
    private const byte ProtocolVersion = 9;
    private const int HeaderSize = 28, PoseSize = 320, PongSize = 44, StatusSize = 40;
    private UdpClient socket;
    private IPEndPoint remote;
    private ulong session;
    private uint sequence, pingSequence;
    private uint calibrationId, recenterId;
    private OVRDisplay recenterDisplay;
    private bool recenterPending, recenterRequiresStop;
    private int recenterFrame;
    // Keep the wire field bPressId for compatibility: v9 increments it on A STOP, never on B.
    private uint aPressId, bPressId;
    private bool stopAwaitingReady, needsHome, haveStatus;
    private uint lastStatusSequence;
    private uint leftSelectPress, rightSelectPress;
    // Local voice prompts only: the AGX keeps receiving the same Y/B mode counters.
    private static readonly string[] FingerNames = {
        "whole_hand", "pinch"
    };
    private readonly int[] fingerSelection = new int[2];
    private readonly bool[] selectionPending = new bool[2];
    private readonly AudioClip[,] selectionClips = new AudioClip[2, 2];
    private AudioSource selectionVoice;
    private int speakingSide = -1;
    private bool runRequested;
    // Video also requires the AGX RUNNING heartbeat; A-stop/recenter hide it immediately here.
    public bool VideoRequested => isActiveAndEnabled && !paused && runRequested
        && !recenterPending && !recenterRequiresStop;
    private PoseFrame calibration;
    private double pingSent = -1;
    private double nextPose, nextPing, lastSync = -1, rtt = -1, offset;
    private double bestRtt = double.PositiveInfinity, syncWindow;
    private bool paused;
#if UNITY_ANDROID && !UNITY_EDITOR
    private AndroidJavaObject wifiLock;
#endif
    private double nextErrorLog;
    private static double Now => Stopwatch.GetTimestamp() / (double)Stopwatch.Frequency;

    private void OnEnable()
    {
        if (Application.isEditor && !streamInEditor) return;
        PrepareSelectionAudio();
        try
        {
            remote = new IPEndPoint(IPAddress.Parse(receiverAddress), receiverPort);
            socket = new UdpClient(AddressFamily.InterNetwork);
            socket.Connect(remote);
            socket.Client.Blocking = false;
            ResetSession();
            SetLowLatencyWifi(true);
            Debug.Log($"QPOS pose-only: {receiverAddress}:{receiverPort}, {sendHz} Hz, ROS FLU, xyzw. No motor commands.");
        }
        catch (Exception e)
        {
            Debug.LogError("QPOS socket setup failed: " + e.Message);
            CloseSocket();
        }
    }

    private void ResetSession()
    {
        session = BitConverter.ToUInt64(Guid.NewGuid().ToByteArray(), 0);
        sequence = pingSequence = 0;
        calibrationId = recenterId = 0;
        recenterPending = recenterRequiresStop = false;
        aPressId = bPressId = leftSelectPress = rightSelectPress = 0;
        ResetSelectionAudio();
        runRequested = false;
        stopAwaitingReady = needsHome = haveStatus = false;
        calibration = new PoseFrame { hRot = Quaternion.identity, lRot = Quaternion.identity, rRot = Quaternion.identity };
        pingSent = -1;
        rtt = lastSync = -1;
        bestRtt = double.PositiveInfinity;
        nextPose = nextPing = syncWindow = Now;
    }

    private void OnApplicationPause(bool value)
    {
        paused = value;
        if (value) ResetSelectionAudio();
        SetLowLatencyWifi(!value && socket != null && isActiveAndEnabled);
        if (!value && socket != null) ResetSession();
    }

    private void Update()
    {
        if (socket == null || paused) return;
        WatchRecenter();
        // Poses are cached per frame. Capture only after the tracking origin has updated.
        if (recenterPending && Time.frameCount > recenterFrame && TrackingReady())
        {
            calibration = CapturePoseFrame();
            if (++calibrationId == 0) calibrationId = 1;
            recenterPending = false;
            Debug.Log($"QPOS recenter {recenterId}: new tracking-frame poses ready; a fresh A is required.");
        }
        // Consume READY/HOMING feedback before interpreting this frame's A press.
        try { ReceivePongs(); }
        catch (SocketException) { /* No status acknowledgement: keep waiting, never assume READY. */ }
        // Y -> left hand; right B -> right hand. Left X is unused.
        // Normal uint32 wrap preserves even/odd mode parity, including after packet loss.
        if (OVRInput.GetDown(OVRInput.Button.Two, OVRInput.Controller.LTouch))
        {
            unchecked { leftSelectPress++; }
            SelectFinger(0);
        }
        if (OVRInput.GetDown(OVRInput.Button.Two, OVRInput.Controller.RTouch))
        {
            unchecked { rightSelectPress++; }
            SelectFinger(1);
        }
        PlaySelectionAudio();
        if (OVRInput.GetDown(OVRInput.Button.One, OVRInput.Controller.RTouch))
            ToggleTeleoperation(TrackingReady());
        try
        {
            ReceivePongs();
            double now = Now;
            if (now >= nextPing)
            {
                uint id = ++pingSequence;
                double sent = Now;
                using (var bytes = new MemoryStream(HeaderSize))
                using (var writer = new BinaryWriter(bytes))
                {
                    WriteHeader(writer, 2, HeaderSize, id, sent);
                    Send(bytes);
                }
                pingSent = sent;
                nextPing = now + 1;
            }
            if (now < nextPose) return;
            // One current sample per frame, with an accumulated deadline and no catch-up burst.
            double period = 1.0 / Math.Max(1, sendHz);
            nextPose += period;
            if (nextPose <= now) nextPose = now + period;
            using (var bytes = new MemoryStream(PoseSize))
            using (var writer = new BinaryWriter(bytes))
            {
                WriteHeader(writer, 1, PoseSize, sequence++, Now);
                writer.Write(rtt);
                writer.Write(offset);
                writer.Write(lastSync < 0 ? -1 : now - lastSync);
                // Reuse the original script's OVR poses and ROS conversion.
                var frame = CapturePoseFrame();
                WritePose(writer, XRNode.Head, frame.hPos, frame.hRot, mainCamera != null);
                WritePose(writer, XRNode.LeftHand, frame.lPos, frame.lRot, true);
                WritePose(writer, XRNode.RightHand, frame.rPos, frame.rRot, true);
                // Repeat the immutable button-time anchors: losing one UDP packet cannot lose A.
                writer.Write(recenterPending || recenterRequiresStop ? 0u : calibrationId);
                WriteAnchor(writer, calibration.hPos, calibration.hRot);
                WriteAnchor(writer, calibration.lPos, calibration.lRot);
                WriteAnchor(writer, calibration.rPos, calibration.rRot);
                WriteControls(writer);
                writer.Write(aPressId); writer.Write(bPressId);
                writer.Write(runRequested ? 1u : 0u);
                WriteBaseControls(writer);
                writer.Write(recenterId);
                uint hands = (InputDevices.GetDeviceAtXRNode(XRNode.LeftHand).isValid ? 1u : 0u)
                    | (InputDevices.GetDeviceAtXRNode(XRNode.RightHand).isValid ? 2u : 0u);
                writer.Write(hands);
                writer.Write(leftSelectPress); writer.Write(rightSelectPress);
                Send(bytes);
            }
        }
        catch (SocketException e)
        {
            if (Now >= nextErrorLog)
            {
                Debug.LogWarning("QPOS network: " + e.SocketErrorCode);
                nextErrorLog = Now + 5;
            }
        }
    }

    private void ToggleTeleoperation(bool trackingReady)
    {
        if (stopAwaitingReady)
        {
            Debug.Log("QPOS A ignored: waiting for AGX READY after homing.");
            return;
        }
        // Stopping must work even when tracking is missing or recenter was blocked.
        if (runRequested || needsHome || recenterRequiresStop)
        {
            if (++bPressId == 0) bPressId = 1;
            runRequested = false;
            recenterRequiresStop = needsHome = false;
            stopAwaitingReady = true;
            Debug.Log("QPOS A stop: home/disable requested; waiting for READY.");
        }
        else if (!recenterPending && trackingReady)
        {
            calibration = CapturePoseFrame();
            if (++calibrationId == 0) calibrationId = 1;
            if (++aPressId == 0) aPressId = 1;
            runRequested = true;
            Debug.Log($"QPOS A start {calibrationId}: new neutral poses captured.");
        }
        else Debug.LogWarning("QPOS A start ignored: wait for head/controller tracking and recenter.");
    }

    private void ApplyControlStatus(uint seq, uint phase, uint startAck, uint stopAck)
    {
        // Reply sequence refers to a pose, not a ping. Ignore reordered replies.
        if (haveStatus && unchecked((int)(seq - lastStatusSequence)) <= 0) return;
        haveStatus = true;
        lastStatusSequence = seq;
        if (phase == 3) // HOMING: A cannot restart until the actual SDK home completes.
        {
            stopAwaitingReady = true;
            runRequested = false;
        }
        else if (phase == 4) needsHome = true; // Frozen after stale input/recenter/session change.
        else if ((phase == 0 || phase == 1) && startAck == aPressId && stopAck == bPressId)
        {
            // Old READY replies cannot cancel a new start. Phase 0 is a pose-only monitor.
            if (stopAwaitingReady) Debug.Log("QPOS READY: press A to start.");
            stopAwaitingReady = needsHome = false;
            if (phase == 1) runRequested = false;
        }
    }

    private void PrepareSelectionAudio()
    {
        if (selectionVoice != null) return;
        selectionVoice = gameObject.AddComponent<AudioSource>();
        selectionVoice.playOnAwake = false;
        selectionVoice.spatialBlend = 0; // Spoken in the headset, independent of head position.
        selectionVoice.volume = 0.8f;
        for (int side = 0; side < 2; side++)
            for (int finger = 0; finger < FingerNames.Length; finger++)
            {
                string name = (side == 0 ? "left_" : "right_") + FingerNames[finger];
                selectionClips[side, finger] = Resources.Load<AudioClip>("FingerSelection/" + name);
                if (selectionClips[side, finger] == null)
                    Debug.LogWarning("QPOS missing selection voice: " + name);
            }
    }

    private void SelectFinger(int side)
    {
        fingerSelection[side] = (fingerSelection[side] + 1) % FingerNames.Length;
        selectionPending[side] = true;
        // Replace outdated speech for this hand instead of building a long queue.
        if (speakingSide == side && selectionVoice != null) selectionVoice.Stop();
    }

    private void PlaySelectionAudio()
    {
        if (selectionVoice == null || selectionVoice.isPlaying) return;
        // Alternate when both hands have pending speech. Keep only the latest per hand.
        int first = speakingSide == 0 ? 1 : 0;
        for (int i = 0; i < 2; i++)
        {
            int side = (first + i) % 2;
            if (!selectionPending[side]) continue;
            selectionPending[side] = false;
            AudioClip clip = selectionClips[side, fingerSelection[side]];
            if (clip == null) continue;
            speakingSide = side;
            selectionVoice.clip = clip;
            selectionVoice.Play(); // Nonblocking; pose sending continues at its usual rate.
            break;
        }
    }

    private void ResetSelectionAudio()
    {
        if (selectionVoice != null) selectionVoice.Stop();
        fingerSelection[0] = fingerSelection[1] = 0;
        selectionPending[0] = selectionPending[1] = false;
        speakingSide = -1;
    }

    private void WriteHeader(BinaryWriter writer, byte kind, ushort length, uint seq, double sent)
    {
        writer.Write(Magic); writer.Write(ProtocolVersion); writer.Write(kind); writer.Write(length);
        writer.Write(session); writer.Write(seq); writer.Write(sent);
    }

    private void Send(MemoryStream bytes)
    {
        byte[] packet = bytes.ToArray();
        socket.Send(packet, packet.Length);
    }

    private struct PoseFrame
    {
        public Vector3 hPos, lPos, rPos;
        public Quaternion hRot, lRot, rRot;
    }

    private bool TrackingReady() => mainCamera != null && FullyTracked(XRNode.Head)
        && FullyTracked(XRNode.LeftHand) && FullyTracked(XRNode.RightHand)
        && OVRInput.GetControllerPositionTracked(OVRInput.Controller.LTouch)
        && OVRInput.GetControllerPositionTracked(OVRInput.Controller.RTouch)
        && OVRInput.GetControllerOrientationTracked(OVRInput.Controller.LTouch)
        && OVRInput.GetControllerOrientationTracked(OVRInput.Controller.RTouch);

    private void WatchRecenter()
    {
        if (recenterDisplay == OVRManager.display) return;
        if (recenterDisplay != null) recenterDisplay.RecenteredPose -= OnRecentered;
        recenterDisplay = OVRManager.display;
        if (recenterDisplay != null) recenterDisplay.RecenteredPose += OnRecentered;
    }

    private void OnRecentered()
    {
        if (++recenterId == 0) recenterId = 1;
        recenterFrame = Time.frameCount;
        recenterPending = true;
        recenterRequiresStop |= runRequested;
        // Keep runRequested unchanged: recenter must freeze, never impersonate an A-stop/home request.
        Debug.Log(recenterRequiresStop
            ? "QPOS RECENTER BLOCKED while running. A to home, wait for READY, then A to start."
            : "QPOS recenter: waiting for new poses before accepting A.");
    }

    private static bool FullyTracked(XRNode node)
    {
        var device = InputDevices.GetDeviceAtXRNode(node);
        return device.isValid && device.TryGetFeatureValue(CommonUsages.isTracked, out bool tracked) && tracked
            && device.TryGetFeatureValue(CommonUsages.trackingState, out InputTrackingState state)
            && (state & (InputTrackingState.Position | InputTrackingState.Rotation))
                == (InputTrackingState.Position | InputTrackingState.Rotation);
    }

    private static void WriteAnchor(BinaryWriter writer, Vector3 p, Quaternion q)
    {
        writer.Write(p.x); writer.Write(p.y); writer.Write(p.z);
        writer.Write(q.x); writer.Write(q.y); writer.Write(q.z); writer.Write(q.w);
    }

    private void WriteControls(BinaryWriter writer)
    {
        var left = InputDevices.GetDeviceAtXRNode(XRNode.LeftHand);
        var right = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
        uint available = 0;
        float leftTrigger = ReadAnalog(left, CommonUsages.trigger, 1, ref available);
        float leftGrip = ReadAnalog(left, CommonUsages.grip, 2, ref available);
        float rightTrigger = ReadAnalog(right, CommonUsages.trigger, 4, ref available);
        float rightGrip = ReadAnalog(right, CommonUsages.grip, 8, ref available);
        var torsoController = right; // Right Y: torso. Right X is sent in WriteBaseControls.
        float torsoY = 0;
        if (torsoController.isValid && torsoController.TryGetFeatureValue(CommonUsages.primary2DAxis, out Vector2 stick))
        {
            available |= 16;
            torsoY = Mathf.Clamp(stick.y, -1, 1);
        }
        writer.Write(available);
        writer.Write(leftTrigger); writer.Write(leftGrip);
        writer.Write(rightTrigger); writer.Write(rightGrip);
        writer.Write(torsoY); // Up positive, down negative; raw intent, no motor command.
    }

    private static void WriteBaseControls(BinaryWriter writer)
    {
        var left = InputDevices.GetDeviceAtXRNode(XRNode.LeftHand);
        Vector2 stick = Vector2.zero;
        bool available = left.isValid && left.TryGetFeatureValue(CommonUsages.primary2DAxis, out stick);
        writer.Write(available ? 3u : 0u);
        writer.Write(available ? Mathf.Clamp(stick.x, -1, 1) : 0f);
        writer.Write(available ? Mathf.Clamp(stick.y, -1, 1) : 0f);
        var right = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
        Vector2 rightStick = Vector2.zero;
        bool turnAvailable = right.isValid && right.TryGetFeatureValue(CommonUsages.primary2DAxis, out rightStick);
        writer.Write(turnAvailable ? 1u : 0u);
        writer.Write(turnAvailable ? Mathf.Clamp(rightStick.x, -1, 1) : 0f);
    }

    private static float ReadAnalog(InputDevice device, InputFeatureUsage<float> usage, uint bit, ref uint available)
    {
        if (!device.isValid || !device.TryGetFeatureValue(usage, out float value)) return 0;
        available |= bit;
        return Mathf.Clamp01(value);
    }

    // Preserved from the original recorder. ROS FLU: x forward, y left, z up.
    private static Vector3 UnityToRosPosition(Vector3 p) => new Vector3(p.z, -p.x, p.y);
    private static Quaternion UnityToRosRotation(Quaternion q) => new Quaternion(q.z, -q.x, q.y, -q.w);

    private PoseFrame CapturePoseFrame()
    {
        return new PoseFrame {
            hPos = mainCamera != null ? UnityToRosPosition(mainCamera.localPosition) : Vector3.zero,
            hRot = mainCamera != null ? UnityToRosRotation(mainCamera.localRotation) : Quaternion.identity,
            lPos = UnityToRosPosition(OVRInput.GetLocalControllerPosition(OVRInput.Controller.LTouch)),
            lRot = UnityToRosRotation(OVRInput.GetLocalControllerRotation(OVRInput.Controller.LTouch)),
            rPos = UnityToRosPosition(OVRInput.GetLocalControllerPosition(OVRInput.Controller.RTouch)),
            rRot = UnityToRosRotation(OVRInput.GetLocalControllerRotation(OVRInput.Controller.RTouch))
        };
    }

    private static void WritePose(BinaryWriter writer, XRNode node, Vector3 p, Quaternion q, bool sourceAvailable)
    {
        InputDevice device = InputDevices.GetDeviceAtXRNode(node);
        bool trackedKnown = device.TryGetFeatureValue(CommonUsages.isTracked, out bool tracked);
        bool stateKnown = device.TryGetFeatureValue(CommonUsages.trackingState, out InputTrackingState state);
        bool positionRead = sourceAvailable && device.TryGetFeatureValue(CommonUsages.devicePosition, out _);
        bool rotationRead = sourceAvailable && device.TryGetFeatureValue(CommonUsages.deviceRotation, out _);
        if (node != XRNode.Head)
        {
            var controller = node == XRNode.LeftHand ? OVRInput.Controller.LTouch : OVRInput.Controller.RTouch;
            positionRead &= OVRInput.GetControllerPositionTracked(controller);
            rotationRead &= OVRInput.GetControllerOrientationTracked(controller);
        }
        uint flags = (device.isValid ? 1u : 0u) | (tracked ? 2u : 0u)
            | (positionRead ? 4u : 0u) | (rotationRead ? 8u : 0u)
            | (stateKnown ? 16u : 0u) | (trackedKnown ? 32u : 0u);
        // Unavailable values are explicit placeholders, never presented as valid tracking.
        if (!positionRead) p = Vector3.zero;
        if (!rotationRead) q = Quaternion.identity;
        writer.Write(flags); writer.Write((uint)state);
        writer.Write(p.x); writer.Write(p.y); writer.Write(p.z);
        writer.Write(q.x); writer.Write(q.y); writer.Write(q.z); writer.Write(q.w);
    }

    private void ReceivePongs()
    {
        for (int count = 0; count < 16 && socket.Available > 0; count++)
        {
            IPEndPoint source = null;
            byte[] bytes = socket.Receive(ref source);
            double received = Now;
            if (!source.Equals(remote) || (bytes.Length != PongSize && bytes.Length != StatusSize)) continue;
            using (var reader = new BinaryReader(new MemoryStream(bytes)))
            {
                if (reader.ReadUInt32() != Magic || reader.ReadByte() != ProtocolVersion) continue;
                byte kind = reader.ReadByte();
                if (reader.ReadUInt16() != bytes.Length || reader.ReadUInt64() != session) continue;
                if (kind == 4 && bytes.Length == StatusSize)
                {
                    uint poseSeq = reader.ReadUInt32();
                    reader.ReadDouble();
                    uint phase = reader.ReadUInt32();
                    if (phase <= 4) ApplyControlStatus(poseSeq, phase, reader.ReadUInt32(), reader.ReadUInt32());
                    continue;
                }
                if (kind != 3 || bytes.Length != PongSize) continue;
                uint id = reader.ReadUInt32();
                double t1 = reader.ReadDouble(), t2 = reader.ReadDouble(), t3 = reader.ReadDouble();
                if (id != pingSequence || t1 != pingSent || pingSent < 0) continue;
                pingSent = -1;
                double sampleRtt = (received - t1) - (t3 - t2);
                double sampleOffset = ((t2 - t1) + (t3 - received)) / 2;
                if (double.IsNaN(sampleRtt) || double.IsInfinity(sampleRtt) || sampleRtt < 0 || sampleRtt > 2
                    || double.IsNaN(sampleOffset) || double.IsInfinity(sampleOffset) || t3 < t2) continue;
                if (received - syncWindow > 10) { bestRtt = double.PositiveInfinity; syncWindow = received; }
                if (sampleRtt <= bestRtt)
                {
                    bestRtt = sampleRtt; offset = sampleOffset; lastSync = received;
                }
                rtt = sampleRtt;
            }
        }
    }

    // Request Android's low-latency radio mode only while this sender is active.
    // A held lock is a request; Android also requires foreground + screen on.
    private void SetLowLatencyWifi(bool enabled)
    {
#if UNITY_ANDROID && !UNITY_EDITOR
        try
        {
            if (enabled)
            {
                if (wifiLock == null)
                {
                    using (var player = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
                    using (var activity = player.GetStatic<AndroidJavaObject>("currentActivity"))
                    using (var context = activity.Call<AndroidJavaObject>("getApplicationContext"))
                    using (var wifi = context.Call<AndroidJavaObject>("getSystemService", "wifi"))
                    using (var manager = new AndroidJavaClass("android.net.wifi.WifiManager"))
                    {
                        int mode = manager.GetStatic<int>("WIFI_MODE_FULL_LOW_LATENCY");
                        wifiLock = wifi.Call<AndroidJavaObject>("createWifiLock", mode, "QuestAGXPose:low_latency");
                        wifiLock.Call("setReferenceCounted", false);
                    }
                }
                if (!wifiLock.Call<bool>("isHeld"))
                {
                    wifiLock.Call("acquire");
                    Debug.Log("QPOS Wi-Fi low-latency lock acquired; Android requires foreground and screen on.");
                }
            }
            else if (wifiLock != null)
            {
                if (wifiLock.Call<bool>("isHeld")) wifiLock.Call("release");
                Debug.Log("QPOS Wi-Fi low-latency lock released.");
            }
        }
        catch (Exception e)
        {
            // A radio-mode request must not stop pose streaming.
            Debug.LogWarning("QPOS Wi-Fi low-latency request failed: " + e.Message);
        }
        finally
        {
            if (!enabled && wifiLock != null)
            {
                wifiLock.Dispose();
                wifiLock = null;
            }
        }
#endif
    }

    private void CloseSocket() { socket?.Close(); socket = null; }
    private void OnDisable()
    {
        ResetSelectionAudio();
        SetLowLatencyWifi(false);
        if (recenterDisplay != null) recenterDisplay.RecenteredPose -= OnRecentered;
        recenterDisplay = null;
        CloseSocket();
    }
}
