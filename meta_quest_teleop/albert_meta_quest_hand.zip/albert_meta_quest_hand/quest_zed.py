"""Latest native stereo frames across separate ZED and teleoperation environments.

The worker publishes one atomic NPZ containing both original RGB images and
their native calibration. Importing this bridge never starts a camera/process.
"""
import json
from io import BytesIO
import math
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import time

import numpy as np
from PIL import Image


WORKER = Path(__file__).with_name("quest_zed_worker.py")
MODELS = ("zed-x", "zed-2i")


def probe_camera(python, serial=None, model="zed-x"):
    if model not in MODELS:
        raise ValueError("Unknown ZED model: " + str(model))
    result = subprocess.run([str(python), str(WORKER), "--probe", "--model", model],
                            capture_output=True, text=True, timeout=20)
    # ZED diagnostics may precede the worker's JSON device inventory.
    for line in reversed(result.stdout.splitlines()):
        try:
            info = json.loads(line)
        except ValueError:
            continue
        if isinstance(info, dict) and isinstance(info.get("devices"), list):
            break
    else:
        raise RuntimeError((result.stderr or result.stdout or "No ZED probe output")[-1500:])
    devices = [device for device in info["devices"]
               if device.get("model_key") == model and device.get("serial", 0) > 0
               and (serial is None or device["serial"] == serial)]
    info["ready"] = len(devices) == 1 and getattr(result, "returncode", 0) == 0
    if not info["ready"]:
        info["issue"] = ("No unique %s with a valid serial; check USB video detection "
                         "or specify --camera-serial" % model)
        if getattr(result, "returncode", 0):
            info["issue"] += "; probe exited with status %s" % result.returncode
    return info


class StereoCamera:
    native_stereo = True

    def __init__(self, python=None, synthetic=False, serial=None, fps=15, timeout=.5,
                 model="zed-x"):
        if model not in MODELS:
            raise ValueError("Unknown ZED model: " + str(model))
        if fps not in (10, 15, 30):
            raise ValueError("ZED frame rate must be 10, 15 or 30")
        if not math.isfinite(timeout) or timeout <= 0:
            raise ValueError("Camera timeout must be finite and positive")
        self.python = str(python or sys.executable)
        self.synthetic, self.serial, self.fps = synthetic, serial, fps
        self.timeout, self.model = timeout, model
        self.lock = threading.Lock()
        self.stop = threading.Event()
        self.frame = self.jpeg = self.calibration = None
        self.stereo = False
        self.error = "Waiting for first native stereo frame"
        self.proc = self.directory = self.thread = self.log = None

    def start(self):
        if self.proc is not None and self.proc.poll() is None:
            return self
        if not WORKER.is_file():
            raise FileNotFoundError("ZED capture worker is missing: " + str(WORKER))
        if self.directory is not None:
            self.close()
        self.stop.clear()
        with self.lock:
            self.frame = self.jpeg = self.calibration = None
            self.stereo = False
            self.error = "Waiting for first native stereo frame"
        base = "/dev/shm" if Path("/dev/shm").is_dir() else None
        self.directory = tempfile.TemporaryDirectory(prefix="quest-zed-", dir=base)
        path = Path(self.directory.name)
        self.log = (path / "worker.log").open("w+")
        args = [self.python, "-u", str(WORKER), "--output-dir", str(path),
                "--fps", str(self.fps), "--parent-pid", str(os.getpid()), "--model", self.model]
        if self.synthetic:
            args.append("--test-pattern")
        if self.serial is not None:
            args += ["--serial", str(self.serial)]
        try:
            self.proc = subprocess.Popen(args, stdout=self.log, stderr=self.log,
                                         env=dict(os.environ, PYTHONNOUSERSITE="1"))
            self.thread = threading.Thread(target=self._read, daemon=True)
            self.thread.start()
        except BaseException:
            self.close()
            raise
        return self

    def _read_frame(self, path, last_sequence):
        """Read/encode one atomic worker snapshot; return its accepted sequence."""
        with np.load(str(path), allow_pickle=False) as data:
            required = {"sequence", "timestamp", "left", "right", "calibration", "stereo"}
            if required - set(data.files):
                raise ValueError("Worker snapshot is missing native stereo metadata")
            sequence = np.asarray(data["sequence"])
            if sequence.shape != () or not np.issubdtype(sequence.dtype, np.integer):
                raise ValueError("Invalid stereo sequence")
            sequence = int(sequence)
            if sequence <= 0:
                raise ValueError("Invalid stereo sequence")
            if sequence <= last_sequence:
                return last_sequence
            stamp = float(data["timestamp"])
            left, right = data["left"], data["right"]
            calibration = np.asarray(data["calibration"], dtype=float)
            stereo = np.asarray(data["stereo"])
        if (left.shape != right.shape or left.ndim != 3 or left.shape[2] != 3
                or min(left.shape[:2]) <= 0 or left.dtype != np.uint8 or right.dtype != np.uint8):
            raise ValueError("Invalid stereo RGB images")
        if not math.isfinite(stamp) or stamp < 0:
            raise ValueError("Invalid capture timestamp")
        if stereo.shape != () or stereo.dtype != np.bool_ or not bool(stereo):
            raise ValueError("Worker did not supply a native stereo pair")
        height, width = left.shape[:2]
        if (calibration.shape != (7,) or not np.isfinite(calibration).all()
                or calibration[0] <= 0 or calibration[1] <= 0
                or not 0 <= calibration[2] <= width or not 0 <= calibration[3] <= height
                or not .02 <= calibration[5] <= .3):
            raise ValueError("Invalid native stereo calibration")
        # JPEG work stays in this reader, off the tracking/control event loop.
        # Each original eye is encoded directly; there is no crop or reprojection.
        encoded = []
        for pixels in (left, right):
            stream = BytesIO()
            Image.fromarray(pixels).save(stream, format="JPEG", quality=75)
            encoded.append(stream.getvalue())
            pixels.setflags(write=False)
        calibration = tuple(float(value) for value in calibration)
        with self.lock:
            self.frame = (sequence, stamp, left, right)
            self.jpeg = (sequence, stamp, encoded[0], encoded[1], width, height)
            self.calibration, self.stereo = calibration, True
            self.error = None
        return sequence

    def _read(self):
        path = Path(self.directory.name) / "frame.npz"
        last = 0
        while not self.stop.wait(.01):
            if self.proc.poll() is not None:
                self.log.flush()
                detail = (Path(self.directory.name) / "worker.log").read_text()[-1500:]
                with self.lock:
                    self.error = "Capture stopped: " + detail.strip()
                return
            try:
                last = self._read_frame(path, last)
            except FileNotFoundError:
                pass
            except Exception as exc:
                with self.lock:
                    self.error = str(exc)

    def latest(self):
        with self.lock:
            return self.frame

    def latest_jpeg(self):
        with self.lock:
            return self.jpeg

    def latest_calibrated_jpeg(self):
        with self.lock:
            return self.jpeg, self.calibration, self.stereo

    def status(self):
        with self.lock:
            age = None if self.frame is None else time.monotonic() - self.frame[1]
            healthy = (self.proc is not None and self.proc.poll() is None and self.error is None
                       and self.stereo and age is not None and math.isfinite(age) and 0 <= age < self.timeout)
            return {"source": "synthetic" if self.synthetic else self.model, "healthy": healthy,
                    "native_stereo": True, "stereo_ready": self.stereo,
                    "capture_age_s": age, "sequence": 0 if self.frame is None else self.frame[0],
                    "error": self.error or (None if healthy else "Camera frames are stale or capture has stopped")}

    def healthy(self):
        return self.status()["healthy"]

    def close(self):
        self.stop.set()
        if self.proc is not None and self.proc.poll() is None:
            self.proc.terminate()
            try:
                self.proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.proc.kill()
                self.proc.wait(timeout=3)
        if self.thread is not None:
            self.thread.join(timeout=1)
        if self.log is not None:
            self.log.close()
            self.log = None
        if self.directory is not None:
            self.directory.cleanup()

