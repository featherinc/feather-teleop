"""Capture the original rectified ZED stereo pair; no robot access or depth processing."""
import argparse
import json
import os
from pathlib import Path
import signal
import sys
import time

import numpy as np


def probe():
    import pyzed.sl as sl
    devices = []
    for device in sl.Camera.get_device_list():
        name = str(device.camera_model)
        upper = name.upper().replace(" ", "_")
        key = "zed-2i" if "ZED_2I" in upper else "zed-x" if "ZED_X" in upper else "unknown"
        devices.append({"serial": int(device.serial_number), "model": name, "model_key": key})
    return {"sdk": sl.Camera.get_sdk_version(), "devices": devices}


def publish(directory, left, right, seq, stamp, calibration, stereo=True):
    # Publish both eyes, calibration and time in one atomic snapshot.
    temporary = directory / "frame.tmp"
    with temporary.open("wb") as stream:
        np.savez(stream, left=left, right=right, sequence=np.int64(seq), timestamp=np.float64(stamp),
                 calibration=np.asarray(calibration, dtype=np.float32), stereo=np.bool_(stereo))
    os.replace(str(temporary), str(directory / "frame.npz"))


def native_calibration(camera, resolution):
    calibration = camera.get_camera_information(resolution).camera_configuration.calibration_parameters
    left = calibration.left_cam
    # UNIT.METER applies to the stereo translation used by get_camera_baseline().
    values = [left.fx, left.fy, left.cx, left.cy, 0., calibration.get_camera_baseline(), 0.]
    if (not all(np.isfinite(value) for value in values) or values[0] <= 0 or values[1] <= 0
            or not .02 <= values[5] <= .3):
        raise RuntimeError("Invalid ZED stereo calibration in meters")
    return values


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--probe", action="store_true")
    parser.add_argument("--model", choices=("zed-x", "zed-2i"), default="zed-x")
    parser.add_argument("--test-pattern", action="store_true")
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--serial", type=int)
    parser.add_argument("--parent-pid", type=int, help="Stop if the launching bridge exits")
    parser.add_argument("--fps", type=int, default=15, choices=(10, 15, 30))
    parser.add_argument("--width", type=int, default=640)
    parser.add_argument("--height", type=int, default=360)
    args = parser.parse_args(argv)
    if args.probe:
        info = probe()
        print(json.dumps(info), flush=True)
        return 0 if any(d["model_key"] == args.model and d["serial"] > 0 for d in info["devices"]) else 2
    if args.output_dir is None:
        parser.error("--output-dir is required")
    if not 16 <= args.width <= 1280 or not 16 <= args.height <= 720:
        parser.error("Invalid output dimensions")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    running = True

    def stop(*_):
        nonlocal running
        running = False

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    camera = None
    try:
        if not args.test_pattern:
            import pyzed.sl as sl
            info = probe()
            devices = [device for device in info["devices"]
                       if device["model_key"] == args.model and device["serial"] > 0
                       and (args.serial is None or device["serial"] == args.serial)]
            if len(devices) != 1:
                raise RuntimeError("Expected one %s; select --serial if several are attached: %s"
                                   % (args.model, json.dumps(info)))
            camera = sl.Camera()
            params = sl.InitParameters()
            params.camera_resolution = sl.RESOLUTION.HD720 if args.model == "zed-2i" else sl.RESOLUTION.AUTO
            params.camera_fps = 30
            params.depth_mode = sl.DEPTH_MODE.NONE
            params.coordinate_units = sl.UNIT.METER
            params.enable_right_side_measure = False
            params.set_from_serial_number(devices[0]["serial"])
            result = camera.open(params)
            if result != sl.ERROR_CODE.SUCCESS:
                raise RuntimeError("ZED open failed: " + str(result))
            mats = [sl.Mat(), sl.Mat()]
            resolution = sl.Resolution(args.width, args.height)
            calibration = native_calibration(camera, resolution)
            runtime = sl.RuntimeParameters()
            runtime.enable_depth = False
            runtime.enable_fill_mode = False
            print(json.dumps({"camera": devices[0], "sdk": info["sdk"]}), flush=True)
        else:
            calibration = [float(args.width), float(args.width), args.width / 2., args.height / 2., 0., .12, 0.]
            print("SYNTHETIC STEREO TEST: no camera or robot connected", flush=True)
        sequence = 0
        while running:
            if args.parent_pid is not None and os.getppid() != args.parent_pid:
                break
            capture_tick = time.monotonic()
            stamp = capture_tick
            if args.test_pattern:
                left = np.zeros((args.height, args.width, 3), dtype=np.uint8)
                left[:, :, 0] = 180
                column = (sequence * 9) % args.width
                left[:, column:column + 12, :] = 255
                right = left[:, :, [2, 1, 0]].copy()
            else:
                result = camera.grab(runtime)
                if result != sl.ERROR_CODE.SUCCESS:
                    raise RuntimeError("ZED grab failed: " + str(result))
                stamp = time.monotonic()
                for mat, view in zip(mats, (sl.VIEW.LEFT, sl.VIEW.RIGHT)):
                    result = camera.retrieve_image(mat, view, sl.MEM.CPU, resolution)
                    if result != sl.ERROR_CODE.SUCCESS:
                        raise RuntimeError("ZED retrieve failed: " + str(result))
                left, right = [np.ascontiguousarray(mat.get_data()[:, :, [2, 1, 0]]) for mat in mats]
            sequence += 1
            publish(args.output_dir, left, right, sequence, stamp, calibration, stereo=True)
            time.sleep(max(0., 1 / args.fps - (time.monotonic() - capture_tick)))
    finally:
        if camera is not None:
            camera.close()
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as error:
        print("Camera error: " + str(error), file=sys.stderr, flush=True)
        sys.exit(2)
