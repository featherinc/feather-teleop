"""Quest poses -> A-button calibration -> TeleVision IK -> CSV. No motor commands.

ArmModel loads each URDF. QuestIK maps controller movement and holds failed solutions.
capture() receives packets and writes the two arm rows returned by comparison_rows().
"""
from __future__ import annotations
import csv
import hashlib
import json
import math
from pathlib import Path
import time
from types import SimpleNamespace

import numpy as np
import pinocchio as pin
from scipy.spatial.transform import Rotation
from quest_pose_receiver import PoseReceiver, CONTROL_NAMES, format_controls
from television_ik_core import (TeleVisionIK, IKDatabase, IK_TOLERANCE_NORM,
    IK_TOLERANCE_POS_MM, IK_DB_POSITION_WEIGHT, IK_DB_ORIENTATION_WEIGHT, CORE_AST_SHA256)

URDF_DIR = Path(__file__).resolve().parent.parent / 'URDF_C_Arm_03_description-20260625T192804Z-3-001/URDF_C_Arm_03_description/urdf'
DATABASE_PATH = Path(__file__).resolve().parent / 'ik_database/og_joint_samples.npz'
CANDIDATE_FIELDS = ('iterations', 'candidate_position_error_mm',
                    'candidate_rotation_error_deg', 'failure_reason',
                    'seed_source', 'warm_start_used', 'database_fallback_used', 'candidate_limit_joints')


def pose_arrays(pose):
    return np.array(pose['position_m']), Rotation.from_quat(pose['quaternion_xyzw']).as_matrix()


def pose_values(position, rotation):
    return np.r_[position, Rotation.from_matrix(rotation).as_quat()].tolist()


def valid(pose):
    return pose['position_valid'] and pose['rotation_valid']


class ArmModel:
    def __init__(self, side, urdf_dir=URDF_DIR, sdk_joint_limits=None,
                 database_path=DATABASE_PATH):
        self.path = Path(urdf_dir) / f'{side}_arm.urdf'
        if side not in ('left', 'right'):
            raise ValueError('Arm side must be left or right')
        self.side = side
        self.database_path = Path(database_path).resolve()
        self.model = pin.buildModelFromUrdf(str(self.path))
        if self.model.nq != 7 or self.model.nv != 7:
            raise ValueError('Expected the supplied seven-revolute-joint arm URDF')
        self.data = self.model.createData()
        self.joint_names = list(self.model.names)[1:]
        self.frame = f'{side}_wrist_pitch_link_1'
        self.frame_id = self.model.getFrameId(self.frame)
        if self.frame_id >= self.model.nframes:
            raise ValueError(f'Missing wrist frame: {self.frame}')
        lo, hi = self.model.lowerPositionLimit, self.model.upperPositionLimit
        if np.any(lo > 0) or np.any(hi < 0):
            raise ValueError('Zero-joint home lies outside arm URDF limits')
        # The IK bounds can be narrowed to the intersection with SDK limits.
        self.arm = SimpleNamespace(model=self.model, data=self.data,
            neutral_q=np.zeros(7), arm_q_ids=np.arange(7), arm_v_ids=np.arange(7),
            dq=np.zeros(7), q_lower=lo.copy(), q_upper=hi.copy(), ee_frame_id=self.frame_id)
        if sdk_joint_limits is not None:
            self.set_sdk_joint_limits(*sdk_joint_limits)
        self.home_p, self.home_R = self.fk(np.zeros(7))
        self.solver = TeleVisionIK()
        # Use the original recorded angles, reordered by joint name for this URDF.
        with np.load(self.database_path, allow_pickle=False) as recorded:
            q = np.asarray(recorded['q'], dtype=float)
            names = recorded['joint_names'].tolist()
            schema = int(recorded['schema_version'])
            if schema not in (1, 2) or names != ['SpL', 'SrL', 'SwL', 'EpL', 'WwL', 'WpL', 'WrL']:
                raise ValueError('Unsupported recorded IK database joint order/schema')
            self.database_source_sha256 = str(recorded['source_sha256'])
            if q.ndim != 2 or q.shape[1] != 7 or len(q) < 5 or not np.isfinite(q).all():
                raise ValueError('Recorded IK database must contain finite seven-joint poses')
            if schema == 1:
                self.recorded_source_sides = np.full(len(q), 'left')
                self.recorded_source_indices = np.arange(len(q))
                self.database_sources = [dict(side='left',
                    path='TeleVision/teleop/ik_database/combined.pkl',
                    sha256=self.database_source_sha256, recorded=len(q))]
            else:
                self.recorded_source_sides = recorded['row_source_side'].copy()
                self.recorded_source_indices = recorded['row_source_index'].copy()
                sides = recorded['source_sides'].tolist()
                paths = recorded['source_paths'].tolist()
                hashes = recorded['source_sha256s'].tolist()
                counts = recorded['source_counts'].tolist()
                q_hashes = recorded['source_q_sha256s'].tolist()
                if (sides != ['left', 'right'] or len(paths) != 2 or len(hashes) != 2
                        or len(counts) != 2 or len(q_hashes) != 2
                        or self.recorded_source_sides.shape != (len(q),)
                        or self.recorded_source_indices.shape != (len(q),)
                        or not np.issubdtype(self.recorded_source_indices.dtype, np.integer)
                        or not np.isin(self.recorded_source_sides, sides).all()
                        or hashes[0] != self.database_source_sha256
                        or str(recorded['canonicalization']) != 'left_unchanged_right_all_joint_negation'):
                    raise ValueError('Invalid recorded IK database provenance')
                self.database_sources = []
                for source_side, path, sha256, count, q_sha256 in zip(sides, paths, hashes, counts, q_hashes):
                    selected = self.recorded_source_sides == source_side
                    original_q = q[selected] * (1 if source_side == 'left' else -1)
                    if (count < 1 or int(selected.sum()) != count
                            or not np.array_equal(self.recorded_source_indices[selected], np.arange(count))
                            or hashlib.sha256(original_q.tobytes()).hexdigest() != q_sha256):
                        raise ValueError('Invalid recorded IK database provenance')
                    self.database_sources.append(dict(side=source_side, path=path,
                        sha256=sha256, recorded=count, original_q_sha256=q_sha256))
        names = [name[:-1] + ('L' if side == 'left' else 'R') for name in names]
        if set(names) != set(self.joint_names):
            raise ValueError('Recorded IK joints do not match the arm URDF')
        self.recorded_q = q[:, [names.index(name) for name in self.joint_names]].copy()
        if side == 'right':
            self.recorded_q *= -1  # Same joint-sign mirroring as original TeleVision.
        self.database_sha256 = hashlib.sha256(self.database_path.read_bytes()).hexdigest()
        self.database, self.database_info = self._build_database(self.arm.q_lower, self.arm.q_upper)

    def _build_database(self, lower, upper):
        """Keep valid shoulder/elbow angles; move only wrists to the nearest limit."""
        wrist = np.array([name.startswith(('Ww', 'Wr', 'Wp')) for name in self.joint_names])
        within_limits = (self.recorded_q >= lower) & (self.recorded_q <= upper)
        keep = np.all(within_limits[:, ~wrist], axis=1)
        retained = int(keep.sum())
        if retained < 5:
            raise ValueError(f'{self.side}: only {retained} recorded IK poses fit joint limits; need at least 5')
        seeds = self.recorded_q[keep].copy()  # Preserve the original recording.
        wrist_adjusted = int(np.count_nonzero(~np.all(within_limits[keep][:, wrist], axis=1)))
        seeds[:, wrist] = np.clip(seeds[:, wrist], lower[wrist], upper[wrist])
        # Changed angles need matching NEW positions/rotations in the lookup.
        points = [(q.copy(), *self.fk(q)) for q in
                  np.vstack([np.zeros((1, 7)), seeds])]
        database = IKDatabase(points, position_weight=IK_DB_POSITION_WEIGHT,
                              orientation_weight=IK_DB_ORIENTATION_WEIGHT)
        info = dict(source=';'.join(source['path'] for source in self.database_sources),
            source_sha256=self.database_source_sha256, file=str(self.database_path),
            file_sha256=self.database_sha256, recorded=len(self.recorded_q),
            retained=retained, excluded=len(self.recorded_q)-retained,
            original_valid=retained-wrist_adjusted, wrist_adjusted=wrist_adjusted,
            adaptation='nearest_in_range_wrist_angles', excluded_reason='shoulder_or_elbow_limits',
            home_seed_added=True, total_seeds=len(points),
            right_joint_sign_mirror=self.side == 'right', fk_recomputed=True)
        info['sources'] = [dict(source,
            retained=int(np.count_nonzero(keep & (self.recorded_source_sides == source['side']))),
            excluded=int(np.count_nonzero(~keep & (self.recorded_source_sides == source['side']))))
            for source in self.database_sources]
        info['canonicalization'] = 'left_unchanged_right_all_joint_negation'
        return database, info

    def set_sdk_joint_limits(self, lower, upper):
        """Apply a per-joint SDK bound as its intersection with the URDF bound."""
        lower = np.asarray(lower, dtype=float)
        upper = np.asarray(upper, dtype=float)
        if lower.shape != (7,) or upper.shape != (7,) or not np.all(np.isfinite(lower)) \
                or not np.all(np.isfinite(upper)) or np.any(lower > upper):
            raise ValueError('SDK joint limits must be finite ordered arrays of length 7')
        lo = np.maximum(self.model.lowerPositionLimit, lower)
        hi = np.minimum(self.model.upperPositionLimit, upper)
        if np.any(lo > hi):
            raise ValueError('SDK and URDF joint limits have an empty intersection')
        if np.any(lo > 0) or np.any(hi < 0):
            raise ValueError('Zero-joint calibration home lies outside joint-limit intersection')
        if np.array_equal(lo, self.arm.q_lower) and np.array_equal(hi, self.arm.q_upper):
            return lo.copy(), hi.copy()  # Worker calls this every tick; no FK/tree rebuild.
        if hasattr(self, 'recorded_q'):
            database, info = self._build_database(lo, hi)
            self.database, self.database_info = database, info
        self.arm.q_lower = lo.copy()
        self.arm.q_upper = hi.copy()
        return lo.copy(), hi.copy()

    def fk(self, q):
        pin.framesForwardKinematics(self.model, self.data, q)
        pose = self.data.oMf[self.frame_id]
        return pose.translation.copy(), pose.rotation.copy()

    def solve(self, position, rotation, previous_q=None):
        started = time.monotonic()
        # Keep previous_q in the call signature for existing callers; original TeleVision
        # always seeds from its five nearest database poses, never the preceding solution.
        q, _, _, last_iteration = self.solver._compute_single_arm_ik(
            self.arm, self.database, position, rotation)
        fk_p, fk_R = self.fk(q)  # Recompute errors at the actually returned final q.
        pos_error = float(np.linalg.norm(position - fk_p))
        rot_error = float(np.linalg.norm(pin.log3(rotation @ fk_R.T)))
        good = (np.all(np.isfinite(q)) and pos_error * 1000 < IK_TOLERANCE_POS_MM
                and math.hypot(pos_error, rot_error) < IK_TOLERANCE_NORM)
        return dict(joints_rad=q.tolist(), wrist=pose_values(fk_p, fk_R),
                    position_error_mm=pos_error * 1000, rotation_error_deg=math.degrees(rot_error),
                    converged=bool(good), iterations=last_iteration + 1,
                    solve_ms=(time.monotonic() - started) * 1000,
                    failure_reason=None if good else 'iteration_limit',
                    seed_source='database', warm_start_used=False,
                    database_fallback_used=False,
                    candidate_limit_joints=';'.join(name for name, value, low, high in
                        zip(self.joint_names, q, self.arm.q_lower, self.arm.q_upper)
                        if min(abs(value-low), abs(value-high)) < 1e-6))


class QuestIK:
    def __init__(self, scale=1.7, urdf_dir=URDF_DIR, sdk_joint_limits=None,
                 database_path=DATABASE_PATH):
        if not math.isfinite(scale) or scale <= 0:
            raise ValueError('scale must be positive')
        self.scale = scale
        sdk_joint_limits = sdk_joint_limits or {}
        unknown_sides = set(sdk_joint_limits) - {'left', 'right'}
        if unknown_sides:
            raise ValueError(f'Unknown arm side(s): {sorted(unknown_sides)}')
        self.arms = {side: ArmModel(side, urdf_dir,
            sdk_joint_limits=sdk_joint_limits.get(side), database_path=database_path)
            for side in ('left', 'right')}
        self.key = self.blocked_key = None
        self.calibration = None
        self.accepted = {}
        self.parallel = None
        self.status = 'Waiting for right-controller A; head and both controllers must be tracked.'

    def start_parallel(self):
        """Start two independent solvers once, before receiving live commands."""
        if self.parallel is None:
            from quest_parallel_ik import ParallelArmIK
            self.parallel = ParallelArmIK({side: dict(side=side, urdf_dir=str(arm.path.parent),
                database_path=str(arm.database_path),
                sdk_joint_limits=(arm.arm.q_lower, arm.arm.q_upper))
                for side, arm in self.arms.items()})

    def close(self):
        if self.parallel is not None:
            self.parallel.close()
            self.parallel = None

    def set_sdk_joint_limits(self, limits_by_side):
        """Set SDK bounds with {'left': (lower7, upper7), 'right': (...)}."""
        for side, (lower, upper) in limits_by_side.items():
            if side not in self.arms:
                raise ValueError(f'Unknown arm side: {side}')
            self.arms[side].set_sdk_joint_limits(lower, upper)

    def _output(self, side, original=None, target=None, candidate=None, reason='tracking_lost'):
        accepted = self.accepted[side]
        position_error = rotation_error = None
        if target is not None:
            position_error = float(np.linalg.norm(np.array(target[:3]) - accepted['wrist'][:3]) * 1000)
            rotation_error = float(np.linalg.norm((Rotation.from_quat(target[3:]) *
                Rotation.from_quat(accepted['wrist'][3:]).inv()).as_rotvec()) * 180 / np.pi)
        return dict(raw=None if original is None else original['position_m'] + original['quaternion_xyzw'],
            target=target, joints_rad=list(accepted['joints_rad']), wrist=list(accepted['wrist']),
            converged=bool(candidate and candidate['converged']), holding=reason != 'following', reason=reason,
            attempted=candidate is not None, candidate=candidate,
            position_error_mm=position_error, rotation_error_deg=rotation_error,
            solve_ms=0 if candidate is None else candidate['solve_ms'],
            iterations=None if candidate is None else candidate.get('iterations'),
            candidate_position_error_mm=None if candidate is None else candidate.get('position_error_mm'),
            candidate_rotation_error_deg=None if candidate is None else candidate.get('rotation_error_deg'),
            failure_reason=reason if candidate is None and reason.startswith('ik_')
                else None if candidate is None else candidate.get('failure_reason'),
            seed_source=None if candidate is None else candidate.get('seed_source'),
            warm_start_used=None if candidate is None else candidate.get('warm_start_used'),
            database_fallback_used=None if candidate is None else candidate.get('database_fallback_used'),
            candidate_limit_joints=None if candidate is None else candidate.get('candidate_limit_joints'))

    def hold(self, message):
        # A temporary dropout does not change the reference frame or last accepted joint target.
        self.status = message + ' Holding; resumes automatically on fresh valid poses.'
        return {side:self._output(side, reason='stale_stream') for side in self.accepted} or None

    def process(self, packet):
        key = (packet['session'], packet.get('calibration_id', 0))
        if self.key is not None and key[0] != self.key[0]:
            self.key = None
            self.calibration = None
            self.accepted.clear()
        if packet.get('arm_switch') is not None and not packet['arm_switch']['run_requested']:
            self.status = 'B/off request: waiting for A. Dry run; no motor commands.'
            return {side:self._output(side, reason='disabled_request') for side in self.accepted} or None
        if not key[1] or key == self.blocked_key:
            self.status = 'Waiting for a new right-controller A calibration.'
            return None
        if key != self.key:
            anchors = packet['anchors']
            _, head_R = pose_arrays(anchors['head'])
            forward = head_R[:, 0]  # ROS +X is head forward; fix heading at A, never follow head afterward.
            if np.linalg.norm(forward[:2]) < 0.1:
                self.status = 'Look forward horizontally and press A again.'
                self.blocked_key = key
                return None
            yaw = math.atan2(forward[1], forward[0])
            self.axis_map = Rotation.from_euler('z', -yaw).as_matrix()
            self.anchors = {side: pose_arrays(anchors[side]) for side in self.arms}
            self.key = key
            self.accepted = {side:dict(joints_rad=[0.0]*7, wrist=pose_values(arm.home_p, arm.home_R))
                             for side, arm in self.arms.items()}
            self.calibration = dict(session=key[0], calibration_id=key[1], scale=self.scale,
                recenter_id=packet.get('recenter_id', 0),
                anchors=anchors, tracking_to_robot_rotation=self.axis_map.tolist(),
                orientation_mapping='head_yaw_relative_controller_delta',
                ik_solver='television_original_database_first',
                ik_execution='parallel_processes' if self.parallel is not None else 'sequential',
                homes={side: dict(joint_names=arm.joint_names, joints_rad=[0]*7,
                    wrist_frame=arm.frame, wrist=pose_values(arm.home_p, arm.home_R),
                    ik_database=dict(arm.database_info),
                    urdf=str(arm.path), urdf_sha256=hashlib.sha256(arm.path.read_bytes()).hexdigest())
                    for side, arm in self.arms.items()}, solver_core_sha256=CORE_AST_SHA256)
        result, targets, jobs = {}, {}, {}
        for side, arm in self.arms.items():
            original = packet['poses'][side]
            if not valid(original):
                result[side] = self._output(side, original)
                continue
            p, R = pose_arrays(packet['poses'][side])
            p0, R0 = self.anchors[side]
            target_p = arm.home_p + self.scale * (self.axis_map @ (p - p0))
            target_R = self.axis_map @ (R @ R0.T) @ self.axis_map.T @ arm.home_R
            target = pose_values(target_p, target_R)
            targets[side] = (original, target)
            jobs[side] = dict(position=target_p, rotation=target_R,
                previous_q=list(self.accepted[side]['joints_rad']),
                limits=(arm.arm.q_lower, arm.arm.q_upper))
        if self.parallel is not None:
            candidates = self.parallel.solve(jobs)  # Both jobs submitted before waiting for either.
        else:
            candidates = {}
            for side, job in jobs.items():
                try:
                    candidate = self.arms[side].solve(job['position'], job['rotation'], job['previous_q'])
                    candidates[side] = (candidate, None)
                except (np.linalg.LinAlgError, FloatingPointError, ValueError):
                    candidates[side] = (None, 'ik_error')
        for side, (candidate, error) in candidates.items():
            original, target = targets[side]
            if error:
                result[side] = self._output(side, original, target, reason=error)
                continue
            if candidate['converged']:
                self.accepted[side] = dict(joints_rad=list(candidate['joints_rad']), wrist=list(candidate['wrist']))
            result[side] = self._output(side, original, target, candidate,
                'following' if candidate['converged'] else 'ik_failed')
        self.status = ' | '.join(f"{side}: {'HOLD' if item['holding'] else 'FOLLOW'} ({item['reason']})"
                                for side, item in result.items()) + ' — dry run, no motor commands.'
        return result



POSE_FIELDS = ['x', 'y', 'z', 'qx', 'qy', 'qz', 'qw']
COMPARISON_FIELDS = ['elapsed_s', 'seq', 'calibration_id', 'side', 'tracking_valid', 'holding', 'reason', 'status']
COMPARISON_FIELDS += [f'{stage}_{k}' for stage in ('controller', 'target', 'wrist_fk') for k in POSE_FIELDS]
COMPARISON_FIELDS += [f'joint_{i+1}_rad' for i in range(7)]
COMPARISON_FIELDS += ['converged', 'position_error_mm', 'rotation_error_deg', 'solve_ms']
COMPARISON_FIELDS += list(CANDIDATE_FIELDS)
COMPARISON_FIELDS += list(CONTROL_NAMES) + ['a_press', 'b_press', 'run_requested']


def comparison_rows(packet, result, elapsed, status):
    """Two rows per packet: original controller pose, robot target, accepted IK, wrist FK."""
    rows = []
    for side in ('left', 'right'):
        pose = packet['poses'][side]
        row = dict(elapsed_s=elapsed, seq=packet['seq'], calibration_id=packet['calibration_id'],
                   side=side, tracking_valid=valid(pose), status=status)
        row.update(packet.get('controls', {}))
        row.update(packet.get('arm_switch') or {})
        row.update(zip(['controller_'+k for k in POSE_FIELDS], pose['position_m'] + pose['quaternion_xyzw']))
        if result is not None:
            arm = result[side]
            if arm['target'] is not None:
                row.update(zip(['target_'+k for k in POSE_FIELDS], arm['target']))
            row.update(zip(['wrist_fk_'+k for k in POSE_FIELDS], arm['wrist']))
            row.update(zip([f'joint_{i+1}_rad' for i in range(7)], arm['joints_rad']))
            row.update({k: arm[k] for k in ('holding', 'reason', 'converged',
                        'position_error_mm', 'rotation_error_deg', 'solve_ms',
                        'iterations', 'candidate_position_error_mm',
                        'candidate_rotation_error_deg', 'failure_reason',
                        'seed_source', 'warm_start_used', 'database_fallback_used', 'candidate_limit_joints')})
        rows.append(row)
    return rows


def capture(seconds=15, scale=1.7, wait_seconds=120, output_dir=None, on_update=None):
    """Wait for a new A, then record poses -> targets -> existing IK -> wrist FK. No motors."""
    mapper = QuestIK(scale)
    output_dir = Path(output_dir) if output_dir else Path(__file__).resolve().parent / 'recordings/quest_ik'
    folder = output_dir / f'test_{time.time_ns()}'
    folder.mkdir(parents=True)
    receiver = PoseReceiver().start(folder / 'pose_diagnostics.csv')
    started = last_id = first_key = latest_result = None
    calibrations, recorded_rows = [], []
    deadline = time.monotonic() + wait_seconds
    last_display = 0
    try:
        with (folder / 'comparison.csv').open('w', newline='') as file:
            writer = csv.DictWriter(file, fieldnames=COMPARISON_FIELDS)
            writer.writeheader()
            while started is None or time.monotonic() - started < seconds:
                now = time.monotonic()
                if started is None and now > deadline:
                    raise TimeoutError('No new A calibration received before timeout')
                state = receiver.snapshot()
                if state['error']:
                    raise RuntimeError(state['error'])
                packet = state['latest']
                if state['status'] != 'receiving':
                    latest_result = mapper.hold('Pose stream stale or absent.')
                elif packet and (packet['session'], packet['seq']) != last_id:
                    last_id = (packet['session'], packet['seq'])
                    key = (packet['session'], packet.get('calibration_id', 0))
                    if first_key is None:
                        first_key = key
                    if started is not None or (key[1] and key != first_key):
                        latest_result = mapper.process(packet)
                        if latest_result is not None and started is None:
                            started = now
                        if started is not None:
                            if mapper.calibration and (not calibrations or mapper.calibration != calibrations[-1]):
                                calibrations.append(mapper.calibration)
                                (folder / 'calibration.json').write_text(json.dumps(calibrations, indent=2))
                            rows = comparison_rows(packet, latest_result, now-started, mapper.status)
                            writer.writerows(rows)
                            recorded_rows.extend(rows)
                if on_update and now - last_display >= 0.25:
                    remaining = 'Waiting for A' if started is None else f'{max(0, seconds-(now-started)):.1f}s remaining'
                    text = remaining + ' | ' + mapper.status + '\n'
                    text += format_controls(packet) if packet and state['status'] == 'receiving' else 'Inputs unavailable'
                    for side, arm in (latest_result or {}).items():
                        text += f"\n{side}: {arm['reason']}"
                        for label, key in [('Controller', 'raw'), ('Target', 'target'), ('IK rad', 'joints_rad'), ('Wrist FK', 'wrist')]:
                            text += f"\n{label}: {None if arm[key] is None else np.round(arm[key], 4)}"
                    on_update(text)
                    last_display = now
                time.sleep(0.002)
    finally:
        receiver.stop()

    # Summarize the same rows that were written; do not maintain a second set of counters in the receive loop.
    summary = dict(duration_s=seconds, processed_packets=len(recorded_rows)//2, scale=scale,
                   folder=str(folder.resolve()), calibration_count=len(calibrations), arms={},
                   latest=latest_result, network=receiver.snapshot())
    for side in mapper.arms:
        rows = [row for row in recorded_rows if row['side'] == side]
        stats = dict(rows=len(rows), solved=sum(row.get('reason') in ('following', 'ik_failed') for row in rows),
                     converged=sum(bool(row.get('converged')) for row in rows))
        for field, name in [('position_error_mm', 'position_errors_mm'),
                            ('rotation_error_deg', 'rotation_errors_deg'), ('solve_ms', 'solve_ms')]:
            values = [row[field] for row in rows if row.get(field) is not None]
            stats[name] = (dict(mean=float(np.mean(values)), p95=float(np.percentile(values, 95)), max=max(values))
                           if values else None)
        summary['arms'][side] = stats
    (folder / 'summary.json').write_text(json.dumps(summary, indent=2))
    (Path(__file__).resolve().parent / 'quest_ik_last_summary.json').write_text(json.dumps(summary, indent=2))
    print(f'Saved {seconds}-second comparison:', folder.resolve())
    return summary
