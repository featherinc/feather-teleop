"""Bounded, nonblocking CSV logging for time-sensitive receive/control loops."""
from __future__ import annotations

import csv
from pathlib import Path
import queue
import threading
import time


class AsyncCSVWriter:
    """Write rows on a daemon thread; discard excess logging instead of stalling callers.

    The header is created synchronously so a bad path fails at construction. Rows
    accepted by ``writerow`` are drained by ``close`` up to its timeout. An I/O
    failure is reported in ``stats()['error']`` and later rows are dropped.
    """

    def __init__(self, path, fieldnames, *, max_rows=2048, flush_interval_s=0.5):
        if max_rows < 1 or flush_interval_s <= 0:
            raise ValueError("max_rows and flush_interval_s must be positive")
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._file = self.path.open("x", newline="", encoding="utf-8")
        try:
            self._writer = csv.DictWriter(self._file, fieldnames=fieldnames)
            self._writer.writeheader()
            self._file.flush()
        except Exception:
            self._file.close()
            raise
        self._rows = queue.Queue(maxsize=max_rows)
        self._lock = threading.Lock()
        self._closing = threading.Event()
        self._flush = threading.Event()
        self._flush_interval_s = flush_interval_s
        self._written = self._dropped = 0
        self._error = None
        self._thread = threading.Thread(target=self._run, name="quest-csv-writer", daemon=True)
        self._thread.start()

    def writerow(self, row):
        """Queue one row without waiting; return False when it could not be logged."""
        with self._lock:
            if self._closing.is_set() or self._error is not None:
                self._dropped += 1
                return False
            try:
                self._rows.put_nowait(dict(row))
            except queue.Full:
                self._dropped += 1
                return False
            return True

    def writerows(self, rows):
        return sum(self.writerow(row) for row in rows)

    def flush(self):
        """Ask the writer thread to flush soon without waiting for disk I/O."""
        with self._lock:
            if self._closing.is_set() or self._error is not None:
                return False
            self._flush.set()
            return True

    def stats(self):
        with self._lock:
            return dict(queued=self._rows.qsize(), written=self._written,
                        dropped=self._dropped, error=self._error,
                        closing=self._closing.is_set(), alive=self._thread.is_alive())

    def close(self, timeout=2):
        """Drain accepted rows for at most ``timeout`` seconds; report completion."""
        with self._lock:
            self._closing.set()
            self._flush.set()
        self._thread.join(timeout=max(0, timeout))
        if self._thread.is_alive():
            with self._lock:
                if self._error is None:
                    self._error = "CSV drain timed out; queued rows may not be written"
            return False
        return self._error is None

    def _run(self):
        row = None
        try:
            last_flush = time.monotonic()
            while not self._closing.is_set() or not self._rows.empty():
                try:
                    row = self._rows.get(timeout=min(self._flush_interval_s, 0.05))
                except queue.Empty:
                    row = None
                if row is not None:
                    self._writer.writerow(row)
                    with self._lock:
                        self._written += 1
                    row = None
                now = time.monotonic()
                if self._flush.is_set() or now - last_flush >= self._flush_interval_s:
                    self._file.flush()
                    self._flush.clear()
                    last_flush = now
            self._file.flush()
        except Exception as exc:
            with self._lock:
                self._error = repr(exc)
                if row is not None:
                    self._dropped += 1
                while True:
                    try:
                        self._rows.get_nowait()
                    except queue.Empty:
                        break
                    self._dropped += 1
            # No caller waits on the queue, so unfinished tasks need no accounting.
        finally:
            try:
                self._file.close()
            except Exception as exc:
                with self._lock:
                    if self._error is None:
                        self._error = repr(exc)
