# Recorded TeleVision IK seeds

`og_joint_samples.npz` schema 2 contains 619 unique original recorded poses:
311 left rows from `TeleVision/teleop/ik_database/combined.pkl`, followed by
308 right rows from `TeleVision/teleop/ik_database/combined_right.pkl`.
The first 311 numeric rows are preserved byte-for-byte. Right rows are stored
with every joint negated to the existing canonical left sign convention.
No random or interpolated configurations are added.

Source file SHA-256:
- left: `80d282aa3852c6055384db101cd308f2b1eb0f104a256b0f8d13b94c5083abcc`
- right: `8538a7eeedd812e68ead9f7223e8816e7bd426aec5cd2ff14a8a656afa847537`

The recorded joint order is Sp, Sr, Sw, Ep, Ww, Wp, Wr for each source arm.
The original TeleVision `ikdb_grav_comp.py` records captured joint positions in
this order. The adapter reorders them by joint name into the current URDF,
which places Wr before Wp. The right adapter negates canonical rows, recovering
the original right recording angles exactly for the appended rows.
This follows the original TeleVision sign convention; the current URDF has
asymmetries, so it is not a claim of exact geometric left/right symmetry.

The NPZ stores numeric arrays only. Runtime uses `allow_pickle=False` and never
unpickles source recordings. `source_paths`, `source_sha256s`, `source_sides`,
`source_counts`, and `source_q_sha256s` identify both original sources.
`row_source_side` and `row_source_index` identify every row within its original
recording. Reconstruction hashes validate canonicalization. The original
`source_sha256` field identifies the primary left source for compatibility;
`database_info.sources` reports both sources and their retained/excluded counts.
Schema 1 left-only files remain supported.

Samples with shoulder or elbow angles outside effective URDF/SDK limits are
excluded. For retained samples, only out-of-range wrists are clipped to their
nearest effective limit. FK position and orientation are rebuilt with each
current arm URDF and wrist frame; original recorded Cartesian labels are not
reused. Original NPZ angles stay intact. One existing zero-joint home seed is
added for A-neutral startup, and fewer than five compatible recorded rows is
an error. Lookup rebuilds occur only when effective limits change.

Under the 2026-10-03 runtime configuration intersected with the current URDF,
both arms retain 583 original rows, exclude 36, and use 584 seeds including
home. Left has 286 unchanged and 297 wrist-adjusted rows; right has 322 unchanged
and 261 wrist-adjusted rows. Session calibration metadata reports actual counts.
The solver math and original all-joint right sign convention are unchanged.
