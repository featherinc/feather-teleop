"""Read Albert's existing declarations using the Teensy SDK's config types.

Only configuration objects are constructed here. No robot, transport, logging,
calibration, or firmware process is started, and source config files are unchanged.
"""
from __future__ import annotations

import ast
import math
from pathlib import Path
from types import SimpleNamespace


SYSTEM_COMMS_CONFIG = Path('/feathersys/configs/infra/comms_manager_conf.py')


def _declarations(path, symbols, result_name):
    """Evaluate local config declarations with explicit SDK symbols, not old imports."""
    path = Path(path)
    tree = ast.parse(path.read_text(encoding='utf-8'), filename=str(path))
    tree.body = [node for node in tree.body if not isinstance(node, (ast.Import, ast.ImportFrom))]
    namespace = dict(symbols, __file__=str(path), __name__='quest_local_config')
    exec(compile(tree, str(path), 'exec'), namespace)
    return namespace[result_name]


def read_hand_configs(config_path, sides=('left', 'right')):
    from quest_sdk_hands import HandCanConfig
    if len(set(sides)) != len(sides) or set(sides) - {'left', 'right'}:
        raise ValueError('Hand sides must be unique left/right values')
    if not sides:
        return {}
    declarations = _declarations(Path(config_path).parent / 'systems/manipulation_system_conf.py', {
        'RealHandManipulationSystemConfig': SimpleNamespace,
        'RealHandConfig': HandCanConfig,
        'RealHandVersion': SimpleNamespace(L6='L6', O6='O6'),
    }, 'manipulation_system_config')
    return {side: getattr(declarations, side + '_hand') for side in sides}


def _native_symbols():
    from feathersdk.robot.robot import FeatherRobotConfig
    from feathersdk.robot.comms import CommsManagerConfig
    from feathersdk.logging import LoggingConfig, INFO, DEBUG, DISABLE_TAGS
    from feathersdk.robot.services import DataMonitorServiceConfig
    from feathersdk.robot.actuator_systems import (
        ArmsSystemConfig, Robstride7MArmConfig, SafeStopPolicy,
        LinearEZMotionTorsoSystemConfig, TwoDOFRobstrideNeckSystemConfig,
        ThreeWheelHolonomicRobstrideNavigationSystemConfig,
    )
    from feathersdk.robot.actuators.robstride import (
        RobstrideMotorConfig, RobVersion, RobstrideCalibrationConfig,
    )
    from feathersdk.robot.actuators.ezmotion import EZMotionMotorConfig, EC_PER_ROT
    from feathersdk.quill_defs.python_qdefs.robstride_qdef import rob_kp_lim, rob_kd_lim

    def factory(cls, retired=(), renamed=None):
        def build(**kwargs):
            for old, new in (renamed or {}).items():
                if old in kwargs:
                    kwargs[new] = kwargs.pop(old)
            unknown = set(kwargs) - set(cls.model_fields)
            if unknown - set(retired):
                raise ValueError(f'{cls.__name__}: unmapped config fields {sorted(unknown - set(retired))}')
            return cls(**{key: value for key, value in kwargs.items() if key not in retired})
        return build

    def motor_config(**kwargs):
        # Validate every native field, then use the encoder's per-model gain
        # limits. The generic config cap of 100 rejects the existing RS03/04
        # KP=300 although their CAN encoder supports KP up to 5000.
        kp = float(kwargs.pop('default_op_kp', 8.0))
        kd = float(kwargs.pop('default_op_kd', 2.0))
        config = factory(RobstrideMotorConfig, retired=(
            'compliance_mode_torque_threshold', 'compliance_mode_update_dx',
            'compliance_mode_max_velocity', 'compliance_mode_max_acceleration'))(
                **kwargs, default_op_kp=0.0, default_op_kd=0.0)
        if (not math.isfinite(kp) or not math.isfinite(kd) or
                not 0 <= kp <= rob_kp_lim[config.version] or not 0 <= kd <= rob_kd_lim[config.version]):
            raise ValueError(f'{config.name}: tuned KP/KD exceeds {config.version.name} CAN limits')
        # Configurable requires this exact native class, rather than a subclass.
        return config.model_copy(update={'default_op_kp': kp, 'default_op_kd': kd}, deep=True)

    return dict(
        Path=Path, Version=str, Literal=__import__('typing').Literal,
        NumericRange=lambda low, high: (low, high), deg2rad=math.radians,
        pi=math.pi, tau=math.tau, GB=1024 ** 3,
        SafeStopPolicy=SimpleNamespace(
            # Both policies leave SDK safe-stop motion disabled.
            DO_NOTHING=SafeStopPolicy.CANNOT_ENTER_SAFE_STOP,
            CANNOT_ENTER_SAFE_STOP=SafeStopPolicy.CANNOT_ENTER_SAFE_STOP,
        ),
        RobstrideVersion=RobVersion, RobVersion=RobVersion,
        RobstrideMotorConfig=motor_config,
        RobstrideCalibrationConfig=factory(RobstrideCalibrationConfig),
        ArmsSystemConfig=factory(ArmsSystemConfig),
        Robstride7MArmConfig=factory(Robstride7MArmConfig, retired=('home_position_tolerance',)),
        TorsoSystemConfig=factory(LinearEZMotionTorsoSystemConfig),
        NeckSystemConfig=factory(TwoDOFRobstrideNeckSystemConfig),
        NavigationSystemConfig=factory(ThreeWheelHolonomicRobstrideNavigationSystemConfig,
            retired=('rotate_in_place_angles', 'rotate_in_place_directions')),
        EZMotionMotorConfig=factory(EZMotionMotorConfig), EC_PER_ROT=EC_PER_ROT,
        LoggingConfig=factory(LoggingConfig), INFO=INFO, DEBUG=DEBUG, DISABLE_TAGS=DISABLE_TAGS,
        CommsManagerConfig=factory(CommsManagerConfig,
            retired=('max_ip_rate', 'ip_leniency', 'show_all_sdo_errors')),
        DataMonitorServiceConfig=factory(DataMonitorServiceConfig,
            renamed={'can_monitor_enabled': 'candump_enabled'}),
        FeatherRobotConfig=factory(FeatherRobotConfig, retired=('enable_cans_during_find',)),
    )


def load_branch_config(config_path, urdf_path, *, include_torso=False,
                       include_navigation=False, include_neck=False, hand_sides=(),
                       comms_config_path=None):
    """Retain local actuator tuning and the installed system's transport config.

    ``comms_config_path`` explicitly selects a different transport declaration
    for offline fixtures or another installation. There is no default fallback
    to the older Albert declaration, which omits the USB-CAN emulator setting.
    """
    selected_comms = SYSTEM_COMMS_CONFIG if comms_config_path is None else Path(comms_config_path)
    try:
        selected_comms = selected_comms.resolve(strict=True)
    except FileNotFoundError as exc:
        raise FileNotFoundError(f'Selected SDK communications config is missing: {selected_comms}. '
                                'Pass comms_config_path to select an existing declaration.') from exc
    if not selected_comms.is_file():
        raise FileNotFoundError(f'Selected SDK communications config must be a file: {selected_comms}')
    config_path = Path(config_path).resolve(strict=True)
    urdf_path = Path(urdf_path).resolve(strict=True)
    symbols = _native_symbols()
    # Validate hand model declarations before any subsequent hardware initialization.
    read_hand_configs(config_path, hand_sides)
    specs = {
        'logging_config': ('infra/logging_conf.py', True),
        'data_monitor_service_config': ('infra/data_monitor_service_conf.py', True),
        'arms_system_config': ('systems/arms_system_conf.py', True),
        'torso_system_config': ('systems/torso_system_conf.py', include_torso),
        'neck_system_config': ('systems/neck_system_conf.py', include_neck),
        'navigation_system_config': ('systems/navigation_system_conf.py', include_navigation),
    }
    for key, (relative, selected) in specs.items():
        symbols[key] = _declarations(config_path.parent / relative, symbols, key) if selected else None
    symbols['comms_manager_config'] = _declarations(selected_comms, symbols, 'comms_manager_config')
    # Native RealHand is unfinished on this branch; local L6 transport attaches
    # separately to the existing comms manager and never substitutes the O6 model.
    symbols.update(manipulation_system_config=None, battery_service_config=None,
                   export_config=lambda config: None, set_root_feather_path=lambda path: None)
    config = _declarations(config_path, symbols, 'robot_config')
    updates = dict(urdf_path=urdf_path, set_signal_handlers=False,
                   manipulation_system_config=None, battery_service_config=None,
                   camera_service_config=None, odometry_service_config=None)
    if hand_sides:
        monitor = config.data_monitor_service_config
        if monitor is None or config.logging_config is None:
            raise ValueError('L6 reply transport requires SDK data monitoring and logging')
        updates['data_monitor_service_config'] = monitor.model_copy(update={'candump_enabled': True}, deep=True)
    return config.model_copy(update=updates, deep=True)
