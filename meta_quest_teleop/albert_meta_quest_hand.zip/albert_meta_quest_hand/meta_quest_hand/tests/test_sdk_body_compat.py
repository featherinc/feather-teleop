"""Offline SDK boundary checks, using real branch navigation method bodies."""

import ast
import copy
import math
from pathlib import Path
import tempfile
import threading
from types import MethodType, SimpleNamespace
import unittest

from quest_sdk_compat import (LegacyNavigation, motor_position_param,
                              motor_feedback_age_s, read_navigation_rotation_maps)


PROJECT = Path(__file__).resolve().parents[1]
REPO = Path(__file__).resolve().parents[5]
SDK_NAV = REPO / 'feathersdk/src/feathersdk/robot/actuator_systems/navigation_system.py'
USER_NAV = PROJECT.parent / 'configs/systems/navigation_system_conf.py'
ANGLES = {'turning_center': -math.pi / 2, 'turning_right': -math.pi / 4,
          'turning_left': math.pi / 4}
DIRECTIONS = {'drive_center': -1, 'drive_right': 1, 'drive_left': -1}
# Selected Albert URDF mesh/cache centers, ordered center, right, left. The
# rear module is closer to the chassis center than the two front modules;
# native body-velocity IK must account for all three positions independently.
WHEEL_POSITIONS = [(-.12774287033081055, -.010949900627136623),
                   (.1745, -.1854499053955078), (.1745, .1854499053955078)]


def assert_in_range(value, limits, obj_name):
    if not math.isfinite(value) or not limits[0] <= value <= limits[1]:
        raise ValueError(f'{obj_name} exceeds configured limits')


def branch_navigation():
    """Compile actual branch IK/dispatch/polling, with no SDK imports or IO."""
    tree = ast.parse(SDK_NAV.read_text())
    cls = next(node for node in tree.body if isinstance(node, ast.ClassDef)
               and node.name == 'ThreeWheelHolonomicRobstrideNavigationSystem')
    names = {'_set_new_angles_and_speeds', '_thread_step', 'set_velocity',
             'get_strict_directions', 'set_strict_directions'}
    methods = [copy.deepcopy(node) for node in cls.body
               if isinstance(node, ast.FunctionDef) and node.name in names]
    if {node.name for node in methods} != names:
        raise AssertionError('Branch navigation integration changed')
    ik_path = SDK_NAV.with_name('navigation_ik.py')
    ik_tree = ast.parse(ik_path.read_text())
    ik_nodes = []
    for node in ik_tree.body:
        if isinstance(node, (ast.FunctionDef, ast.Assign)):
            ik_nodes.append(copy.deepcopy(node))
        elif isinstance(node, ast.AnnAssign):
            ik_nodes.append(ast.Assign(targets=[copy.deepcopy(node.target)],
                                       value=copy.deepcopy(node.value)))
    for node in ik_nodes + methods:
        for child in ast.walk(node):
            if isinstance(child, ast.FunctionDef):
                child.returns = None
                for arg in child.args.posonlyargs + child.args.args + child.args.kwonlyargs:
                    arg.annotation = None
    code = ast.fix_missing_locations(ast.Module(body=ik_nodes + methods, type_ignores=[]))
    namespace = {'math': math, 'value_in_range': lambda value, limits: limits[0] <= value <= limits[1],
                 'assert_in_range': assert_in_range, 'debug': lambda *args: None}
    exec(compile(code, str(SDK_NAV), 'exec'), namespace)
    events = []

    class Motor:
        def __init__(self, name):
            self.config = SimpleNamespace(name=name, max_velocity=10.47,
                                          angle_range=(-math.radians(100), math.radians(100)))
            self.PARAMS = SimpleNamespace(FB_MODE='mode', FB_POSITION='position')
            self.initialized = True
            self.actual = 0.0

        def set_target_position(self, value, block):
            events.append(('position', self.config.name, value, block))

        def set_target_velocity(self, value, block):
            events.append(('velocity', self.config.name, value, block))

        def trigger_feedback_frame(self, **kwargs):
            pass

        def check_warn_on_feedback_delay(self, param):
            pass

        def get_param(self, param, default=None):
            return self.actual if self.actual is not None else default

    nav = SimpleNamespace(config=SimpleNamespace(module_name='navigation_system',
                           rotation_tolerance=.04, operating_frequency=30,
                           wheel_radius=.06, wheel_positions=list(WHEEL_POSITIONS)),
                          turning_motors=[Motor(name) for name in ANGLES],
                          drive_motors=[Motor(name) for name in DIRECTIONS],
                          _target_angles={name: 0.0 for name in ANGLES},
                          _target_velocities={name: 0.0 for name in DIRECTIONS},
                          _enabled=True, _strict_directions=True, is_initialized=True,
                          _reached_target_positions=True,
                          _target_positions_thread_lock=threading.Lock())
    for name in names:
        setattr(nav, name, MethodType(namespace[name], nav))
    return nav, events


class NativeNavigationTests(unittest.TestCase):
    def setUp(self):
        self.nav, self.events = branch_navigation()

    def reach_steering(self):
        for motor in self.nav.turning_motors:
            motor.actual = self.nav._target_angles[motor.config.name]
        self.nav._thread_step()

    def assert_wheel_vectors(self, requested, scale=1.):
        vx, vy, omega = requested
        for turn, drive, (x, y) in zip(self.nav.turning_motors, self.nav.drive_motors,
                                      WHEEL_POSITIONS):
            with self.subTest(wheel=drive.config.name):
                angle = self.nav._target_angles[turn.config.name]
                speed = self.nav._target_velocities[drive.config.name] * .06
                # Reconstruct physical wheel velocity from the commanded
                # clockwise steering and signed speed, independent of SDK IK.
                self.assertAlmostEqual(speed * math.cos(angle), (vx - omega*y) * scale)
                self.assertAlmostEqual(-speed * math.sin(angle), (vy + omega*x) * scale)
                self.assertLessEqual(abs(angle), math.pi/2 + 1e-9)
                self.assertLessEqual(abs(self.nav._target_velocities[drive.config.name]),
                                     drive.config.max_velocity + 1e-9)

    def test_point_two_meters_per_second_becomes_wheel_rad_per_second(self):
        self.assertEqual(self.events, [])
        self.nav.set_velocity(.2, 0., 0.)
        self.assertEqual(self.nav._target_angles, {name: 0. for name in ANGLES})
        for velocity in self.nav._target_velocities.values():
            self.assertAlmostEqual(velocity, 10./3.)
        self.assertEqual(len([event for event in self.events if event[0] == 'velocity']), 3)
        self.assert_wheel_vectors((.2,0.,0.))

    def test_backward_and_both_strafes_use_native_folding_and_signed_wheels(self):
        for requested in ((-.2,0.,0.), (0.,.2,0.), (0.,-.2,0.), (.1,-.1,0.)):
            with self.subTest(requested=requested):
                self.nav, self.events = branch_navigation()
                self.nav.set_velocity(*requested)
                self.assert_wheel_vectors(requested)
                if requested[0] < 0:
                    for angle in self.nav._target_angles.values():
                        self.assertAlmostEqual(angle, 0.)
                    self.assertTrue(all(value < 0 for value in self.nav._target_velocities.values()))

    def test_yaw_both_signs_uses_actual_unequal_module_positions(self):
        for omega in (-1.,1.):
            with self.subTest(omega=omega):
                self.nav, self.events = branch_navigation()
                self.nav.set_velocity(0.,0.,omega)
                self.assert_wheel_vectors((0.,0.,omega))
                speeds = [abs(self.nav._target_velocities[motor.config.name])
                          for motor in self.nav.drive_motors]
                self.assertLess(speeds[0], speeds[1])
                self.assertAlmostEqual(speeds[1], speeds[2])
                # The rear center is slightly off-axis; its native steering
                # must come from geometry rather than the retired +/-90 map.
                self.assertLess(abs(self.nav._target_angles['turning_center']), math.pi/2)

    def test_strict_steering_holds_drive_until_feedback_arrives(self):
        self.assertTrue(self.nav.get_strict_directions())
        self.nav.set_velocity(0.,.2,0.)
        self.assertFalse(self.nav._reached_target_positions)
        self.assertEqual([event[2] for event in self.events if event[0] == 'velocity'], [0.,0.,0.])
        self.nav._thread_step()
        self.assertFalse(self.nav._reached_target_positions)
        self.reach_steering()
        self.assertTrue(self.nav._reached_target_positions)
        for velocity in [event[2] for event in self.events if event[0] == 'velocity'][-3:]:
            self.assertAlmostEqual(velocity, 10./3.)

    def test_zero_twist_retains_steering_and_cancels_pending_motion(self):
        self.nav.set_velocity(0.,0.,1.)
        targets = dict(self.nav._target_angles)
        self.nav.set_velocity(0.,0.,0.)
        self.assertEqual(self.nav._target_angles, targets)
        self.assertEqual(self.nav._target_velocities, {name: 0. for name in DIRECTIONS})
        self.reach_steering()
        self.assertEqual([event[2] for event in self.events if event[0] == 'velocity'][-3:], [0.,0.,0.])

    def test_uniform_wheel_limit_scaling_preserves_mixed_body_twist(self):
        requested = (.7,-.2,2.)
        limits = (2.,4.,3.)
        for motor, limit in zip(self.nav.drive_motors, limits):
            motor.config.max_velocity = limit
        vx, vy, omega = requested
        requested_speeds = [math.hypot(vx-omega*y, vy+omega*x)/.06 for x,y in WHEEL_POSITIONS]
        scale = min(1., *(limit/speed for limit,speed in zip(limits,requested_speeds)))
        self.assertLess(scale, 1.)
        self.nav.set_velocity(*requested)
        self.assert_wheel_vectors(requested, scale)
        self.assertTrue(any(math.isclose(abs(self.nav._target_velocities[m.config.name]), limit)
                            for m,limit in zip(self.nav.drive_motors,limits)))

    def test_orient_only_uses_native_headings_but_zero_drive(self):
        self.nav.set_velocity(.2,-.2,0.,orient_only=True)
        self.assertEqual(self.nav._target_velocities, {name: 0. for name in DIRECTIONS})
        for angle in self.nav._target_angles.values():
            self.assertAlmostEqual(angle, math.pi/4)

    def test_continuous_identical_twist_recovers_speed_as_steering_aligns(self):
        self.nav.set_strict_directions(False)
        self.assertFalse(self.nav.get_strict_directions())
        self.events.clear()
        self.nav.set_velocity(0.,.2,0.)
        targets=dict(self.nav._target_angles)
        self.assertTrue(self.nav._reached_target_positions)
        for speed in self.nav._target_velocities.values():
            self.assertAlmostEqual(speed,0.)
        for fraction,expected in ((.5,(10./3.)/math.sqrt(2)),(1.,10./3.)):
            for motor in self.nav.turning_motors:
                motor.actual=targets[motor.config.name]*fraction
            before=dict(self.nav._target_velocities)
            self.events.clear()
            self.nav._thread_step()
            # Encoder polling alone does not refresh the projection. The
            # notebook must resubmit the held body twist on each active tick.
            self.assertEqual(self.nav._target_velocities,before)
            self.assertEqual(self.events,[])
            self.nav.set_velocity(0.,.2,0.)
            self.assertEqual(self.nav._target_angles,targets)
            for speed in self.nav._target_velocities.values():
                self.assertAlmostEqual(speed,expected)
            self.assertEqual(len([event for event in self.events if event[0]=='velocity']),3)
        self.assert_wheel_vectors((0.,.2,0.))

    def test_non_strict_stop_retains_heading_and_subsequent_polling_stays_zero(self):
        self.nav.set_strict_directions(False)
        self.nav.set_velocity(.1,.1,0.)
        self.reach_steering()
        self.nav.set_velocity(.1,.1,0.)
        targets=dict(self.nav._target_angles)
        self.assertTrue(any(value for value in self.nav._target_velocities.values()))
        self.nav.set_velocity(0.,0.,0.)
        self.assertEqual(self.nav._target_angles,targets)
        self.assertEqual(self.nav._target_velocities,{name:0. for name in DIRECTIONS})
        self.events.clear()
        for _ in range(3):self.nav._thread_step()
        self.assertEqual(self.events,[])
        self.assertEqual(self.nav._target_velocities,{name:0. for name in DIRECTIONS})

    def test_continuous_steering_keeps_common_wheel_limit_scaling_when_aligned(self):
        self.nav.set_strict_directions(False)
        requested=(.7,-.2,2.)
        limits=(2.,4.,3.)
        for motor,limit in zip(self.nav.drive_motors,limits):motor.config.max_velocity=limit
        self.nav.set_velocity(*requested,orient_only=True)
        self.reach_steering()
        vx,vy,omega=requested
        speeds=[math.hypot(vx-omega*y,vy+omega*x)/.06 for x,y in WHEEL_POSITIONS]
        scale=min(1.,*(limit/speed for limit,speed in zip(limits,speeds)))
        for _ in range(3):
            self.nav.set_velocity(*requested)
            self.assert_wheel_vectors(requested,scale)
        self.assertTrue(any(math.isclose(abs(self.nav._target_velocities[m.config.name]),limit)
                            for m,limit in zip(self.nav.drive_motors,limits)))


class FeedbackTests(unittest.TestCase):
    def motor(self, generation, stamp):
        reads = []
        def timestamp(param, default):
            reads.append(param)
            return stamp
        motor = SimpleNamespace(telemetry=SimpleNamespace(get_latest_timestamp=timestamp))
        if generation == 'branch':
            motor.PARAMS = SimpleNamespace(FB_POSITION='new-position')
        else:
            motor.PARAM_SET = SimpleNamespace(mech_pos='old-position')
        return motor, reads

    def test_branch_seconds_and_legacy_nanoseconds(self):
        for generation, stamp in [('branch', 99.85), ('legacy', 99.85e9)]:
            motor, reads = self.motor(generation, stamp)
            self.assertAlmostEqual(motor_feedback_age_s(motor, 100), .15)
            self.assertEqual(reads, [motor_position_param(motor)])

    def test_units_follow_api_even_for_atypical_magnitudes(self):
        branch, _ = self.motor('branch', 1e11)
        legacy, _ = self.motor('legacy', 1)
        self.assertEqual(motor_feedback_age_s(branch, 100), 100 - 1e11)
        self.assertAlmostEqual(motor_feedback_age_s(legacy, 100), 100 - 1e-9)

    def test_fresh_legacy_timestamp_keeps_original_nanosecond_arithmetic(self):
        now = 12345.38
        stamp = int(now * 1e9)
        fresh, _ = self.motor('legacy', stamp)
        self.assertEqual(motor_feedback_age_s(fresh, now), 0.0)
        future, _ = self.motor('legacy', stamp + 1)
        self.assertLess(motor_feedback_age_s(future, now), 0.0)
        recent, _ = self.motor('legacy', stamp - 1_000_000)
        self.assertAlmostEqual(motor_feedback_age_s(recent, now), .001)

    def test_missing_and_nonfinite_feedback_are_not_fresh(self):
        for stamp in (None, math.nan, math.inf, 'invalid'):
            motor, _ = self.motor('branch', stamp)
            self.assertEqual(motor_feedback_age_s(motor, 100), math.inf)
        future, _ = self.motor('branch', 100.01)
        self.assertLess(motor_feedback_age_s(future, 100), 0)

    def test_unknown_api_and_nonfinite_time_fail(self):
        with self.assertRaisesRegex(RuntimeError, 'position-feedback API'):
            motor_position_param(SimpleNamespace())
        malformed = SimpleNamespace(PARAMS=SimpleNamespace(), PARAM_SET=SimpleNamespace(mech_pos='old'))
        with self.assertRaisesRegex(RuntimeError, 'PARAMS.FB_POSITION'):
            motor_position_param(malformed)
        motor, _ = self.motor('branch', 100)
        with self.assertRaisesRegex(ValueError, 'finite'):
            motor_feedback_age_s(motor, math.nan)


class NavigationTests(unittest.TestCase):
    def setUp(self):
        self.nav, self.events = branch_navigation()
        self.adapter = LegacyNavigation(self.nav, rotate_in_place_angles=ANGLES,
                                        rotate_in_place_directions=DIRECTIONS)

    def reach_steering(self):
        for motor in self.nav.turning_motors:
            motor.actual = self.nav._target_angles[motor.config.name]
        self.nav._thread_step()

    def test_construction_sends_nothing_and_exposes_original_maps(self):
        self.assertEqual(self.events, [])
        self.assertEqual(dict(self.adapter.config.rotate_in_place_angles), ANGLES)
        self.assertEqual(dict(self.adapter.config.rotate_in_place_directions), DIRECTIONS)
        self.assertEqual(self.adapter.config.rotation_tolerance, .04)
        self.assertIs(self.adapter.drive_motors, self.nav.drive_motors)

    def test_user_rotation_config_is_read_without_execution(self):
        angles, directions = read_navigation_rotation_maps(USER_NAV)
        self.assertEqual(angles, ANGLES)
        self.assertEqual(directions, DIRECTIONS)
        adapter = LegacyNavigation(self.nav, config_path=USER_NAV)
        self.assertEqual(dict(adapter.config.rotate_in_place_angles), ANGLES)
        self.assertEqual(self.events, [])

    def test_translation_preserves_all_headings_and_wheel_rad_per_second(self):
        for degrees in range(-90, 91, 5):
            for speed in (-3.0, 3.0):
                angle = math.radians(degrees)
                self.adapter.orient_and_move(angle, speed)
                self.assertEqual(self.nav._target_angles, {name: angle for name in ANGLES})
                self.assertEqual(self.nav._target_velocities, {name: speed for name in DIRECTIONS})

    def test_rotation_preserves_exact_user_wheel_targets_both_signs(self):
        for speed in (-3.0, 3.0):
            self.adapter.rotate_in_place(speed)
            self.assertEqual(self.nav._target_angles, ANGLES)
            self.assertEqual(self.nav._target_velocities,
                             {name: speed * direction for name, direction in DIRECTIONS.items()})

    def test_actual_branch_gates_drives_until_steering_arrives(self):
        self.adapter.orient_and_move(.4, 3)
        velocities = [item[2] for item in self.events if item[0] == 'velocity']
        self.assertEqual(velocities, [0, 0, 0])
        self.assertFalse(self.nav._reached_target_positions)
        self.nav._thread_step()
        self.assertFalse(self.nav._reached_target_positions)
        self.reach_steering()
        self.assertTrue(self.nav._reached_target_positions)
        self.assertEqual([item[2] for item in self.events if item[0] == 'velocity'][-3:], [3, 3, 3])

    def test_stop_cancels_pending_drive_and_keeps_steering_target(self):
        self.adapter.rotate_in_place(3)
        self.adapter.set_speed(0)
        self.assertEqual(self.nav._target_angles, ANGLES)
        self.assertEqual(self.nav._target_velocities, {name: 0 for name in DIRECTIONS})
        self.reach_steering()
        self.assertEqual([item[2] for item in self.events if item[0] == 'velocity'][-3:], [0, 0, 0])

    def test_nonzero_set_speed_matches_historical_uniform_wheels(self):
        self.adapter.rotate_in_place(3)
        self.adapter.set_speed(-2)
        self.assertEqual(self.nav._target_angles, ANGLES)
        self.assertEqual(self.nav._target_velocities, {name: -2 for name in DIRECTIONS})

    def test_opposite_sideways_command_reverses_drive_without_steering_sweep(self):
        self.adapter.orient_and_move(-math.pi / 2, 3)
        self.reach_steering()
        self.events.clear()
        self.adapter.orient_and_move(math.pi / 2, 3)
        self.assertEqual(self.nav._target_angles, {name: -math.pi / 2 for name in ANGLES})
        self.assertEqual(self.nav._target_velocities, {name: -3 for name in DIRECTIONS})
        self.assertEqual([item[2] for item in self.events if item[0] == 'position'], [-math.pi / 2] * 3)
        self.assertEqual([item[2] for item in self.events if item[0] == 'velocity'], [-3] * 3)

    def test_actual_branch_limits_and_disabled_state_are_retained(self):
        for action in (lambda: self.adapter.orient_and_move(math.radians(101), 3),
                       lambda: self.adapter.orient_and_move(0, 11),
                       lambda: self.adapter.rotate_in_place(11)):
            with self.assertRaises(ValueError):
                action()
        self.assertEqual(self.events, [])
        self.nav._enabled = False
        with self.assertRaisesRegex(RuntimeError, 'not enabled'):
            self.adapter.set_speed(0)

    def test_unsupported_private_signature_and_incomplete_maps_fail_before_commands(self):
        self.nav._set_new_angles_and_speeds = lambda positions, speeds: None
        with self.assertRaisesRegex(RuntimeError, 'signature'):
            LegacyNavigation(self.nav, rotate_in_place_angles=ANGLES,
                             rotate_in_place_directions=DIRECTIONS)
        self.nav, self.events = branch_navigation()
        with self.assertRaisesRegex(ValueError, 'names'):
            LegacyNavigation(self.nav, rotate_in_place_angles={}, rotate_in_place_directions=DIRECTIONS)
        with self.assertRaisesRegex(ValueError, 'directions'):
            LegacyNavigation(self.nav, rotate_in_place_angles=ANGLES,
                             rotate_in_place_directions={name: 0 for name in DIRECTIONS})
        self.nav._strict_directions = False
        with self.assertRaisesRegex(RuntimeError, 'strict steering'):
            LegacyNavigation(self.nav, rotate_in_place_angles=ANGLES,
                             rotate_in_place_directions=DIRECTIONS)
        self.assertEqual(self.events, [])

    def test_legacy_public_api_passes_through_unchanged(self):
        events = []
        original = SimpleNamespace(config=object(),
            set_speed=lambda speed: events.append(('speed', speed)),
            orient_and_move=lambda angle, speed: events.append(('move', angle, speed)),
            rotate_in_place=lambda speed: events.append(('rotate', speed)))
        adapter = LegacyNavigation(original)
        self.assertIs(adapter.config, original.config)
        adapter.orient_and_move(.3, -2)
        adapter.rotate_in_place(3)
        adapter.set_speed(0)
        self.assertEqual(events, [('move', .3, -2), ('rotate', 3), ('speed', 0)])

    def test_rotation_parser_rejects_executable_values_without_executing(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'config.py'
            path.write_text("navigation_system_config = Constructor(rotate_in_place_angles="
                            "{'turning_center': print('unsafe')}, rotate_in_place_directions={})")
            with self.assertRaisesRegex(ValueError, 'literal numbers'):
                read_navigation_rotation_maps(path)


if __name__ == '__main__':
    unittest.main()
