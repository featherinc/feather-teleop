import quest_video as video
import json
from pathlib import Path
import socket
import struct
import sys
import tempfile
import unittest
from unittest.mock import patch, Mock

from quest_video import HEADER, CONTROL, MAX_IMAGE_BYTES, VideoStream, read_exact, video_packet


class Camera:
    synthetic = False
    def __init__(self):
        self.frame = (7, 10., b'left-jpeg', b'right-jpeg', 640, 360)
        self.ok = True
    def latest_jpeg(self): return self.frame
    def healthy(self): return self.ok


class VideoTests(unittest.TestCase):
    def packet(self, camera, previous=0, now=10.1):
        with patch('quest_video.time.monotonic', return_value=now):
            data = video_packet(camera, previous)
        return HEADER.unpack(data[:HEADER.size]), data[HEADER.size:]

    def test_stereo_protocol_and_no_duplicate_image_payload(self):
        camera = Camera()
        header, data = self.packet(camera)
        self.assertEqual(header[:5], (b'QVID', 1, 0, 24, 7))
        self.assertAlmostEqual(header[5], 100.)
        self.assertEqual(header[6:], (9, 10))
        self.assertEqual(data, b'left-jpegright-jpeg')
        header, data = self.packet(camera, previous=7)
        self.assertEqual(header[2], 2)
        self.assertEqual(data, b'')

    def test_missing_stale_future_unhealthy_and_oversized_frames_rejected(self):
        for fault in ('missing', 'stale', 'future', 'unhealthy', 'oversized', 'size'):
            with self.subTest(fault=fault):
                camera = Camera()
                now = 10.1
                if fault == 'missing': camera.frame = None
                if fault == 'stale': now = 10.5
                if fault == 'future': now = 9.9
                if fault == 'unhealthy': camera.ok = False
                if fault == 'oversized': camera.frame = (7, 10., b'x'*(MAX_IMAGE_BYTES+1), b'y', 640, 360)
                if fault == 'size': camera.frame = (7, 10., b'x', b'y', 320, 240)
                header, data = self.packet(camera, now=now)
                self.assertEqual(header[2], 1)
                self.assertEqual(data, b'')

    def test_latest_only_and_synthetic_flag(self):
        camera = Camera()
        camera.frame = (100, 10., b'new-L', b'new-R', 640, 360)
        camera.synthetic = True
        header, data = self.packet(camera, previous=2)
        self.assertEqual(header[2], 0x80)
        self.assertEqual(header[4], 100)
        self.assertEqual(data, b'new-Lnew-R')

    def test_paused_never_transmits_images(self):
        data = video_packet(Camera(), 0, active=False)
        header = HEADER.unpack(data)
        self.assertEqual(header[2], 3)
        self.assertEqual(header[-2:], (0, 0))

    def test_run_heartbeat_is_nonblocking_and_stop_bypasses_rate_limit(self):
        video = VideoStream('/unused')
        video.control, peer = socket.socketpair(socket.AF_UNIX, socket.SOCK_DGRAM)
        video.control.setblocking(False)
        peer.settimeout(.1)
        try:
            with patch('quest_video.time.monotonic', return_value=10.):
                video.set_active(True)
                self.assertEqual(CONTROL.unpack(peer.recv(64)), (True, 10.))
                video.set_active(True)
                with self.assertRaises(socket.timeout): peer.recv(64)
                video.set_active(False)
                self.assertEqual(CONTROL.unpack(peer.recv(64)), (False, 10.))
        finally:
            video.control.close()
            peer.close()

    def test_camera_selection_is_passed_to_the_child(self):
        with tempfile.TemporaryDirectory() as temp:
            television = Path(temp) / 'TeleVision'
            (television / 'teleop').mkdir(parents=True)
            for name in ('quest_zed.py', 'quest_zed_worker.py'):
                (television / 'teleop' / name).write_text('# unused in mocked child\n')
            video = VideoStream(television, python=sys.executable, model='zed-2i', serial=35928961)
            video.runtime = Path(temp) / 'runtime'
            video.status = lambda: {'healthy': True, 'listening': True}
            process = Mock()
            process.poll.return_value = None
            with patch('quest_video.subprocess.Popen', return_value=process) as start, \
                    patch('quest_video.socket.socketpair', return_value=(Mock(), Mock())), \
                    patch('quest_video.socket.AF_UNIX', getattr(socket, 'AF_UNIX', 0), create=True):
                try:
                    video.start()
                    args = start.call_args.args[0]
                    self.assertEqual(args[args.index('--model')+1], 'zed-2i')
                    self.assertEqual(args[args.index('--serial')+1], '35928961')
                finally:
                    video.stop()
        self.assertEqual(VideoStream('/unused').model, 'zed-x')
        with self.assertRaises(ValueError): VideoStream('/unused', model='other')

    def test_missing_capture_dependencies_fail_before_any_startup_effects(self):
        for missing in ('quest_zed.py', 'quest_zed_worker.py', 'python'):
            with self.subTest(missing=missing), tempfile.TemporaryDirectory() as temp:
                television = Path(temp) / 'TeleVision'
                teleop = television / 'teleop'
                teleop.mkdir(parents=True)
                for name in ('quest_zed.py', 'quest_zed_worker.py'):
                    (teleop / name).write_text('raise AssertionError("parent imported capture")\n')
                if missing == 'python':
                    interpreter = str(Path(temp) / 'missing-python')
                    missing_path = interpreter
                else:
                    (teleop / missing).unlink()
                    interpreter = sys.executable
                    missing_path = str(teleop / missing)
                stream = VideoStream(television, python=interpreter)
                stream.runtime = Path(temp) / 'runtime'
                # An old log must survive a failed restart as well.
                stream.runtime.mkdir()
                log = stream.runtime / 'zed_video.log'
                log.write_text('prior diagnostic\n')
                before = {p.relative_to(temp): p.read_bytes() for p in Path(temp).rglob('*') if p.is_file()}
                with patch('quest_video.subprocess.Popen') as process, \
                        patch('quest_video.socket.socketpair') as pair, \
                        patch.object(Path, 'mkdir') as mkdir, \
                        patch('quest_video.importlib.util.spec_from_file_location') as load:
                    with self.assertRaises(FileNotFoundError) as error:
                        stream.start()
                self.assertIn(missing_path, str(error.exception))
                process.assert_not_called()
                pair.assert_not_called()
                mkdir.assert_not_called()
                load.assert_not_called()
                self.assertEqual(before, {p.relative_to(temp): p.read_bytes() for p in Path(temp).rglob('*') if p.is_file()})
                self.assertIsNone(stream.process)
                self.assertIsNone(stream.log)
                self.assertIsNone(stream.control)

    def test_bare_interpreter_is_resolved_without_importing_capture(self):
        with tempfile.TemporaryDirectory() as temp:
            television = Path(temp) / 'TeleVision'
            (television / 'teleop').mkdir(parents=True)
            for name in ('quest_zed.py', 'quest_zed_worker.py'):
                (television / 'teleop' / name).write_text('raise AssertionError("parent imported capture")\n')
            stream = VideoStream(television, python='quest-camera-python')
            with patch('quest_video.shutil.which', return_value=sys.executable) as which:
                self.assertEqual(stream._preflight(), sys.executable)
            which.assert_called_once_with('quest-camera-python')
            with patch('quest_video.shutil.which', return_value=None):
                with self.assertRaisesRegex(FileNotFoundError, 'quest-camera-python'):
                    stream._preflight()

    def test_capture_api_can_load_from_an_isolated_stage_without_hardware(self):
        with tempfile.TemporaryDirectory() as temp:
            television = Path(temp) / 'TeleVision'
            (television / 'teleop').mkdir(parents=True)
            source = television / 'teleop' / 'quest_zed.py'
            source.write_text('''
def probe_camera(python, serial=None, model='zed-x'):
    raise AssertionError('probe must not run during module loading')
class StereoCamera:
    native_stereo = True
    synthetic = False
    def __init__(self, python, synthetic=False, serial=None, fps=30, model='zed-x'):
        raise AssertionError('camera must not be constructed during module loading')
    def start(self): raise AssertionError('camera must not start')
    def status(self): raise AssertionError('camera must not be used')
    def healthy(self): raise AssertionError('camera must not be used')
    def latest_jpeg(self): raise AssertionError('camera must not be used')
    def latest_calibrated_jpeg(self): raise AssertionError('camera must not be used')
    def close(self): raise AssertionError('camera must not be used')
''')
            with patch('quest_video.subprocess.Popen') as process, \
                    patch('quest_video.socket.socket') as create_socket:
                capture = video.load_capture(television)
            process.assert_not_called()
            create_socket.assert_not_called()
            self.assertEqual(Path(capture.__file__), source)
            self.assertTrue(callable(capture.probe_camera))
            self.assertTrue(capture.StereoCamera.native_stereo)
            for name in ('start', 'status', 'healthy', 'latest_jpeg', 'latest_calibrated_jpeg', 'close'):
                self.assertTrue(callable(getattr(capture.StereoCamera, name)))

    def test_tcp_fragmented_read_and_disconnect(self):
        first, second = socket.socketpair()
        try:
            first.sendall(b'ab')
            first.sendall(b'cd')
            first.shutdown(socket.SHUT_WR)
            self.assertEqual(read_exact(second, 4), b'abcd')
            with self.assertRaises(EOFError): read_exact(second, 1)
        finally:
            first.close()
            second.close()

    def test_notebook_video_preview_and_stop_do_not_import_sdk(self):
        root = Path(__file__).resolve().parents[1]
        notebook = root / ('meta_quest_hand.ipynb' if (root/'meta_quest_hand.ipynb').exists() else 'quest_trajectory_replay.ipynb')
        cells = {c['id']: ''.join(c['source']) for c in json.loads(notebook.read_text())['cells']}
        calls = []
        class FakeVideo:
            def __init__(self, **kw): calls.append(('create', kw))
            def start(self): calls.append(('start',))
            def status(self): return {'healthy': True}
            def stop(self): calls.append(('stop',))
        ns = dict(PROJECT=Path('/home/feather/Workspace/featheros/showcase/team/albert/test'), RUN_HARDWARE=False)
        with patch('quest_video.VideoStream', FakeVideo):
            exec(cells['video-start'], ns)
            exec(cells['video-stop'], ns)
        self.assertEqual([c[0] for c in calls], ['create', 'start', 'stop'])
        self.assertNotIn('robot', ns)
        self.assertEqual(calls[0][1]['model'], 'zed-2i')
        self.assertEqual(calls[0][1]['serial'], 35928961)


class NativeCamera:
    synthetic=False
    native_stereo=True
    def __init__(self):
        self.frame=(7,10.,b'original-L',b'original-R',640,360)
        self.calibration=[262.,262.,320.,180.,0.,.12,1.]
    def latest_jpeg(self): return self.frame
    def latest_calibrated_jpeg(self): return self.frame,self.calibration,True
    def healthy(self): return True


class NativeProtocolTests(unittest.TestCase):
    def packet(self, camera=None, **kwargs):
        with patch.object(video.time,'monotonic',return_value=10.1):
            data=video.video_packet(camera or NativeCamera(),kwargs.pop('previous',0),**kwargs)
        header=video.HEADER.unpack(data[:24])
        return header,data[header[3]:]

    def test_native_pair_unchanged_and_no_viewer_ipd_needed(self):
        h,payload=self.packet(native=True)
        self.assertEqual(h[:5],(b'QVID',3,0,52,7))
        self.assertEqual(payload,b'original-Loriginal-R')
        self.assertEqual(h[-2:],(10,10))

    def test_legacy_clients_receive_mono(self):
        for kwargs,version in (({},1),({'metric':True},2)):
            h,payload=self.packet(**kwargs)
            self.assertEqual(h[1],version)
            self.assertEqual(payload,b'original-Loriginal-L')
            if version==2:self.assertTrue(h[2]&0x40)

    def test_paused_duplicate_and_stale_have_no_images(self):
        h,payload=self.packet(native=True,active=False)
        self.assertEqual(h[2]&0x3f,3);self.assertEqual(payload,b'')
        h,payload=self.packet(native=True,previous=7)
        self.assertEqual(h[2]&0x3f,2);self.assertEqual(payload,b'')
        camera=NativeCamera();camera.frame=(7,9.,b'L',b'R',640,360)
        h,payload=self.packet(camera,native=True)
        self.assertEqual(h[2]&0x3f,1);self.assertEqual(payload,b'')

    def test_no_depth_statistic_can_drop_the_stereo_pair(self):
        camera=NativeCamera();camera.calibration[-1]=0.
        h,payload=self.packet(camera,native=True)
        self.assertEqual(h[2],0)
        self.assertEqual(payload,b'original-Loriginal-R')



if __name__ == '__main__': unittest.main()
