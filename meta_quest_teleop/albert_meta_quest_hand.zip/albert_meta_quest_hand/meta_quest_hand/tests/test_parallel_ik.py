"""Process scheduling/failure tests, with no Pinocchio or robot hardware."""
import multiprocessing as mp
import os
from pathlib import Path
import sys
import time
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from quest_parallel_ik import ParallelArmIK


def fake_worker(pipe, config):
    if config.get('startup_error'):
        pipe.send(('error', None, 'test startup error'))
        return
    pipe.send(('ready', None, None))
    count = 0
    try:
        while True:
            request = pipe.recv()
            if request is None:
                return
            token, job = request
            count += 1
            if job.get('exit'):
                os._exit(1)
            if 'barrier' in config and job.get('barrier'):
                config['barrier'].wait(timeout=2)
            if 'release' in config and job.get('block'):
                config['entered'].set()
                config['release'].wait()
            pipe.send((token, dict(marker=job.get('marker'), count=count,
                                   previous_q=job.get('previous_q')), job.get('error')))
    except (EOFError, BrokenPipeError):
        pass
    finally:
        pipe.close()


class ParallelTests(unittest.TestCase):
    def pool(self, configs=None, **kwargs):
        pool = ParallelArmIK(configs or {'left': {}, 'right': {}},
                             worker_target=fake_worker, **kwargs)
        self.addCleanup(pool.close)
        return pool

    def test_both_submitted_before_waiting_and_fresh_seed_per_job(self):
        barrier = mp.get_context('spawn').Barrier(2)
        pool = self.pool({side: dict(barrier=barrier) for side in ('left', 'right')}, wait_ms=2000)
        for marker in (1, 2):
            jobs = {side: dict(barrier=True, marker=marker, previous_q=[marker] * 7)
                    for side in ('left', 'right')}
            result = pool.solve(jobs)
            for candidate, error in result.values():
                self.assertIsNone(error)
                self.assertEqual(candidate['marker'], marker)
                self.assertEqual(candidate['previous_q'], [marker] * 7)

    def test_timeout_does_not_queue_or_reuse_old_result_and_other_arm_continues(self):
        ctx = mp.get_context('spawn')
        entered, release = ctx.Event(), ctx.Event()
        pool = self.pool({'left': dict(entered=entered, release=release), 'right': {}}, wait_ms=100)
        result = pool.solve({'left': dict(marker='old-reference', block=True),
                             'right': dict(marker=1)})
        self.assertTrue(entered.is_set())
        self.assertEqual(result['left'], (None, 'ik_worker_timeout'))
        self.assertEqual(result['right'][0]['marker'], 1)
        result = pool.solve({'left': dict(marker='must-not-queue'), 'right': dict(marker=2)})
        self.assertEqual(result['left'], (None, 'ik_worker_busy'))
        self.assertEqual(result['right'][0]['marker'], 2)
        release.set()
        self.assertTrue(pool.workers['left']['pipe'].poll(2))
        result = pool.solve({'left': dict(marker='new-reference')})
        self.assertIsNone(result['left'][1])
        self.assertEqual(result['left'][0]['marker'], 'new-reference')
        self.assertEqual(result['left'][0]['count'], 2)  # The busy tick was never queued.

    def test_failure_and_crash_are_independent_per_arm(self):
        pool = self.pool(wait_ms=1000)
        result = pool.solve({'left': dict(error='bad numerical input'), 'right': dict(marker=1)})
        self.assertEqual(result['left'], (None, 'ik_worker_error'))
        self.assertEqual(result['right'][0]['marker'], 1)
        self.assertEqual(pool.last_errors['left'], 'bad numerical input')
        result = pool.solve({'left': dict(exit=True), 'right': dict(marker=2)})
        self.assertEqual(result['left'], (None, 'ik_worker_error'))
        self.assertEqual(result['right'][0]['marker'], 2)
        result = pool.solve({'left': {}, 'right': dict(marker=3)})
        self.assertEqual(result['left'], (None, 'ik_worker_error'))
        self.assertEqual(result['right'][0]['marker'], 3)

    def test_close_terminates_stuck_worker_and_is_idempotent(self):
        ctx = mp.get_context('spawn')
        entered, release = ctx.Event(), ctx.Event()
        pool = self.pool({'left': dict(entered=entered, release=release)}, wait_ms=50)
        pool.solve({'left': dict(block=True)})
        self.assertTrue(entered.wait(2))
        started = time.monotonic()
        pool.close()
        pool.close()
        self.assertLess(time.monotonic() - started, 2)
        self.assertFalse(pool.workers['left']['process'].is_alive())
        with self.assertRaises(RuntimeError):
            pool.solve({'left': {}})

    def test_startup_failure_closes_children(self):
        before = {p.pid for p in mp.active_children()}
        with self.assertRaisesRegex(RuntimeError, 'startup error'):
            self.pool({'left': dict(startup_error=True), 'right': {}})
        self.assertEqual({p.pid for p in mp.active_children()}, before)


if __name__ == '__main__':
    unittest.main()
