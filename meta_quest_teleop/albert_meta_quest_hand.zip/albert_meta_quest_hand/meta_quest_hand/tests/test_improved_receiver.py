"""Synthetic and Linux loopback receiver checks; no robot hardware is used."""
import csv
from pathlib import Path
import struct
import socket
import sys
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import quest_pose_receiver as receiver_module
from quest_async_log import AsyncCSVWriter
from quest_pose_receiver import (HEADER, TIMING, POSE, ANCHOR, CONTROLS, ARM_SWITCH,
                                 BASE_CONTROLS, TURN_CONTROL, MAGIC, PoseReceiver,
                                 parse_packet, packet_row)


def packet(version=6, seq=1, session=42, sent=12.5, offset=-0.01, age=0.2):
    size = {1: 160, 2: 248, 3: 272, 4: 284, 5: 296, 6: 304}[version]
    data = HEADER.pack(MAGIC, version, 1, size, session, seq, sent)
    data += TIMING.pack(0.02, offset, age)
    data += POSE.pack(63, 3, 1, 2, 3, 0, 0, 0, 1) * 3
    if version >= 2:
        data += struct.pack('<I', 7) + ANCHOR.pack(1, 2, 3, 0, 0, 0, 1) * 3
    if version >= 3:
        data += CONTROLS.pack(31, 0.1, 0.2, 0.3, 0.4, -0.5)
    if version >= 4:
        data += ARM_SWITCH.pack(1, 0, 1)
    if version >= 5:
        data += BASE_CONTROLS.pack(3, 0.5, -0.5)
    if version >= 6:
        data += TURN_CONTROL.pack(1, 0.75)
    return parse_packet(data)


class ImprovedReceiver(unittest.TestCase):
    def test_kernel_wait_is_separate_from_clock_estimate(self):
        r = PoseReceiver()
        r.timestamp_option = (64, struct.Struct('=qq'))
        peer = ('127.0.0.1', 1234)
        first = packet(sent=100., offset=0.)
        r._accept(first, peer, 100.150, 200_000_000_000, 200_150_000_000)
        self.assertEqual(first['timestamp_status'], 'ok')
        self.assertAlmostEqual(first['kernel_to_python_ms'], 150.)
        self.assertAlmostEqual(first['quest_to_kernel_estimate_ms'], 0.)
        self.assertIsNone(first['kernel_gap_ms'])
        second = packet(seq=2, sent=100.030, offset=0.)
        r._accept(second, peer, 100.151, 200_033_000_000, 200_151_000_000)
        self.assertAlmostEqual(second['kernel_gap_ms'], 33.)
        self.assertAlmostEqual(second['gap_ms'], 1.)
        self.assertAlmostEqual(second['kernel_to_python_ms'], 118.)
        self.assertAlmostEqual(second['quest_to_kernel_estimate_ms'], 3.)
        # Control freshness retains its original monotonic Python-receive timestamp.
        self.assertEqual(second['receive_s'], 100.151)

    def test_timestamp_missing_truncated_and_clock_step_are_not_zero_wait(self):
        option = (64, struct.Struct('=qq'))
        ancillary = [(socket.SOL_SOCKET, 64, struct.pack('=qq', 200, 123))]
        self.assertEqual(receiver_module.kernel_timestamp_ns(ancillary, 0, option), 200_000_000_123)
        self.assertIsNone(receiver_module.kernel_timestamp_ns([], 0, option))
        self.assertIsNone(receiver_module.kernel_timestamp_ns(ancillary, getattr(socket, 'MSG_CTRUNC', 8), option))
        self.assertIsNone(receiver_module.kernel_timestamp_ns([(socket.SOL_SOCKET, 64, b'x')], 0, option))
        r = PoseReceiver()
        r.timestamp_option = option
        peer = ('127.0.0.1', 1234)
        first = packet(seq=1)
        r._accept(first, peer, 100., 200_000_000_000, 200_001_000_000)
        shifted = packet(seq=2)
        r._accept(shifted, peer, 100.033, 200_033_000_000, 201_034_000_000)
        self.assertEqual(shifted['timestamp_status'], 'clock_step')
        self.assertIsNone(shifted['kernel_to_python_ms'])
        self.assertIsNone(shifted['kernel_gap_ms'])
        missing = packet(seq=3)
        r._accept(missing, peer, 100.066, None, 201_067_000_000)
        self.assertEqual(missing['timestamp_status'], 'missing')
        self.assertIsNone(missing['kernel_to_python_ms'])

    def test_unavailable_timestamping_keeps_original_receive_data(self):
        r = PoseReceiver()
        item = packet()
        r._accept(item, ('127.0.0.1', 1234), 12.55)
        self.assertIsNone(item['kernel_to_python_ms'])
        self.assertIsNone(item['quest_to_kernel_estimate_ms'])
        self.assertAlmostEqual(item['one_way_estimate_ms'], 60.)

    @unittest.skipUnless(sys.platform.startswith('linux'), 'Linux kernel timestamp integration')
    def test_background_receiver_records_real_kernel_metadata(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / 'input.csv'
            receiver = PoseReceiver('127.0.0.1', 0).start(path)
            try:
                sent = time.monotonic()
                data = HEADER.pack(MAGIC, 1, 1, 160, 42, 1, sent)
                data += TIMING.pack(.02, 0., .01)
                data += POSE.pack(63, 3, 1, 2, 3, 0, 0, 0, 1) * 3
                with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as tx:
                    tx.sendto(data, receiver.sock.getsockname())
                deadline = time.monotonic() + 1.
                while receiver.latest_snapshot()['latest'] is None and time.monotonic() < deadline:
                    time.sleep(.002)
                state = receiver.latest_snapshot()
                self.assertIsNone(state['error'])
                self.assertEqual(state['kernel_timestamping'], 'enabled')
                self.assertEqual(state['latest']['timestamp_status'], 'ok')
                self.assertGreaterEqual(state['latest']['kernel_to_python_ms'], 0.)
                self.assertAlmostEqual(state['latest']['quest_to_kernel_estimate_ms']
                    + state['latest']['kernel_to_python_ms'], state['latest']['one_way_estimate_ms'])
            finally:
                receiver.stop()
            with path.open(newline='') as f:
                row = next(csv.DictReader(f))
            self.assertEqual(row['timestamp_status'], 'ok')
            self.assertGreater(int(row['kernel_receive_unix_ns']), 0)

    @unittest.skipUnless(sys.platform.startswith('linux'), 'Linux kernel timestamp integration')
    def test_real_socket_reports_wait_even_when_python_reads_late(self):
        # Only loopback UDP; no Quest, SDK, CAN, or robot hardware.
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as rx, \
             socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as tx:
            option = receiver_module.enable_kernel_timestamps(rx)
            self.assertIsNotNone(option, 'Linux kernel must expose receive timestamps')
            rx.bind(('127.0.0.1', 0))
            rx.settimeout(1.)
            tx.sendto(b'timestamp-test', rx.getsockname())
            time.sleep(.06)  # Intentionally leave the packet waiting in the socket queue.
            data, ancillary, flags, _ = rx.recvmsg(256, socket.CMSG_SPACE(32))
            wall_ns = time.time_ns()
            kernel_ns = receiver_module.kernel_timestamp_ns(ancillary, flags, option)
            self.assertEqual(data, b'timestamp-test')
            self.assertIsNotNone(kernel_ns)
            self.assertGreater((wall_ns - kernel_ns) / 1e6, 40.)

    def test_protocol_versions_and_timing_csv(self):
        for version in range(1, 7):
            parsed = packet(version)
            self.assertEqual(parsed['version'], version)
            self.assertEqual((parsed['sent_s'], parsed['offset_s'], parsed['sync_age_s']),
                             (12.5, -0.01, 0.2))
        parsed.update(receive_s=12.55, gap_ms=None, rtt_ms=20,
                      one_way_estimate_ms=60)
        row = packet_row(parsed, ('127.0.0.1', 1234))
        self.assertEqual(row['sent_s'], 12.5)
        self.assertEqual(row['offset_s'], -0.01)
        self.assertEqual(row['sync_age_s'], 0.2)
        self.assertEqual(set(row), set(receiver_module.CSV_FIELDS))

    def test_latest_is_fresh_and_diagnostics_run_outside_lock(self):
        r = PoseReceiver()
        peer = ('127.0.0.1', 1234)
        now = time.monotonic()
        r._accept(packet(version=4), peer, now - 0.6)
        self.assertEqual(r.latest_snapshot()['status'], 'stale')
        r._accept(packet(version=4, seq=2), peer, now)
        fast = r.latest_snapshot()
        self.assertEqual(fast['status'], 'receiving')
        self.assertEqual(fast['latest']['seq'], 2)
        self.assertEqual((fast['session'], fast['peer']), (42, peer))
        self.assertNotIn('gap_ms', fast)

        original = receiver_module.distribution
        calls = []

        def check_lock(values):
            calls.append(not r.lock.locked())
            return original(values)

        with patch.object(receiver_module, 'distribution', check_lock):
            full = r.snapshot()
        self.assertEqual(calls, [True, True, True])
        self.assertEqual(full['latest']['seq'], 2)

    def test_receiver_log_drains_and_reports_drops(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / 'pose.csv'
            r = PoseReceiver()
            r.log_writer = AsyncCSVWriter(path, receiver_module.CSV_FIELDS, max_rows=8)
            r._accept(packet(version=6), ('127.0.0.1', 1234), time.monotonic())
            self.assertTrue(r.log_writer.close())
            with path.open(newline='', encoding='utf-8') as f:
                rows = list(csv.DictReader(f))
            self.assertEqual(len(rows), 1)
            self.assertEqual((rows[0]['sent_s'], rows[0]['offset_s'], rows[0]['sync_age_s']),
                             ('12.5', '-0.01', '0.2'))
            self.assertEqual(r.latest_snapshot()['log_written'], 1)


class BoundedCSVWriter(unittest.TestCase):
    def test_overflow_drops_without_blocking_and_close_drains(self):
        with tempfile.TemporaryDirectory() as temp:
            logger = AsyncCSVWriter(Path(temp) / 'rows.csv', ['value'], max_rows=1)
            entered, release = threading.Event(), threading.Event()
            original = logger._writer.writerow

            def slow(row):
                entered.set()
                release.wait(1)
                return original(row)

            logger._writer.writerow = slow
            self.assertTrue(logger.writerow({'value': 1}))
            self.assertTrue(entered.wait(1))
            self.assertTrue(logger.writerow({'value': 2}))
            start = time.monotonic()
            self.assertFalse(logger.writerow({'value': 3}))
            self.assertLess(time.monotonic() - start, 0.05)
            self.assertEqual(logger.stats()['dropped'], 1)
            release.set()
            self.assertTrue(logger.close())
            self.assertEqual(logger.stats()['written'], 2)

    def test_io_error_visible_and_close_bounded(self):
        with tempfile.TemporaryDirectory() as temp:
            logger = AsyncCSVWriter(Path(temp) / 'error.csv', ['value'])
            def fail(_row):
                raise OSError('synthetic disk failure')
            logger._writer.writerow = fail
            self.assertTrue(logger.writerow({'value': 1}))
            deadline = time.monotonic() + 1
            while logger.stats()['error'] is None and time.monotonic() < deadline:
                time.sleep(0.005)
            self.assertIn('synthetic disk failure', logger.stats()['error'])
            self.assertEqual(logger.stats()['dropped'], 1)
            self.assertFalse(logger.writerow({'value': 2}))
            self.assertEqual(logger.stats()['dropped'], 2)
            self.assertFalse(logger.close())

            logger = AsyncCSVWriter(Path(temp) / 'slow.csv', ['value'])
            entered, release = threading.Event(), threading.Event()
            original = logger._writer.writerow
            def slow(row):
                entered.set()
                release.wait(1)
                return original(row)
            logger._writer.writerow = slow
            logger.writerow({'value': 1})
            self.assertTrue(entered.wait(1))
            start = time.monotonic()
            self.assertFalse(logger.close(timeout=0.01))
            self.assertLess(time.monotonic() - start, 0.1)
            self.assertIn('timed out', logger.stats()['error'])
            release.set()
            logger.close(timeout=1)


if __name__ == '__main__':
    unittest.main()
