"""Headset math and notebook SDK calls, with simulated feedback only."""
import copy
import json
import math
from pathlib import Path
import sys
import threading
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from quest_control import head_angles, NeckTargets
from test_quest_buttons import snapshot
import test_quest_notebook as notebook_fixture


def quat(pitch=0, yaw=0, roll=0):
    p, y, r = [math.radians(v)/2 for v in (pitch, yaw, roll)]
    cp, sp, cy, sy, cr, sr = math.cos(p), math.sin(p), math.cos(y), math.sin(y), math.cos(r), math.sin(r)
    return [sr*cp*cy-cr*sp*sy, cr*sp*cy+sr*cp*sy, cr*cp*sy-sr*sp*cy, cr*cp*cy+sr*sp*sy]


class MathTests(unittest.TestCase):
    def motion(self, q=None, neutral=(-.5, .2), speed=100):
        return NeckTargets(quat() if q is None else q, neutral, [(-2.2, .1), (-1.66, 1.66)], speed=speed)

    def test_a_is_neutral_at_arbitrary_heading_pitch_and_roll(self):
        for yaw in (-150, 0, 130):
            q = quat(pitch=-30, yaw=yaw, roll=45)
            motion = self.motion(q)
            self.assertEqual(motion.step(q, 1/30), (-.5, .2))

    def test_pitch_yaw_directions_and_roll_ignored(self):
        for roll in (-70, 0, 70):
            p, y = head_angles(quat(pitch=-20, yaw=35, roll=roll))
            self.assertAlmostEqual(p, math.radians(-20))  # Looking up is negative pitch.
            self.assertAlmostEqual(y, math.radians(35))  # Looking left is positive yaw.
        result = self.motion(quat(-30, 90, 45)).step(quat(-40, 110, -60), .03)
        self.assertAlmostEqual(result[0], -.5-math.radians(10))
        self.assertAlmostEqual(result[1], .2-math.radians(20))

    def test_left_head_turn_commands_negative_motor_yaw_and_right_positive(self):
        for head_yaw in (-30, 30):
            pitch, yaw = self.motion(neutral=(-.5, 0)).step(quat(yaw=head_yaw), .03)
            self.assertEqual(pitch, -.5)
            self.assertAlmostEqual(yaw, -math.radians(head_yaw))

    def test_quaternion_sign_and_yaw_wrap(self):
        q = quat(-10, 179)
        self.assertEqual(self.motion(q).step([-v for v in q], .03), (-.5, .2))
        self.assertAlmostEqual(self.motion(q).step(quat(-10, -179), .03)[1], .2-math.radians(2))

    def test_limits_speed_and_long_gap_do_not_jump(self):
        motion = self.motion(speed=1)
        p, y = motion.step(quat(-70, 150), 50)
        self.assertAlmostEqual(p, -.55)
        self.assertAlmostEqual(y, .15)
        for _ in range(200):
            p, y = motion.step(quat(-70, 150), 1/30)
        self.assertGreaterEqual(p, -2.2)
        self.assertEqual(y, -1.66)
        p, y = self.motion().step(quat(60, -150), .03)
        self.assertAlmostEqual(p, .1)
        self.assertEqual(y, 1.66)

    def test_invalid_or_vertical_quaternion_cannot_command(self):
        for q in ([0, 0, 0, 0], [math.nan, 0, 0, 1], [0, 0, 0], quat(90)):
            with self.assertRaises(ValueError):
                head_angles(q)


class NotebookTests(unittest.TestCase):
    def setUp(self):
        self.fixture = notebook_fixture.Tests()
        self.fixture.setUp()
        self.addCleanup(self.fixture.doCleanups)
        self.ns, self.robot = self.fixture.namespace()
        self.now = 10.0
        self.calls = []
        self.fresh = True
        self.feedback_requests = []
        def motor(value, bounds):
            return SimpleNamespace(config=SimpleNamespace(angle_range=bounds, max_velocity=10.47),
                PARAM_SET=SimpleNamespace(mech_pos='position'),
                get_param=lambda *a, **kw: value,
                trigger_feedback_frame=lambda **kw: self.feedback_requests.append((self.now, kw)),
                read_param=lambda *a, **kw: value,
                telemetry=SimpleNamespace(get_latest_timestamp=lambda *a, **kw:
                    int((self.now if self.fresh else self.now-1)*1e9)))
        self.neck = SimpleNamespace(pitch_motor=motor(-.5, (-2.2, .1)), yaw_motor=motor(0, (-1.66, 1.66)),
            go_to=lambda **kw: self.calls.append(('go', kw)),
            set_speed=lambda **kw: self.calls.append(('speed', kw)))
        self.ns.update(CONTROL_NECK=True, neck=self.neck, neck_lock=threading.RLock(),
            neck_held=True, neck_errors=[], active_key=(42,7), active_b=0,
            torso_allowed=threading.Event(),
            neck_motion=NeckTargets(quat(), (-.5,0), [(-2.2,.1),(-1.66,1.66)]))
        self.ns['torso_allowed'].set()

    def state(self):
        s = snapshot(1,0,True,now=10)
        s['latest']['poses']['head']['quaternion_xyzw'] = quat(-10, 15)
        return s

    def run_worker(self, states, late=None):
        index, reads = [0], [0]
        class Done:
            def is_set(self): return index[0] >= len(states)
            def wait(_, dt):
                index[0] += 1
                self.now += 1/30
        def latest():
            reads[0] += 1
            return late if late is not None and reads[0] == 2 else states[index[0]]
        self.ns.update(receiver=SimpleNamespace(latest_snapshot=latest), torso_done=Done())
        with patch.object(time, 'monotonic', lambda: self.now):
            self.ns['neck_loop']()

    def test_b_stale_session_recenter_or_tracking_holds_without_home(self):
        for reason in ('b', 'stale', 'session', 'recenter', 'rotation', 'tracking'):
            self.calls.clear()
            self.now = 10
            self.ns['neck_held'] = True
            first = self.state()
            last = copy.deepcopy(first)
            if reason == 'b': last['latest']['arm_switch']['b_press'] = 1
            if reason == 'stale': last['latest']['receive_s'] = 9
            if reason == 'session': last['latest']['session'] = 88
            if reason == 'recenter': last['latest']['recenter_id'] = 1
            if reason == 'rotation': last['latest']['poses']['head']['rotation_valid'] = False
            if reason == 'tracking': last['latest']['poses']['head']['tracked'] = False
            self.run_worker([first, first, last])
            self.assertEqual(self.ns['neck_errors'], [])
            self.assertEqual(self.calls[-2], ('speed', dict(pitch_speed=0., yaw_speed=0.)))
            self.assertEqual(self.calls[-1], ('go', dict(pitch=-.5, yaw=0., block=False)))
            self.assertTrue(self.ns['neck_held'])

    def test_position_and_extra_a_do_not_change_head_reference(self):
        state = self.state()
        state['latest']['poses']['head'].update(position_valid=False, position_m=[100, 100, 100])
        state['latest']['calibration_id'] += 1
        state['latest']['arm_switch']['a_press'] += 1
        self.assertTrue(self.ns['neck_request_valid'](state, 10))
        reference = self.ns['neck_motion'].reference
        self.run_worker([state, state])
        self.assertEqual(self.ns['neck_motion'].reference, reference)
        self.assertTrue(any(k == 'speed' and v['yaw_speed'] == 1 for k,v in self.calls))

    def test_late_b_does_not_submit_computed_target(self):
        state = self.state()
        b = copy.deepcopy(state)
        b['latest']['arm_switch']['b_press'] = 1
        self.run_worker([state], late=b)
        self.assertEqual(self.calls, [])  # Already held; no motion or resume.

    def test_stale_feedback_keeps_speed_zero_until_it_recovers(self):
        self.fresh = False
        self.run_worker([self.state()])
        self.assertEqual(self.calls, [])
        self.fresh = True
        self.run_worker([self.state()])
        self.assertTrue(any(k == 'speed' and v['yaw_speed'] > 0 for k,v in self.calls))

    def test_can_feedback_timestamps_are_monotonic_nanoseconds(self):
        # CanSocketResult passes CLOCK_MONOTONIC ns straight to motor telemetry.
        for uptime in (10.0, 3600.0, 86400.0):
            self.now = uptime
            with patch.object(time, 'monotonic', lambda: self.now):
                self.assertEqual(self.ns['read_neck_position'](), (-.5, 0.))

    def test_worker_polls_feedback_at_control_rate_even_while_ready(self):
        self.ns['torso_allowed'].clear()
        self.run_worker([self.state(), self.state()])
        self.assertEqual(self.calls, [])  # Feedback requests do not enable/move.
        self.assertEqual(len(self.feedback_requests), 4)  # Two motors, two ticks.
        for _, args in self.feedback_requests:
            self.assertEqual(args, {'block': False})  # No SDK update_hz gate.
        self.assertAlmostEqual(self.feedback_requests[2][0] - self.feedback_requests[0][0], 1/30)

    def test_feedback_request_failure_holds_and_reports_error(self):
        self.ns['neck_held'] = False
        def fail(**kw): raise RuntimeError('feedback request failed')
        self.neck.pitch_motor.trigger_feedback_frame = fail
        self.run_worker([self.state()])
        self.assertEqual(str(self.ns['neck_errors'][0]), 'feedback request failed')
        self.assertEqual(self.calls[0], ('speed', dict(pitch_speed=0., yaw_speed=0.)))
        self.assertTrue(self.ns['neck_held'])

    def test_missing_future_and_nonfinite_feedback_cannot_resume(self):
        for stamp in (None, 9e9, 10.1e9, math.nan, math.inf):
            with self.subTest(stamp=stamp):
                for motor in (self.neck.pitch_motor, self.neck.yaw_motor):
                    motor.telemetry.get_latest_timestamp = lambda *a, **kw: stamp
                with patch.object(time, 'monotonic', lambda: self.now):
                    with self.assertRaisesRegex(RuntimeError, 'fresh neck feedback'):
                        self.ns['read_neck_position']()
                self.calls.clear()
                self.run_worker([self.state()])
                self.assertEqual(self.calls, [])
                self.assertTrue(self.ns['neck_held'])

    def test_home_stops_neck_before_arms(self):
        self.ns['neck_held'] = False
        self.ns['arms'].disable = lambda: self.calls.append(('arms', 'home'))
        with patch.object(time, 'monotonic', lambda: self.now):
            self.ns['home_and_disable_arms']()
        self.assertEqual(self.calls[0], ('speed', dict(pitch_speed=0., yaw_speed=0.)))
        self.assertEqual(self.calls[-1], ('arms', 'home'))

    def test_config_neck_is_optional_without_sdk_mutation(self):
        from quest_trajectory_replay import load_replay_config
        class Config(SimpleNamespace):
            def model_copy(self, update, deep):
                result = copy.deepcopy(self)
                result.__dict__.update(update)
                return result
        original = Config(neck_system_config={'neck':'unchanged'})
        with patch.dict(sys.modules, {'feathersdk.configs': SimpleNamespace(load_configs=lambda _: original)}):
            self.assertIsNone(load_replay_config(__file__, __file__, sdk_generation='legacy').neck_system_config)
            self.assertEqual(load_replay_config(__file__, __file__, include_neck=True,
                                               sdk_generation='legacy').neck_system_config,
                             original.neck_system_config)
            self.assertEqual(original.neck_system_config, {'neck':'unchanged'})
            original.neck_system_config = None
            with self.assertRaises(ValueError):
                load_replay_config(__file__, __file__, include_neck=True, sdk_generation='legacy')

    def test_live_a_b_a_refreshes_neck_reference_but_extra_a_is_ignored(self):
        import test_improved_notebook as improved
        import quest_television_ik as ik
        clock = improved.Clock()
        class Receiver(improved.Receiver):
            def latest_snapshot(r):
                s = super().latest_snapshot()
                t = clock.now_s
                a = 0 if t < .02 else 1 if t < .10 else 2 if t < .27 else 3
                yaw = 10*a
                s['latest'].update(calibration_id=a)
                s['latest']['arm_switch']['a_press'] = a
                s['latest']['anchors']['head']['quaternion_xyzw'] = quat(yaw=yaw)
                return s
        class Thread:
            # The worker is tested separately; keep the notebook state machine deterministic.
            def __init__(self, **kw): pass
            def start(self): pass
            def join(self, **kw): pass
            def is_alive(self): return False
        receiver = Receiver(clock)
        self.ns.update(RUN_HARDWARE=True, PoseReceiver=lambda: receiver,
            threading=SimpleNamespace(Thread=Thread, Event=threading.Event,
                                      Lock=threading.Lock, RLock=threading.RLock))
        with patch.object(time, 'monotonic', clock.monotonic), \
             patch.object(time, 'sleep', clock.sleep), \
             patch.object(ik, 'pose_values', lambda *a: [0.,0.,0.,0.,0.,0.,1.]):
            exec(self.fixture.cells()['run'], self.ns)
        folder = self.ns['session_folder']
        references = json.loads((folder/'calibration.json').read_text())
        self.assertEqual([r['calibration_id'] for r in references], [1,3])
        self.assertAlmostEqual(references[0]['neck']['head_pitch_yaw_rad'][1], math.radians(10))
        self.assertAlmostEqual(references[1]['neck']['head_pitch_yaw_rad'][1], math.radians(30))
        self.assertEqual(references[1]['neck']['neutral_pitch_yaw_rad'], [-.5,0.])


if __name__ == '__main__':
    unittest.main()
