import copy
import json
import math
from pathlib import Path
import sys
import threading
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from quest_hand import HandTargets, HAND_MODES, read_hand_position
from quest_control import FixedRate


def packet(left=0, right=0, session=1, trigger=0., grip=0.):
    return dict(version=9, session=session, receive_s=10., recenter_id=0, hand_buttons=dict(
        available=True, left_available=True, right_available=True, left_select_press=left, right_select_press=right),
        arm_switch=dict(b_press=0, run_requested=True),
        controls={key: value for side in ('left', 'right') for key, value in
                  ((side + '_trigger', trigger), (side + '_grip', grip))},
        poses={side: dict(connected=True, tracked=True, position_valid=True, rotation_valid=True)
               for side in ('left', 'right')})


class HandControlTests(unittest.TestCase):
    def setUp(self):
        self.state = HandTargets({side: [128] * 6 for side in ('left', 'right')})
        self.step(packet())  # Release arms control and requests open.

    def step(self, p, running=True):
        commands = self.state.step(p, running)
        for side, position in commands.items():
            self.state.mark_sent(side, position)
        return commands

    def test_front_trigger_sets_absolute_position_in_both_directions(self):
        self.assertEqual(self.state.sent['left'], [255]*6)
        self.assertEqual(self.step(packet(trigger=0.5))['left'], [128]*6)
        self.assertEqual(self.step(packet(trigger=1))['left'], [0]*6)
        self.assertEqual(self.step(packet(trigger=0.25))['left'], [191]*6)
        self.assertEqual(self.step(packet(trigger=0))['left'], [255]*6)

    def test_holding_partial_trigger_does_not_keep_closing(self):
        self.step(packet(trigger=0.4))
        for _ in range(100):self.assertEqual(self.step(packet(trigger=0.4)), {})
        self.assertEqual(self.state.sent['left'], [153]*6)

    def test_side_grip_does_not_change_or_block_hand_target(self):
        self.step(packet(trigger=0.5))
        for grip in (0., .5, 1., None, float('nan')):
            self.assertEqual(self.step(packet(trigger=.5, grip=grip)), {})
        self.assertEqual(self.step(packet(trigger=0, grip=1))['left'], [255]*6)
        self.assertEqual(self.step(packet(trigger=1, grip=1))['left'], [0]*6)

    def test_each_controller_drives_its_own_hand(self):
        p=packet()
        p['controls'].update(left_trigger=.2, right_trigger=.8)
        result=self.step(p)
        self.assertEqual(result['left'], [204]*6)
        self.assertEqual(result['right'], [51]*6)

    def test_decoded_udp_front_trigger_fields_control_the_correct_hand(self):
        from test_hand_protocol import wire
        from quest_pose_receiver import parse_packet
        p=parse_packet(wire(left=0,right=0))  # L trigger .2/grip .3; R trigger .4/grip .5.
        neutral=copy.deepcopy(p)
        neutral['controls'].update(left_trigger=0.,right_trigger=0.)
        self.step(neutral)  # Fresh session: front release arms control.
        result=self.step(p)
        self.assertEqual(result['left'],[204]*6)
        self.assertEqual(result['right'],[153]*6)

    def test_two_modes_independent_and_packet_loss_safe(self):
        self.step(packet(left=1, right=4))
        self.assertEqual(self.state.selection, dict(left=1, right=0))
        self.step(packet(left=1, right=4))
        self.assertEqual(self.state.selection, dict(left=1, right=0))
        self.assertEqual(len(HAND_MODES), 2)
        self.assertEqual(self.state.status()['left_hand_selection'], 'pinch')
        self.step(packet(left=2, right=5))
        self.assertEqual(self.state.selection, dict(left=0, right=1))

    def test_pinch_maps_thumb_and_index_to_trigger_and_opens_other_fingers(self):
        self.step(packet(left=1))
        self.assertEqual(self.step(packet(left=1, trigger=.5))['left'], [178,25,190,255,255,255])
        self.assertEqual(self.step(packet(left=1, trigger=1))['left'], [100,25,125,255,255,255])
        self.assertNotIn('left',self.step(packet(left=1, trigger=1)))
        self.assertEqual(self.step(packet(left=1))['left'], [255,25,255,255,255,255])

    def test_both_hands_use_same_pinch_endpoints_with_independent_triggers(self):
        self.step(packet(left=1,right=1))
        for trigger,expected in ((0,[255,25,255,255,255,255]),
                                 (.5,[178,25,190,255,255,255]),
                                 (1,[100,25,125,255,255,255])):
            self.step(packet(left=1,right=1,trigger=trigger))
            self.assertEqual(self.state.sent['left'],expected)
            self.assertEqual(self.state.sent['right'],expected)
        p=packet(left=1,right=1)
        p['controls'].update(left_trigger=.2,right_trigger=.8)
        result=self.step(p)
        self.assertEqual(result['left'],[224,25,229,255,255,255])
        self.assertEqual(result['right'],[131,25,151,255,255,255])

    def test_pinch_endpoints_are_validated_and_copied(self):
        opened=[255,25,255,255,255,255]
        closed=[100,25,125,255,255,255]
        state=HandTargets({'left':[255]*6},pinch_open_position=opened,pinch_closed_position=closed)
        opened[1]=255;closed[0]=0
        state.step(packet(left=1),True)
        self.assertEqual(state.step(packet(left=1,trigger=1),True)['left'],[100,25,125,255,255,255])
        for bad in ([1]*5,[256]*6,[float('nan')]*6):
            for field in ('pinch_open_position','pinch_closed_position'):
                with self.assertRaises(ValueError):HandTargets({},**{field:bad})

    def test_mode_switch_while_squeezed_waits_for_front_release(self):
        self.step(packet(trigger=1))
        result=self.step(packet(left=1,trigger=1))
        self.assertEqual(result['left'], [0,0,0,255,255,255])
        self.assertTrue(self.state.release_required['left'])
        self.assertNotIn('left',self.step(packet(left=1,trigger=.5)))
        self.assertEqual(self.step(packet(left=1,grip=1))['left'], [255,25,255,255,255,255])
        self.assertEqual(self.step(packet(left=1,trigger=.5))['left'], [178,25,190,255,255,255])
        self.assertNotIn('left',self.step(packet(left=2,trigger=.5)))
        self.step(packet(left=2))
        self.assertEqual(self.step(packet(left=2,trigger=.5))['left'], [128]*6)

    def test_pinch_selected_while_stopped_does_not_open_hand(self):
        state=HandTargets({'left':[0]*6})
        self.assertFalse(state.step(packet(left=3),False))
        self.assertEqual(state.selection['left'],1)
        self.assertEqual(state.sent['left'],[0]*6)

    def test_stop_and_stale_hold_until_front_released_to_resume(self):
        self.step(packet(trigger=.8))
        held=copy.deepcopy(self.state.sent)
        self.assertFalse(self.step(packet(trigger=0),running=False))
        self.assertFalse(self.step(packet(trigger=.8),running=True))
        self.assertEqual(self.state.sent,held)
        self.assertEqual(self.step(packet(trigger=0,grip=1))['left'],[255]*6)
        self.assertEqual(self.step(packet(trigger=.8))['left'],[51]*6)

    def test_one_untracked_hand_does_not_block_the_other(self):
        p=packet(trigger=1)
        p['poses']['left']['tracked']=False
        p['hand_buttons']['left_available']=False
        result=self.step(p)
        self.assertNotIn('left',result)
        self.assertEqual(result['right'],[0]*6)
        self.assertEqual(self.state.sent['left'],[255]*6)

    def test_invalid_input_and_legacy_packets_never_move(self):
        for value in (None,float('nan'),float('inf'),-1,2):
            self.state.release_required['left']=False
            self.assertNotIn('left',self.step(packet(trigger=value)))
        p=packet(trigger=1);p['version']=8
        self.assertFalse(self.step(p))
        p['hand_buttons']=None
        self.assertFalse(self.step(p))

    def test_restart_and_counter_wrap(self):
        self.step(packet(trigger=.5,left=4))
        self.assertFalse(self.step(packet(session=2,trigger=1)))
        self.assertTrue(self.state.release_required['left'])
        self.step(packet(session=2,left=0xffffffff))
        self.assertEqual(self.state.selection['left'],1)
        self.step(packet(session=2,left=0))
        self.assertEqual(self.state.selection['left'],0)

    def test_unsubmitted_target_discarded_on_stop(self):
        self.state.step(packet(trigger=1),True)
        self.state.hold()
        self.assertEqual(self.state.targets,self.state.sent)
        self.assertEqual(self.state.sent['left'],[255]*6)

    def test_release_threshold_only_arms_control_not_position_mapping(self):
        self.assertEqual(self.step(packet(trigger=.05))['left'],[242]*6)
        self.assertEqual(self.step(packet(trigger=.5))['left'],[128]*6)

    def test_sdk_position_packing_preserves_channel_order(self):
        positions=[0,255,17,88,123,9]
        hand=SimpleNamespace(PARAM_SET=SimpleNamespace(position='position'),
            read_param=lambda param,block:int.from_bytes(bytes(positions)+b'\0','big'))
        self.assertEqual(read_hand_position(hand),positions)

    def test_empty_selection_and_bad_initial_settings(self):
        self.assertFalse(HandTargets({}).step(packet(),True))
        for positions in ({'left':[256]*6},{'left':[1]*5}):
            with self.assertRaises(ValueError):HandTargets(positions)
        for threshold in (-1,1,float('nan')):
            with self.assertRaises(ValueError):HandTargets({},release_threshold=threshold)


class NotebookHandTests(unittest.TestCase):
    def cells(self):
        return {c['id']: ''.join(c['source']) for c in json.loads((ROOT / 'meta_quest_hand.ipynb').read_text(encoding='utf-8'))['cells'] if c['cell_type'] == 'code'}

    def test_cells_compile_no_gripper_driver_and_no_sdk_disable_for_hands(self):
        cells = self.cells()
        for name, source in cells.items():
            compile(source, name, 'exec')
        code = '\n'.join(cells.values())
        self.assertNotIn('quest_gripper', code)
        self.assertNotIn('recalibrate(', code)
        self.assertNotIn('gripper_', code)
        self.assertIn('PARALLEL_IK = True', cells['settings'])
        self.assertRegex(cells['settings'], r'(?m)^RUN_HARDWARE\s*=\s*(True|False)\b')
        self.assertIn('set_position(position)', cells['hand-functions'])

    def test_prepare_uses_sdk_torque_speed_and_reads_without_opening_hands(self):
        calls = []
        position = [100, 200, 130, 140, 150, 160]
        def hand(side):
            return SimpleNamespace(PARAM_SET=SimpleNamespace(position='position'),
                set_torque=lambda values: calls.append((side, 'torque', values[:])),
                set_speed=lambda value: calls.append((side, 'speed', value)),
                set_position=lambda values: calls.append((side, 'position', values[:])),
                read_param=lambda param, block: int.from_bytes(bytes(position) + b'\0', 'big'))
        hands = {side: hand(side) for side in ('left', 'right')}
        ns = dict(RUN_HARDWARE=True, selected_hands=lambda: hands, HAND_TORQUE=[180,180,120,120,120,120],
                  PINCH_OPEN_POSITION=[255,25,255,255,255,255], PINCH_CLOSED_POSITION=[100,25,125,255,255,255], HAND_SPEED=150, HAND_RELEASE_THRESHOLD=.1, CONTROL_HZ=30.)
        exec(self.cells()['hand-setup'], ns)
        self.assertEqual(len(calls), 4)
        self.assertFalse(any(kind == 'position' for _, kind, _ in calls))
        self.assertEqual(ns['hand_targets'].sent, {'left': position, 'right': position})

    def test_prepare_preview_sends_no_hardware_commands(self):
        ns = dict(RUN_HARDWARE=False)
        exec(self.cells()['hand-setup'], ns)
        self.assertNotIn('hand_targets', ns)

    def test_b_recenter_and_expiry_between_hand_calculation_and_send(self):
        for fault in ('b', 'recenter', 'stale', 'session'):
            with self.subTest(fault=fault):
                p = packet(trigger=1)
                count = [0]
                def snapshot():
                    count[0] += 1
                    q = copy.deepcopy(p)
                    if count[0] > 1:
                        if fault == 'b': q['arm_switch']['b_press'] = 1
                        if fault == 'recenter': q['recenter_id'] = 1
                        if fault == 'stale': q['receive_s'] = 9.
                        if fault == 'session': q['session'] = 2
                    return dict(status='receiving', latest=q)
                done, allowed = threading.Event(), threading.Event()
                allowed.set()
                done.wait = lambda _seconds: done.set()
                calls = []
                hands = {side: SimpleNamespace(set_position=lambda pos: calls.append(pos)) for side in ('left', 'right')}
                state = HandTargets({side: [128] * 6 for side in hands})
                state.step(packet(), True)
                now = [10.]
                def monotonic():
                    now[0] += .005
                    return now[0]
                ns = dict(FixedRate=FixedRate, CONTROL_HZ=30., math=math, time=SimpleNamespace(monotonic=monotonic),
                    torso_done=done, torso_allowed=allowed, active_key=(1, 1), active_b=0,
                    same_tracking_origin=lambda q: q['recenter_id'] == 0,
                    receiver=SimpleNamespace(latest_snapshot=snapshot), hand_lock=threading.Lock(),
                    hand_targets=state, hand_errors=[], selected_hands=lambda: hands,
                    stop_hands=state.hold)
                exec(self.cells()['hand-functions'], ns)
                ns['hand_loop']()
                self.assertFalse(calls)
                self.assertFalse(ns['hand_errors'])
                self.assertEqual(state.sent['left'], [128] * 6)


if __name__ == '__main__':
    unittest.main()
