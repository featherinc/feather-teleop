"""Exercise the actual notebook torso worker with SDK doubles and a real A gate."""
import ast
import copy
import json
import math
from pathlib import Path
import threading
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from quest_control import FixedRate
from quest_pose_receiver import ArmRunGate


class TorsoGrips(unittest.TestCase):
    def state(self, left=0.0, right=0.0, *, a=1, b=0, run=True, session=42,
              receive=10.0, origin=0, joystick=0.0):
        return dict(status='receiving', latest=dict(session=session, receive_s=receive,
            recenter_id=origin, poses={'right': {'connected': True}},
            arm_switch=dict(a_press=a, b_press=b, run_requested=run),
            controls=dict(left_grip=left, right_grip=right, torso_y=joystick)))

    def worker(self, states, *, allowed=True, fail=False):
        notebook = json.loads((Path(__file__).resolve().parents[1]/'meta_quest_hand.ipynb').read_text())
        source = next(''.join(c['source']) for c in notebook['cells']
                      if c['cell_type']=='code' and 'def torso_loop()' in ''.join(c['source']))
        definition = next(n for n in ast.parse(source).body
                          if isinstance(n, ast.FunctionDef) and n.name=='torso_loop')
        index, calls = [0], []
        class Done:
            def is_set(self): return index[0] >= len(states)
            def wait(self, delay): index[0] += 1
        event = threading.Event()
        if allowed: event.set()
        def update_velocity(speed, block):
            calls.append(speed)
            if fail and speed: raise RuntimeError('SDK error')
        namespace = dict(ArmRunGate=ArmRunGate, FixedRate=FixedRate, math=math, time=time,
            CONTROL_HZ=30, TORSO_SPEED=100, DEADZONE=.1, torso_speed_sent=0.0,
            torso_done=Done(), torso_allowed=event, torso_lock=threading.Lock(), torso_errors=[],
            receiver=SimpleNamespace(latest_snapshot=lambda: states[index[0]]),
            same_tracking_origin=lambda p: p.get('recenter_id', 0)==0,
            torso=SimpleNamespace(update_velocity=update_velocity),
            stop_torso=lambda: calls.append(0.0))
        exec(compile(ast.Module(body=[definition], type_ignores=[]), '<notebook torso_loop>', 'exec'), namespace)
        with patch.object(time, 'monotonic', return_value=10.0):
            namespace['torso_loop']()
        return calls, namespace['torso_errors']

    def start(self, *states):
        return self.worker([self.state(a=0, run=False), *states])

    def test_up_down_proportional_and_equal_grips_stop(self):
        calls, errors = self.start(self.state(0, 1), self.state(1, 0), self.state(.2, .8),
                                   self.state(.8, .2), self.state(1, 1), self.state(0, 0))
        self.assertEqual(calls, [100, -100, 60, -60, 0, 0])
        self.assertEqual(errors, [])

    def test_release_sends_zero_and_joystick_is_unused(self):
        calls, errors = self.start(self.state(0, 1, joystick=-1), self.state(0, 0, joystick=1))
        self.assertEqual(calls, [100, 0, 0])
        self.assertEqual(errors, [])

    def test_deadzone_and_unchanged_speed_do_not_repeat(self):
        calls, errors = self.start(self.state(0, .1), self.state(0, .4), self.state(0, .4),
                                   self.state(.95, 1))
        self.assertEqual(calls, [40, 0, 0])
        self.assertEqual(errors, [])

    def test_missing_or_invalid_either_grip_stops(self):
        for side in ('left', 'right'):
            for value in (None, math.nan, math.inf, -.1, 1.1):
                with self.subTest(side=side, value=value):
                    bad=self.state(0, 1)
                    bad['latest']['controls'][side+'_grip']=value
                    calls, errors=self.start(self.state(0, 1), bad)
                    self.assertEqual(calls, [100, 0, 0])
                    self.assertEqual(errors, [])

    def test_stop_stale_session_recenter_and_disconnect_hold(self):
        for reason in ('a_stop', 'stale', 'session', 'recenter', 'disconnected'):
            with self.subTest(reason=reason):
                bad=self.state(0, 1)
                if reason=='a_stop': bad['latest']['arm_switch'].update(b_press=1, run_requested=False)
                if reason=='stale': bad['latest']['receive_s']=9.6
                if reason=='session': bad['latest']['session']=99
                if reason=='recenter': bad['latest']['recenter_id']=1
                if reason=='disconnected': bad['latest']['poses']['right']['connected']=False
                calls, errors=self.start(self.state(0, 1), bad)
                self.assertEqual(calls, [100, 0, 0])
                self.assertEqual(errors, [])

    def test_fresh_a_and_settling_gate_required(self):
        for states, allowed in (([self.state(0,1)], True),
                                 ([self.state(a=0,run=False),self.state(0,1)],False)):
            calls, errors=self.worker(states,allowed=allowed)
            self.assertEqual(calls,[0])
            self.assertEqual(errors,[])

    def test_sdk_error_attempts_hold_and_is_reported(self):
        calls, errors=self.worker([self.state(a=0,run=False),self.state(0,1)],fail=True)
        self.assertEqual(calls,[100,0])
        self.assertEqual(len(errors),1)


if __name__ == '__main__':
    unittest.main()
