"""Offline wire, discovery, failure and lifecycle checks; no SDK or CAN startup."""
import ast
from pathlib import Path
import runpy
import struct
import sys
import threading
import time
from types import MethodType, SimpleNamespace
import unittest
from unittest.mock import patch


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from quest_sdk_hands import HandCanConfig, attach_hands
from quest_hand import read_hand_position


RECORD = struct.Struct('<BI8BQ')


def frame(bus, can_id, values=(0, 255, 17, 88, 123, 9), *, register=1,
          sent=False, dlc=7, stamp=None):
    data = bytes([register]) + bytes(values)
    data = (data + b'\0' * 8)[:8]
    return RECORD.pack((bus << 5) | (int(sent) << 4) | dlc, can_id, *data,
                       time.monotonic_ns() if stamp is None else stamp)


class Handler:
    def __init__(self, writer):
        self._sent_messages = {}
        self._responses = {}
        self._sent_messages_lock = threading.Lock()
        self._responses_lock = threading.Lock()
        self._next_id = 0
        self.writer = writer
        self.calls = []

    def reserve(self):
        with self._sent_messages_lock:
            self._next_id += 1
            self._sent_messages[self._next_id] = time.monotonic()
            return self._next_id

    def _handle_message(self, msg_id, opcode, payload):
        if msg_id not in self._sent_messages:
            return
        self.calls.append((msg_id, opcode, payload))
        if opcode == 4 and payload:
            self.writer.write(payload)
        elif opcode in (0, 1):
            self._responses[msg_id] = (opcode, payload.decode(), time.monotonic())
        del self._sent_messages[msg_id]

    def deliver(self, payload, *, opcode=4, msg_id=None):
        self._handle_message(self.reserve() if msg_id is None else msg_id, opcode, payload)


class FakeComms:
    def __init__(self, robot, num_buses=4):
        self.robot = robot
        self.num_can_endpoints = num_buses
        self.config = SimpleNamespace(teensy_candump_update_frequency=30.)
        self._teensy_handler = Handler(robot.data_monitor_service.candump_writer)
        self.sent = []
        self.on_send = None
        self.ack = True

    def cansend(self, bus, *, extended, can_id, data):
        msg_id = self._teensy_handler.reserve()
        self.sent.append((bus, extended, can_id, data))
        if self.ack:
            self._teensy_handler.deliver(b'', opcode=0, msg_id=msg_id)
        if self.on_send:
            self.on_send(bus, can_id, data)
        return msg_id


def robot(num_buses=4):
    records = []
    item = SimpleNamespace(data_monitor_service=SimpleNamespace(
        candump_writer=SimpleNamespace(write=records.append)), actuators_by_name={})
    item.comms_manager = FakeComms(item, num_buses)
    item.records = records
    return item


def configs(version='L6', timeout=.004, attempts=1, **updates):
    return {side: HandCanConfig(name=side + '_hand', id=can_id, version=version,
                               message_block_timeout=timeout, message_send_attempts=attempts, **updates)
            for side, can_id in (('left', 0x28), ('right', 0x27))}


class HandTransportTests(unittest.TestCase):
    def setUp(self):
        self.robot = robot()
        self.comms = self.robot.comms_manager
        self.handler = self.comms._teensy_handler
        self.adapters = []

    def tearDown(self):
        for adapter in self.adapters:
            adapter.close()

    def attach(self, selected=('left', 'right'), *, use_arm_endpoints=False, **config_updates):
        result = attach_hands(self.robot, configs(**config_updates), sides=selected,
                              use_arm_endpoints=use_arm_endpoints)
        self.adapters.append(result)
        return result

    def arm_endpoints(self, left=2, right=3):
        self.comms.num_can_endpoints = 5
        arms = {}
        for side, endpoint in (('left', left), ('right', right)):
            endpoints = endpoint if isinstance(endpoint, tuple) else (endpoint,) * 7
            motors = {side + '_motor_' + str(index): SimpleNamespace(config=SimpleNamespace(
                name=side + '_motor_' + str(index), id=10 + index, endpoint=value))
                for index, value in enumerate(endpoints)}
            arms[side + '_arm'] = SimpleNamespace(actuators_by_name=motors)
        self.robot.arms_system = SimpleNamespace(**arms)

    def reply_on(self, endpoints, values=(0, 255, 17, 88, 123, 9), *, offset=8, dlc=7):
        def send(bus, can_id, data):
            if data == b'\x01' and endpoints.get(can_id) == bus:
                self.handler.deliver(frame(bus, can_id + offset, values, dlc=dlc))
        self.comms.on_send = send

    def test_attach_and_close_send_nothing_and_restore_sdk_handler(self):
        original = self.handler._handle_message
        hands = self.attach(('left',))
        self.assertIsNone(hands.right_hand)
        self.assertIsNone(hands.left_hand.bus)
        self.assertFalse(self.comms.sent)
        self.assertNotEqual(self.handler._handle_message, original)
        hands.close()
        hands.close()
        self.assertEqual(self.handler._handle_message, original)
        self.assertFalse(self.comms.sent)

    def test_discover_every_endpoint_with_read_only_queries_without_guessing_arm_bus(self):
        self.robot.arms_system = SimpleNamespace(left_arm=SimpleNamespace(
            actuators_by_name={'arm': SimpleNamespace(config=SimpleNamespace(endpoint=1))}))
        hands = self.attach(('left',))
        self.reply_on({0x28: 3})
        self.assertEqual(read_hand_position(hands.left_hand), [0,255,17,88,123,9])
        self.assertEqual(hands.left_hand.bus, 3)
        self.assertEqual(self.comms.sent, [(bus, False, 0x28, b'\x01') for bus in range(4)])
        self.assertFalse(any(data[0] in (2,5) for bus, extended, can_id, data in self.comms.sent))

    def test_setters_require_successful_discovery_before_any_write(self):
        hand = self.attach(('left',)).left_hand
        for name in ('set_torque', 'set_speed', 'set_position'):
            with self.assertRaisesRegex(RuntimeError, 'Discover'):
                getattr(hand, name)([100]*6)
        self.assertFalse(self.comms.sent)

    def test_each_hand_uses_same_side_sdk_arm_endpoint_without_fixed_bus_indices(self):
        for left, right in ((3, 2), (2, 4), (4, 4)):
            with self.subTest(left=left, right=right):
                self.arm_endpoints(left, right)
                hands = self.attach(use_arm_endpoints=True)
                self.assertFalse(self.comms.sent)  # Resolving endpoints sends nothing.
                self.assertIsNone(hands.left_hand.bus)
                self.assertIsNone(hands.right_hand.bus)
                self.reply_on({0x28: left, 0x27: right})
                self.assertEqual(hands.left_hand.read_positions(), [0, 255, 17, 88, 123, 9])
                self.assertEqual(hands.right_hand.read_positions(), [0, 255, 17, 88, 123, 9])
                self.assertEqual((hands.left_hand.bus, hands.right_hand.bus), (left, right))
                self.assertEqual(self.comms.sent, [(left, False, 0x28, b'\x01'),
                                                 (right, False, 0x27, b'\x01')])
                hands.close()
                self.comms.sent.clear()

    def test_unrelated_can1_queue_error_is_never_probed_when_arms_resolve_elsewhere(self):
        self.arm_endpoints(2, 3)
        hands = self.attach(use_arm_endpoints=True)
        self.comms.ack = False

        def send(bus, can_id, data):
            msg_id = self.handler._next_id
            if bus == 1:
                self.handler.deliver(b'Failed condition ``can_write(bus, &msg)``: Failed to send CAN message on bus 1! Errno: No buffer space available',
                                     opcode=1, msg_id=msg_id)
                return
            self.handler.deliver(b'', opcode=0, msg_id=msg_id)
            self.handler.deliver(frame(bus, can_id + 8))

        self.comms.on_send = send
        hands.left_hand.read_positions()
        hands.right_hand.read_positions()
        self.assertEqual([entry[0] for entry in self.comms.sent], [2, 3])
        self.assertIsNone(hands._transport._error)
        self.assertEqual(self.handler._responses, {})

    def test_arm_endpoint_discovery_requires_fresh_feedback_from_same_side_bus(self):
        self.arm_endpoints(2, 3)
        hand = self.attach(('left',), use_arm_endpoints=True, timeout=.002, attempts=2).left_hand
        self.comms.on_send = lambda bus, can_id, data: self.handler.deliver(
            frame(3, 0x30) + frame(2, 0x30, stamp=0) + frame(2, 0x2f))
        with self.assertRaises(TimeoutError):
            hand.read_positions()
        self.assertIsNone(hand.bus)
        self.assertEqual(self.comms.sent, [(2, False, 0x28, b'\x01')] * 2)
        count = len(self.comms.sent)
        with self.assertRaisesRegex(RuntimeError, 'Discover'):
            hand.set_torque(100)
        self.assertEqual(len(self.comms.sent), count)

    def test_missing_arm_motors_and_unresolved_or_mixed_endpoints_fail_before_attachment(self):
        invalid = (None, 255, -1, 5, True, 2., '2', (2, 3))
        for endpoint in invalid:
            with self.subTest(endpoint=endpoint):
                self.arm_endpoints(left=endpoint)
                with self.assertRaisesRegex(RuntimeError, 'arm.*(endpoint|motors)'):
                    self.attach(('left',), use_arm_endpoints=True)
                self.assertFalse(hasattr(self.comms, '_quest_hand_transport'))
                self.assertFalse(self.comms.sent)
        for arm in (None, SimpleNamespace(), SimpleNamespace(actuators_by_name={}),
                    SimpleNamespace(actuators_by_name=[]),
                    SimpleNamespace(actuators_by_name={'motor': SimpleNamespace()})):
            with self.subTest(arm=arm):
                self.robot.arms_system = SimpleNamespace(left_arm=arm)
                with self.assertRaises(RuntimeError):
                    self.attach(('left',), use_arm_endpoints=True)
                self.assertFalse(hasattr(self.comms, '_quest_hand_transport'))
                self.assertFalse(self.comms.sent)
        self.robot.arms_system = None
        with self.assertRaisesRegex(RuntimeError, 'Initialized left arm'):
            self.attach(('left',), use_arm_endpoints=True)
        self.assertFalse(self.comms.sent)

    def test_only_selected_arms_are_required_and_all_are_validated_before_attachment(self):
        self.arm_endpoints()
        self.robot.arms_system.right_arm = None
        with self.assertRaisesRegex(RuntimeError, 'Initialized right arm'):
            self.attach(use_arm_endpoints=True)
        self.assertFalse(hasattr(self.comms, '_quest_hand_transport'))
        self.assertFalse(self.comms.sent)
        hands = self.attach(('left',), use_arm_endpoints=True)
        self.assertIsNone(hands.right_hand)
        self.assertFalse(self.comms.sent)

    def test_explicit_hand_endpoint_must_agree_with_its_arm_and_conflicts_never_fallback(self):
        self.arm_endpoints(2, 3)
        with self.assertRaisesRegex(ValueError, 'hand endpoint 3.*arm endpoint 2'):
            self.attach(('left',), endpoint=3, use_arm_endpoints=True)
        self.assertFalse(hasattr(self.comms, '_quest_hand_transport'))
        self.assertFalse(self.comms.sent)
        hand = self.attach(('left',), endpoint=2, use_arm_endpoints=True).left_hand
        self.reply_on({0x28: 2})
        hand.read_positions()
        self.assertEqual(hand.bus, 2)
        self.assertEqual([entry[0] for entry in self.comms.sent], [2])
        self.adapters[-1].close()
        self.comms.sent.clear()
        self.robot.actuators_by_name['conflict'] = SimpleNamespace(config=SimpleNamespace(
            name='conflict', id=0x30, endpoint=2))
        with self.assertRaisesRegex(ValueError, 'No safe CAN endpoint'):
            self.attach(('left',), use_arm_endpoints=True)
        with self.assertRaisesRegex(ValueError, 'conflicts'):
            self.attach(('left',), endpoint=2, use_arm_endpoints=True)
        self.assertFalse(hasattr(self.comms, '_quest_hand_transport'))
        self.assertFalse(self.comms.sent)

    def test_enobufs_on_actual_arm_bus_during_discovery_read_or_write_remains_fatal(self):
        for endpoint, operation in ((1, 'discovery'), (2, 'read'), (2, 'write')):
            with self.subTest(endpoint=endpoint, operation=operation):
                self.arm_endpoints(left=endpoint)
                hand = self.attach(('left',), use_arm_endpoints=True).left_hand
                if operation != 'discovery':
                    self.reply_on({0x28: endpoint})
                    hand.read_positions()
                self.comms.ack = False
                message = ('Failed condition ``can_write(bus, &msg)``: Failed to send CAN message on bus '
                           + str(endpoint) + '! Errno: No buffer space available').encode()
                self.comms.on_send = None
                if operation == 'write':
                    hand.set_speed(150)
                    self.handler.deliver(message, opcode=1, msg_id=self.handler._next_id)
                else:
                    self.comms.on_send = lambda bus, can_id, data: self.handler.deliver(
                        message, opcode=1, msg_id=self.handler._next_id)
                    with self.assertRaisesRegex(RuntimeError, 'CAN send failed'):
                        hand.read_positions()
                self.assertIsNotNone(hand._transport._error)
                count = len(self.comms.sent)
                with self.assertRaisesRegex(RuntimeError, 'transport failed'):
                    hand.set_position(0)
                self.assertEqual(len(self.comms.sent), count)
                self.assertTrue(all(bus == endpoint for bus, *_ in self.comms.sent))
                hand._transport.close()
                self.comms.ack = True
                self.comms.on_send = None
                self.comms.sent.clear()

    def test_independent_left_and_right_l6_reply_ids_and_selected_sides(self):
        hands = self.attach()
        self.reply_on({0x28: 2, 0x27: 1})
        self.assertEqual(hands.left_hand.read_positions(), [0,255,17,88,123,9])
        self.assertEqual(hands.right_hand.read_positions(), [0,255,17,88,123,9])
        self.assertEqual((hands.left_hand.reply_id, hands.right_hand.reply_id), (0x30, 0x2f))
        self.assertEqual((hands.left_hand.bus, hands.right_hand.bus), (2,1))
        self.assertEqual((hands.left_hand.config.version, hands.right_hand.config.version), ('L6','L6'))

    def test_o6_is_explicit_and_uses_own_id(self):
        hand = self.attach(('left',), version='O6').left_hand
        self.reply_on({0x28: 2}, offset=0)
        self.assertEqual(hand.read_positions(), [0,255,17,88,123,9])
        self.assertEqual(hand.reply_id, 0x28)
        self.assertEqual(hand.config.version, 'O6')

    def test_l6_own_id_replies_bind_both_hands_without_changing_model(self):
        self.arm_endpoints(2, 3)
        hands = self.attach(use_arm_endpoints=True)
        self.reply_on({0x28: 2, 0x27: 3}, offset=0)
        self.assertEqual(hands.left_hand.read_positions(), [0, 255, 17, 88, 123, 9])
        self.assertEqual(hands.right_hand.read_positions(), [0, 255, 17, 88, 123, 9])
        self.assertEqual((hands.left_hand.reply_id, hands.right_hand.reply_id), (0x28, 0x27))
        self.assertEqual((hands.left_hand.config.version, hands.right_hand.config.version), ('L6', 'L6'))
        self.assertEqual(self.comms.sent, [(2, False, 0x28, b'\x01'), (3, False, 0x27, b'\x01')])

    def test_saved_left_reply_bytes_bind_own_id_and_preserve_l6_write_protocol(self):
        self.arm_endpoints(2, 3)
        hand = self.attach(('left',), use_arm_endpoints=True).left_hand
        self.assertEqual(hand.reply_id, 0x30)  # Legacy default until fresh discovery.
        for payload, expected in (('01bdf9fefeffff', [189, 249, 254, 254, 255, 255]),
                                  ('01e7fffefeffff', [231, 255, 254, 254, 255, 255])):
            data = bytes.fromhex(payload)
            self.reply_on({0x28: 2}, values=data[1:], offset=0, dlc=len(data))
            self.assertEqual(read_hand_position(hand), expected)
            self.assertEqual((hand.bus, hand.reply_id, hand.config.version), (2, 0x28, 'L6'))
        self.assertEqual(set(hand._transport._hands), {(2, 0x28)})
        hand.set_speed(150)
        self.assertEqual(self.comms.sent, [(2, False, 0x28, b'\x01'),
                                         (2, False, 0x28, b'\x01'),
                                         (2, False, 0x28, bytes([5] + [150] * 6))])

    def test_l6_hands_can_use_different_reply_conventions_on_their_own_arm_buses(self):
        self.arm_endpoints(3, 2)
        hands = self.attach(use_arm_endpoints=True)

        def send(bus, can_id, data):
            offset = 0 if can_id == 0x28 else 8
            self.handler.deliver(frame(bus, can_id + offset))

        self.comms.on_send = send
        hands.left_hand.read_positions()
        hands.right_hand.read_positions()
        self.assertEqual((hands.left_hand.bus, hands.left_hand.reply_id), (3, 0x28))
        self.assertEqual((hands.right_hand.bus, hands.right_hand.reply_id), (2, 0x2f))
        self.assertEqual(set(hands._transport._hands), {(3, 0x28), (2, 0x2f)})

    def test_o6_does_not_accept_l6_plus_eight_reply_address(self):
        hand = self.attach(('left',), version='O6').left_hand
        self.reply_on({0x28: 2}, offset=8)
        with self.assertRaises(TimeoutError):
            hand.read_positions()
        self.assertIsNone(hand.bus)
        self.assertEqual(hand.reply_id, 0x28)

    def test_l6_two_fresh_aliases_on_one_bus_are_ambiguous_before_any_write(self):
        self.arm_endpoints(2, 3)
        hand = self.attach(('left',), use_arm_endpoints=True).left_hand
        self.comms.on_send = lambda bus, can_id, data: self.handler.deliver(
            frame(bus, 0x28) + frame(bus, 0x30))
        with self.assertRaisesRegex(RuntimeError, "Multiple.*0x28.*0x30"):
            hand.read_positions()
        self.assertIsNone(hand.bus)
        self.assertEqual(hand.reply_id, 0x30)
        self.assertEqual(self.comms.sent, [(2, False, 0x28, b'\x01')])
        with self.assertRaisesRegex(RuntimeError, 'Discover'):
            hand.set_position(0)
        self.assertEqual(len(self.comms.sent), 1)

    def test_learned_reply_id_cannot_be_replaced_by_alternate_alias_feedback_or_error(self):
        for offset in (0, 8):
            with self.subTest(offset=offset):
                hand = self.attach(('left',), endpoint=2).left_hand
                self.reply_on({0x28: 2}, offset=offset)
                hand.read_positions()
                learned_id = 0x28 + offset
                alternate = 0x30 if offset == 0 else 0x28
                self.handler.deliver(RECORD.pack((2 << 5) | 8, alternate, *b'ERROR\x00\x00\x01', time.monotonic_ns()))
                self.assertIsNone(hand._error)
                self.comms.on_send = lambda bus, can_id, data: self.handler.deliver(frame(bus, alternate))
                with self.assertRaises(TimeoutError):
                    hand.read_positions()
                self.assertEqual((hand.bus, hand.reply_id), (2, learned_id))
                self.assertEqual(set(hand._transport._hands), {(2, learned_id)})
                self.reply_on({0x28: 2}, offset=offset)
                self.assertEqual(hand.read_positions(), [0, 255, 17, 88, 123, 9])
                self.adapters[-1].close()

    def test_l6_errors_on_either_candidate_alias_fail_without_sending_a_query(self):
        for reply_id in (0x28, 0x30):
            with self.subTest(reply_id=reply_id):
                hand = self.attach(('left',), endpoint=2).left_hand
                self.handler.deliver(RECORD.pack((2 << 5) | 8, reply_id, *b'ERROR\x00\x00\x01', time.monotonic_ns()))
                with self.assertRaisesRegex(RuntimeError, 'RealHand left_hand failed'):
                    hand.read_positions()
                self.assertIsNone(hand.bus)
                self.assertFalse(self.comms.sent)
                self.adapters[-1].close()

    def test_possible_reply_id_overlap_between_hands_is_rejected_before_listener_installation(self):
        settings = configs()
        settings['right'] = HandCanConfig('right_hand', 0x30, 'L6', .004, 1)
        previous = self.handler._handle_message
        with patch('quest_sdk_hands.TeensyHandTransport', side_effect=AssertionError('Listener must not be constructed')):
            with self.assertRaisesRegex(ValueError, 'share CAN reply ID 0x30'):
                attach_hands(self.robot, settings)
        self.assertEqual(self.handler._handle_message, previous)
        self.assertFalse(hasattr(self.comms, '_quest_hand_transport'))
        self.assertFalse(self.comms.sent)

    def test_reply_alias_overlap_is_allowed_when_same_side_arms_resolve_distinct_buses(self):
        self.arm_endpoints(2, 3)
        settings = configs()
        settings['right'] = HandCanConfig('right_hand', 0x30, 'L6', .004, 1)
        hands = attach_hands(self.robot, settings, use_arm_endpoints=True)
        self.adapters.append(hands)
        self.reply_on({0x28: 2, 0x30: 3}, offset=0)
        hands.left_hand.read_positions()
        hands.right_hand.read_positions()
        self.assertEqual(set(hands._transport._hands), {(2, 0x28), (3, 0x30)})

    def test_either_l6_candidate_id_motor_conflict_rejects_attachment_without_fallback(self):
        self.arm_endpoints(2, 3)
        for can_id in (0x28, 0x30):
            with self.subTest(can_id=can_id):
                self.robot.actuators_by_name = {'conflict': SimpleNamespace(config=SimpleNamespace(
                    name='conflict', id=can_id, endpoint=2))}
                previous = self.handler._handle_message
                with patch('quest_sdk_hands.TeensyHandTransport', side_effect=AssertionError('Listener must not be constructed')):
                    with self.assertRaisesRegex(ValueError, 'No safe CAN endpoint'):
                        self.attach(('left',), use_arm_endpoints=True)
                self.assertEqual(self.handler._handle_message, previous)
                self.assertFalse(hasattr(self.comms, '_quest_hand_transport'))
                self.assertFalse(self.comms.sent)

    def test_dlc7_and_dlc8_replies_preserve_all_six_channels_including_leading_zero(self):
        for dlc in (7,8):
            hand = self.attach(('left',)).left_hand
            self.reply_on({0x28: 2}, dlc=dlc)
            self.assertEqual(read_hand_position(hand), [0,255,17,88,123,9])
            self.adapters[-1].close()

    def test_bound_hand_writes_exact_dlc7_frames_and_noop_enable_disable(self):
        hand = self.attach(('left',)).left_hand
        self.reply_on({0x28: 2})
        hand.read_positions()
        before = len(self.comms.sent)
        hand.set_torque([220,220,200,200,200,200])
        hand.set_speed(150)
        hand.set_position([85,25,150,255,255,255])
        hand.enable()
        hand.disable()
        self.assertEqual(self.comms.sent[before:], [
            (2,False,0x28,bytes([2,220,220,200,200,200,200])),
            (2,False,0x28,bytes([5]+[150]*6)),
            (2,False,0x28,bytes([1,85,25,150,255,255,255])),
        ])

    def test_sent_echoes_short_frames_other_registers_ids_and_stale_frames_are_not_feedback(self):
        hand = self.attach(('left',)).left_hand
        def noise(bus, can_id, data):
            if data != b'\x01':
                return
            self.handler.deliver(b''.join((
                frame(bus,0x30,sent=True), frame(bus,0x30,dlc=1),
                frame(bus,0x30,dlc=6), frame(bus,0x30,register=5),
                frame(bus,0x31), frame(bus,0x30,stamp=0),
                frame(bus,0x80000030), frame(bus,0x128), frame(bus,0x130),
                frame(bus,0x28,sent=True), frame(bus,0x28,dlc=1),
                frame(bus,0x28,dlc=6), frame(bus,0x28,stamp=0), frame(bus,0x28,register=5),
            )))
        self.comms.on_send = noise
        with self.assertRaises(TimeoutError):
            hand.read_positions()
        self.assertIsNone(hand.bus)

    def test_bound_bus_filters_other_endpoints_and_cached_feedback_is_not_new_query_reply(self):
        hand = self.attach(('left',)).left_hand
        self.reply_on({0x28: 2})
        hand.read_positions()
        self.comms.on_send = lambda bus, can_id, data: self.handler.deliver(frame(3, 0x30))
        with self.assertRaises(TimeoutError):
            hand.read_positions()

    def test_multiple_fresh_responders_fail_before_writes(self):
        hand = self.attach(('left',)).left_hand
        self.comms.on_send = lambda bus, can_id, data: self.handler.deliver(frame(bus,0x30)) if bus in (1,3) else None
        with self.assertRaisesRegex(RuntimeError, 'Multiple.*1, 3'):
            hand.read_positions()
        self.assertIsNone(hand.bus)
        self.assertTrue(all(data == b'\x01' for bus, extended, can_id, data in self.comms.sent))
        with self.assertRaisesRegex(RuntimeError, 'Discover'):
            hand.set_position(0)

    def test_discovery_skips_configured_motor_request_and_reply_id_conflicts(self):
        self.robot.actuators_by_name['neck_pitch'] = SimpleNamespace(config=SimpleNamespace(
            name='neck_pitch', id=0x30, endpoint=0))
        hand = self.attach(('left',)).left_hand
        self.reply_on({0x28: 2})
        hand.read_positions()
        self.assertEqual({bus for bus, extended, can_id, data in self.comms.sent}, {1,2,3})
        self.adapters[-1].close()
        with self.assertRaisesRegex(ValueError, 'conflicts'):
            attach_hands(self.robot, configs(endpoint=0), sides=('left',))

    def test_timeouts_are_bounded_and_retry_only_position_queries(self):
        hand = self.attach(('left',), timeout=.002, attempts=2).left_hand
        start = time.monotonic()
        with self.assertRaises(TimeoutError):
            hand.read_positions()
        self.assertLess(time.monotonic()-start, .5)
        self.assertEqual(len(self.comms.sent), 8)
        self.assertTrue(all(data == b'\x01' for bus, extended, can_id, data in self.comms.sent))

    def test_candump_logging_is_preserved_exactly_once_and_unknown_sdk_messages_are_ignored(self):
        hand = self.attach(('left',)).left_hand
        payload = frame(2,0x30)
        self.handler.deliver(payload)
        self.assertEqual(self.robot.records, [payload])
        self.assertEqual(hand._sequence, 1)
        self.handler.deliver(payload, msg_id=987654321)
        self.assertEqual(self.robot.records, [payload])
        self.assertEqual(hand._sequence, 1)

    def test_empty_and_unknown_register_frames_are_ignored(self):
        hand = self.attach(('left',)).left_hand
        self.handler.deliver(b'')
        payload = frame(2,0x30,register=0xff)
        self.handler.deliver(payload)
        self.assertEqual(hand._sequence, 0)
        self.assertEqual(self.robot.records, [payload])

    def test_own_can_acks_are_consumed_but_other_sdk_responses_are_preserved(self):
        hand = self.attach(('left',)).left_hand
        self.reply_on({0x28: 2})
        self.handler._responses[987] = (0,'another SDK command',1.)
        hand.read_positions()
        hand.set_speed(150)
        self.assertEqual(self.handler._responses, {987:(0,'another SDK command',1.)})

    def test_async_can_send_error_stops_future_commands(self):
        hand = self.attach(('left',)).left_hand
        self.reply_on({0x28: 2})
        hand.read_positions()
        self.comms.ack = False
        hand.set_speed(150)
        msg_id = self.handler._next_id
        self.handler.deliver(b'CAN transmit failed', opcode=1, msg_id=msg_id)
        count = len(self.comms.sent)
        with self.assertRaisesRegex(RuntimeError, 'transport failed'):
            hand.set_position(0)
        self.assertEqual(len(self.comms.sent), count)

    def test_missing_can_ack_stops_future_commands_with_bounded_timeout(self):
        hand = self.attach(('left',), timeout=.003).left_hand
        self.reply_on({0x28: 2})
        hand.read_positions()
        self.comms.ack = False
        hand.set_speed(150)
        count = len(self.comms.sent)
        with patch('quest_sdk_hands.time.monotonic', return_value=time.monotonic()+1):
            with self.assertRaisesRegex(RuntimeError, 'timed out'):
                hand.set_position(0)
        self.assertEqual(len(self.comms.sent), count)

    def test_hand_error_and_malformed_batch_never_throw_on_comms_thread(self):
        hand = self.attach(('left',)).left_hand
        self.handler.deliver(RECORD.pack((2<<5)|8, 0x30, *b'ERROR\x00\x00\x01', time.monotonic_ns()))
        with self.assertRaisesRegex(RuntimeError, 'failed'):
            hand.read_positions()
        self.adapters[-1].close()
        hand = self.attach(('left',)).left_hand
        self.handler.deliver(b'bad')
        with self.assertRaisesRegex(RuntimeError, 'transport failed'):
            hand.read_positions()
        self.assertEqual(self.robot.records[-1], b'bad')

    def test_close_wakes_pending_query_without_sending_a_stop_or_open_command(self):
        hand = self.attach(('left',), timeout=1).left_hand
        results = []
        def query():
            try:
                hand.read_positions()
            except Exception as exc:
                results.append(exc)
        thread = threading.Thread(target=query)
        thread.start()
        deadline = time.monotonic()+.3
        while not self.comms.sent and time.monotonic() < deadline:
            time.sleep(.001)
        self.adapters[-1].close()
        thread.join(.3)
        self.assertFalse(thread.is_alive())
        self.assertEqual(len(results), 1)
        self.assertIsInstance(results[0], RuntimeError)
        self.assertTrue(all(data == b'\x01' for bus, extended, can_id, data in self.comms.sent))

    def test_duplicate_attachment_does_not_replace_original_listener(self):
        self.attach(('left',))
        listener = self.handler._handle_message
        with self.assertRaisesRegex(RuntimeError, 'Close the existing'):
            self.attach(('right',))
        self.assertIs(self.handler._handle_message, listener)

    def test_disabled_recording_or_changed_transport_fails_before_io(self):
        self.robot.data_monitor_service.candump_writer = None
        with self.assertRaisesRegex(RuntimeError, 'candump_enabled'):
            self.attach(('left',))
        self.assertFalse(self.comms.sent)

    def test_changed_sdk_call_signature_fails_before_io(self):
        self.comms.cansend = lambda iface, payload: None
        with self.assertRaisesRegex(RuntimeError, 'transport signature'):
            self.attach(('left',))
        self.assertFalse(self.comms.sent)

    def test_invalid_values_and_blocking_writes_are_rejected_without_io(self):
        hand = self.attach(('left',)).left_hand
        self.reply_on({0x28: 2})
        hand.read_positions()
        count = len(self.comms.sent)
        for values in ([0]*5,[256]*6,[-1]*6,[.5]*6,[True]*6,['1']*6):
            with self.assertRaises(ValueError):
                hand.set_position(values)
        with self.assertRaisesRegex(ValueError, 'Blocking'):
            hand.set_speed(150,block=True)
        self.assertEqual(len(self.comms.sent), count)

    def test_empty_selection_is_pure_and_versions_are_not_aliased(self):
        empty = attach_hands(self.robot, {}, sides=())
        empty.close()
        self.assertIsNone(empty.left_hand)
        self.assertFalse(self.comms.sent)
        for value in ('L7',106,6,None):
            with self.assertRaises(ValueError):
                HandCanConfig('hand',0x28,version=value)


class BranchProtocolContractTests(unittest.TestCase):
    def test_listener_runs_with_actual_branch_response_handler_without_initializing_sdk(self):
        sdk = ROOT.parents[3]/'feathersdk'/'src'/'feathersdk'
        source = sdk/'robot'/'comms'/'comms_manager.py'
        if not source.exists():
            self.skipTest('Branch SDK source is unavailable in this checkout')
        qdefs = sdk/'quill_defs'/'python_qdefs'
        commands = runpy.run_path(str(qdefs/'teensy_commands_qdef.py'))
        telemetry = runpy.run_path(str(qdefs/'telemetry_qdef.py'))
        tree = ast.parse(source.read_text())
        cls = next(node for node in tree.body if isinstance(node,ast.ClassDef) and node.name == '_TeensyHandler')
        method = next(node for node in cls.body if isinstance(node,ast.FunctionDef) and node.name == '_handle_message')
        method.decorator_list = []
        namespace = dict(commands, **telemetry, currtime=time.monotonic,
                         warning=lambda *args: None, error=lambda *args: None,
                         _UNTRACKED_TEENSY_RX_OPCODES=frozenset({3,4}), _EMPTY_BYTES=b'')
        exec(compile(ast.fix_missing_locations(ast.Module(body=[method],type_ignores=[])),str(source),'exec'),namespace)
        item = robot()
        item.data_monitor_service.teensy_message_writer = None
        handler = item.comms_manager._teensy_handler
        handler.comms = item.comms_manager
        handler._handle_message = MethodType(namespace['_handle_message'],handler)
        previous = handler._handle_message
        adapter = attach_hands(item, configs(), sides=('left',))
        try:
            def send(bus, can_id, data):
                if bus == 3 and data == b'\x01':
                    handler.deliver(frame(bus,can_id+8))
            item.comms_manager.on_send = send
            self.assertEqual(adapter.left_hand.read_positions(), [0,255,17,88,123,9])
            adapter.left_hand.set_speed(150)
            self.assertEqual(len(item.records), 1)
            self.assertEqual(handler._responses, {})
        finally:
            adapter.close()
        self.assertEqual(handler._handle_message, previous)

    def test_candump_binary_layout_and_opcode_match_branch_generated_defs(self):
        sdk = ROOT.parents[3]/'feathersdk'/'src'/'feathersdk'/'quill_defs'/'python_qdefs'
        telemetry = sdk/'telemetry_qdef.py'
        commands = sdk/'teensy_commands_qdef.py'
        if not telemetry.exists():
            self.skipTest('Branch SDK source is unavailable in this checkout')
        # Generated definitions are plain data modules. Reading them cannot initialize SDK hardware.
        qdef = runpy.run_path(str(telemetry))
        self.assertEqual(qdef['CandumpTelemetry']._STRUCT.format, RECORD.format)
        self.assertEqual(qdef['CandumpTelemetry']._STRUCT.size, 21)
        values = {n.targets[0].id: ast.literal_eval(n.value) for n in ast.walk(ast.parse(commands.read_text()))
                  if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name)
                  and n.targets[0].id in ('RESP_CANDUMP','RESP_ERROR','RESP_SUCCESS')}
        self.assertEqual(values, dict(RESP_CANDUMP=4, RESP_ERROR=1, RESP_SUCCESS=0))


if __name__ == '__main__':
    unittest.main()
