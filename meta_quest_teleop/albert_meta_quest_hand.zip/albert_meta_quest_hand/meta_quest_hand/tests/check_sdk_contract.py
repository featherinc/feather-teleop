"""Check app calls and real branch SDK configuration without creating hardware.

Example:
  python3 -B check_sdk_contract.py APP_DIR --sdk-src REPO/feathersdk/src \
      --report /tmp/meta-quest-sdk-offline-7scrdite/sdk-contract.json

Adapter types can be supplied as `module:Class` for --hand-type/--nav-type.
This imports actual SDK code and validates configs; it never initializes a robot,
actuator, system, transport, camera, numerical worker, or background thread.
"""
from __future__ import annotations

import argparse
import ast
import functools
import importlib
import inspect
import itertools
import json
import math
import os
from pathlib import Path
import sys
import threading
import traceback
from types import SimpleNamespace


sys.dont_write_bytecode = True
os.environ['NUMBA_DISABLE_JIT'] = '1'
LIVE_BASE_NAMES = {'FeatherRobot', 'CommsManager', '_TeensyHandler', 'RobotModule', 'Actuator',
                   'Motor', 'RealHand', 'RobstrideAdminControl', 'URDFLoader'}
_CONSTRUCTOR_TRAPS = {}


def denied(*args, **kwargs):
    raise RuntimeError('Hardware constructors/transports/threads are forbidden in SDK contract checks')


def guard(event, args):
    if event.startswith('socket.') and event not in ('socket.gethostname',):
        denied()
    if event in ('subprocess.Popen', 'os.system', 'os.posix_spawn', 'os.fork', 'pty.spawn'):
        denied()
    if event == 'open' and isinstance(args[0], (str, bytes)):
        path = os.fsdecode(args[0])
        if path.startswith('/dev/') and path not in ('/dev/null', '/dev/urandom', '/dev/random'):
            denied()
        flags = args[2]
        if flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND):
            if REPORT_DIRECTORY is None or not Path(path).resolve().is_relative_to(REPORT_DIRECTORY):
                raise RuntimeError(f'SDK contract check blocked file write: {path}')
    if event in ('os.mkdir', 'os.remove', 'os.rename', 'os.rmdir', 'os.chmod', 'os.chown'):
        path = args[0]
        if isinstance(path, (str, bytes)) and (REPORT_DIRECTORY is None or
                not Path(os.fsdecode(path)).resolve().is_relative_to(REPORT_DIRECTORY)):
            raise RuntimeError(f'SDK contract check blocked filesystem mutation: {event}: {path}')


def profile(frame, event, arg):
    if event == 'call' and frame.f_code.co_name in ('__init__', '__new__'):
        owner = frame.f_locals.get('self', frame.f_locals.get('cls'))
        cls = owner if isinstance(owner, type) else type(owner)
        if any(base.__name__ in LIVE_BASE_NAMES and base.__module__.startswith('feathersdk.robot.')
               for base in cls.__mro__):
            denied()


def install_constructor_traps():
    """Trap actual live classes in memory without altering configs/allocator.

    A profile callback that raises can be removed by Python. Direct constructor
    traps remain active after every expected rejection and protect subsequent
    checks even if profiling is unset. Hardware subclasses inherit these traps.
    The generic Configurable allocator and every native config class are intact.
    """
    import feathersdk  # Audited import; this defines classes and memory models only.
    classes = set()
    for module_name, module in tuple(sys.modules.items()):
        if not module_name.startswith('feathersdk.robot.') or module is None:
            continue
        for cls in tuple(vars(module).values()):
            if (inspect.isclass(cls) and cls.__module__.startswith('feathersdk.robot.')
                    and any(base.__name__ in LIVE_BASE_NAMES and base.__module__.startswith('feathersdk.robot.')
                            for base in cls.__mro__)):
                classes.add(cls)
    for cls in classes:
        if cls in _CONSTRUCTOR_TRAPS:
            continue
        original_init, original_new = cls.__init__, cls.__new__
        @functools.wraps(original_init)
        def blocked_init(*args, **kwargs):
            denied()
        @functools.wraps(original_new)
        def blocked_new(*args, **kwargs):
            denied()
        cls.__init__ = blocked_init
        cls.__new__ = staticmethod(blocked_new)
        _CONSTRUCTOR_TRAPS[cls] = (original_init, original_new)
    assert classes, 'No native hardware classes were available to trap'
    return sorted(cls.__module__ + '.' + cls.__name__ for cls in classes)


def class_from_spec(spec):
    module, name = spec.split(':', 1)
    return getattr(importlib.import_module(module), name)


def source_config(path, ec_per_rot):
    """Capture original literal declarations without importing any original SDK.

    The inspected project's system files contain only declarations/functions.
    Stand-in constructors retain every keyword, so the migration's alias/filter
    logic is not involved in deriving the expected values.
    """
    tree = ast.parse(path.read_text(encoding='utf-8'))
    imports = [node for node in tree.body if isinstance(node, ast.ImportFrom)]
    env = {'__builtins__': {}, 'NumericRange': lambda *args: tuple(args),
           'deg2rad': math.radians, 'pi': math.pi, 'tau': math.tau, 'EC_PER_ROT': ec_per_rot}
    class EnumNames:
        def __getattr__(self, name):
            return name
    for node in imports:
        for item in node.names:
            name = item.asname or item.name
            if name.endswith('Config'):
                env[name] = lambda **kwargs: SimpleNamespace(**kwargs)
            elif name in ('RobstrideVersion', 'RealHandVersion', 'SafeStopPolicy'):
                env[name] = EnumNames()
    tree.body = [node for node in tree.body if not isinstance(node, (ast.Import, ast.ImportFrom))]
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef):
            node.returns = None
            for argument in node.args.args + node.args.kwonlyargs:
                argument.annotation = None
    exec(compile(ast.fix_missing_locations(tree), str(path), 'exec'), env)
    candidates = [value for key, value in env.items() if key.endswith('_system_config')]
    assert len(candidates) == 1, path
    return candidates[0]


def compare_preserved(expected, actual, path, removed):
    if isinstance(expected, SimpleNamespace):
        for name, item in vars(expected).items():
            if hasattr(actual, name):
                compare_preserved(item, getattr(actual, name), path + '.' + name, removed)
            else:
                removed.append(path + '.' + name)
    elif isinstance(expected, dict):
        assert set(expected) == set(actual), path
        for key in expected:
            compare_preserved(expected[key], actual[key], path + '.' + str(key), removed)
    elif isinstance(expected, (tuple, list)):
        assert len(expected) == len(actual), path
        for index, item in enumerate(expected):
            compare_preserved(item, actual[index], path + '.' + str(index), removed)
    elif isinstance(expected, float):
        assert math.isclose(expected, actual, rel_tol=1e-12, abs_tol=1e-12), (path, expected, actual)
    else:
        value = actual.name if hasattr(actual, 'name') and hasattr(actual, 'value') else actual
        if path.endswith('.safe_stop_policy') and expected == 'DO_NOTHING' and value == 'CANNOT_ENTER_SAFE_STOP':
            return  # Both SDK generations keep safe-stop motion disabled.
        assert expected == value, (path, expected, value)


def dotted(node):
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        root = dotted(node.value)
        return root + '.' + node.attr if root else ''
    if isinstance(node, ast.Subscript):
        return dotted(node.value) + '[]'
    if isinstance(node, ast.Call):
        return dotted(node.func) + '()'
    return ''


def all_sources(project):
    for path in sorted(project.glob('*.py')):
        yield str(path), path.read_text(encoding='utf-8-sig')
    notebook = project / 'meta_quest_hand.ipynb'
    if not notebook.exists():
        notebook = project / 'quest_trajectory_replay.ipynb'
    for index, cell in enumerate(json.loads(notebook.read_text(encoding='utf-8'))['cells']):
        if cell['cell_type'] == 'code':
            yield str(notebook) + ':' + str(cell.get('id', index)), ''.join(cell['source'])


def sanitized_dump(value):
    if hasattr(type(value), 'model_fields'):
        result = {name: sanitized_dump(getattr(value, name)) for name in type(value).model_fields}
        if MOTOR_CONFIG_TYPE is not None and isinstance(value, MOTOR_CONFIG_TYPE):
            # The generic SDK schema ceiling is lower than its per-version CAN
            # encoder limit. Gain safety is checked separately against qdefs.
            result['default_op_kp'] = result['default_op_kd'] = 0.0
        return result
    if isinstance(value, dict):
        return {key: sanitized_dump(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return type(value)(sanitized_dump(item) for item in value)
    return value


def validate_model(value):
    if hasattr(type(value), 'model_fields'):
        # model_copy(update=...) skips pydantic validation; validate actual nested types.
        if MOTOR_CONFIG_TYPE is not None and isinstance(value, MOTOR_CONFIG_TYPE):
            assert type(value) is MOTOR_CONFIG_TYPE, 'Native Configurable requires exact RobstrideMotorConfig type'
            for field, limits in (('default_op_kp', KP_LIMITS), ('default_op_kd', KD_LIMITS)):
                gain = getattr(value, field)
                assert math.isfinite(gain) and 0 <= gain <= limits[value.version], (value.name, field, gain)
        type(value).model_validate(sanitized_dump(value), strict=True)
        for name in type(value).model_fields:
            validate_model(getattr(value, name))
    elif isinstance(value, (tuple, list)):
        for item in value:
            validate_model(item)
    elif isinstance(value, dict):
        for item in value.values():
            validate_model(item)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('project', type=Path)
    parser.add_argument('--sdk-src', type=Path, required=True)
    parser.add_argument('--config', type=Path)
    parser.add_argument('--urdf', type=Path)
    parser.add_argument('--hand-type')
    parser.add_argument('--nav-type')
    parser.add_argument('--owner-type', action='append', default=[], metavar='OWNER=MODULE:CLASS')
    parser.add_argument('--config-loader', default='quest_trajectory_replay:load_replay_config')
    parser.add_argument('--hand-config-loader')
    parser.add_argument('--standalone-hands', action='store_true')
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    global REPORT_DIRECTORY
    REPORT_DIRECTORY = args.report.resolve().parent if args.report else None
    sys.addaudithook(guard)
    sys.setprofile(profile)
    threading.Thread.start = denied
    project = args.project.resolve(strict=True)
    sdk_src = args.sdk_src.resolve(strict=True)
    sys.path[:0] = [str(project), str(sdk_src)]
    report = {'project': str(project), 'checks': [], 'issues': [], 'raw_sdk_findings': []}

    def check(name, action):
        try:
            result = action()
            report['checks'].append({'name': name, 'result': result, 'success': True})
            return result
        except Exception as exc:
            report['issues'].append({'name': name, 'error': f'{type(exc).__name__}: {exc}'})
            report['checks'].append({'name': name, 'success': False})
            return None
        finally:
            sys.setprofile(profile)

    try:
        import feathersdk
        assert Path(feathersdk.__file__).resolve().is_relative_to(sdk_src), feathersdk.__file__
        report['sdk'] = {'file': feathersdk.__file__, 'version': feathersdk.__version__}
        from feathersdk.robot.actuators.realhand import RealHand, RealHandVersion
        from feathersdk.robot.actuators.motor import Motor
        from feathersdk.robot.actuators.robstride.robstride_motor import RobstrideMotor, RobstrideMotorTelemetry
        from feathersdk.robot.actuators.robstride import RobstrideMotorConfig
        from feathersdk.quill_defs.python_qdefs.robstride_qdef import rob_kp_lim, rob_kd_lim
        from feathersdk.robot.actuator_systems.arms_system import Robstride7MArm, ArmsSystem
        from feathersdk.robot.actuator_systems.torso_system import LinearEZMotionTorsoSystem
        from feathersdk.robot.actuator_systems.neck_system import TwoDOFRobstrideNeckSystem
        from feathersdk.robot.actuator_systems.navigation_system import ThreeWheelHolonomicRobstrideNavigationSystem
        from feathersdk.robot.robot import initialize_feather_system
        from feathersdk.robot.comms.comms_manager import CommsManager
        from feathersdk.configs import load_configs
        app_config_loader = class_from_spec(args.config_loader)
        global MOTOR_CONFIG_TYPE, KP_LIMITS, KD_LIMITS
        MOTOR_CONFIG_TYPE, KP_LIMITS, KD_LIMITS = RobstrideMotorConfig, rob_kp_lim, rob_kd_lim
        report['constructor_traps'] = install_constructor_traps()

        def constructor_guards():
            guarded = []
            for module_name, module in tuple(sys.modules.items()):
                if not module_name.startswith('feathersdk.robot.') or module is None:
                    continue
                for name, cls in tuple(vars(module).items()):
                    if (not inspect.isclass(cls) or cls.__module__ != module_name or inspect.isabstract(cls)
                            or not any(base.__name__ in LIVE_BASE_NAMES for base in cls.__mro__)):
                        continue
                    positional, keyword = [], {}
                    for parameter in inspect.signature(cls.__init__).parameters.values():
                        if parameter.name == 'self' or parameter.default is not inspect.Parameter.empty:
                            continue
                        if parameter.kind in (parameter.POSITIONAL_ONLY, parameter.POSITIONAL_OR_KEYWORD):
                            positional.append(None)
                        elif parameter.kind == parameter.KEYWORD_ONLY:
                            keyword[parameter.name] = None
                    try:
                        sys.setprofile(profile)
                        cls(*positional, **keyword)
                    except RuntimeError as exc:
                        assert 'forbidden in SDK contract checks' in str(exc), (name, exc)
                        guarded.append(module_name + '.' + name)
                    else:
                        raise AssertionError('Hardware constructor was not blocked: ' + name)
                    finally:
                        sys.setprofile(profile)
            assert guarded, 'No hardware constructors were checked'
            return guarded
        check('hardware constructor entries rejected before execution', constructor_guards)

        hand_type = class_from_spec(args.hand_type) if args.hand_type else RealHand
        nav_type = class_from_spec(args.nav_type) if args.nav_type else ThreeWheelHolonomicRobstrideNavigationSystem
        types = {'hand': hand_type, 'left_arm': Robstride7MArm, 'right_arm': Robstride7MArm,
                 'arm': Robstride7MArm, 'arms': ArmsSystem, 'torso': LinearEZMotionTorsoSystem,
                 'neck': TwoDOFRobstrideNeckSystem, 'nav': nav_type, 'navigation': nav_type, 'motor': RobstrideMotor,
                 'comms': CommsManager, 'self.comms': CommsManager, 'robot.comms_manager': CommsManager,
                 'self._navigation': ThreeWheelHolonomicRobstrideNavigationSystem}
        for specification in args.owner_type:
            owner, type_spec = specification.split('=', 1)
            types[owner] = class_from_spec(type_spec)
        for label, value in [('realhand_is_motor', issubclass(RealHand, Motor)),
                              ('realhand_versions', [item.name for item in RealHandVersion])]:
            report['raw_sdk_findings'].append({'name': label, 'value': value})

        def owner_type(owner, location):
            if owner == 'arm' and location.endswith('quest_parallel_ik.py'):
                # This module's arm is the numerical worker, not an SDK arm.
                from quest_television_ik import ArmModel
                return ArmModel
            if owner.startswith('selected_hands()[]') or owner.startswith('manipulation.'):
                return hand_type
            if owner == 'motor.telemetry':
                return RobstrideMotorTelemetry
            return types.get(owner)

        checked = []
        for location, source in all_sources(project):
            tree = ast.parse(source)
            for node in ast.walk(tree):
                if isinstance(node, ast.Call):
                    if isinstance(node.func, ast.Attribute):
                        owner, method = dotted(node.func.value), node.func.attr
                        cls = owner_type(owner, location)
                        if cls is None:
                            continue
                        if location.endswith('quest_sdk_compat.py') and owner == 'self._navigation' and method in (
                                'set_speed', 'orient_and_move', 'rotate_in_place'):
                            continue  # Only used if the object has the prior SDK's complete public API.
                        label = f'{location}:{node.lineno}: {owner}.{method}'
                        def bind_call(cls=cls, method=method, node=node, owner=owner, location=location):
                            func = getattr(cls, method)
                            signature = inspect.signature(func)
                            argument_count = len(node.args)
                            if any(isinstance(arg, ast.Starred) for arg in node.args):
                                if (location.endswith('quest_parallel_ik.py') and owner == 'arm'
                                        and method == 'set_sdk_joint_limits' and len(node.args) == 1
                                        and isinstance(node.args[0], ast.Starred)
                                        and dotted(node.args[0].value) == 'job[]'
                                        and isinstance(node.args[0].value.slice, ast.Constant)
                                        and node.args[0].value.slice.value == 'limits'):
                                    producer = ast.parse((project / 'quest_television_ik.py').read_text(encoding='utf-8'))
                                    pairs = [item.value for item in ast.walk(producer)
                                             if isinstance(item, ast.keyword) and item.arg == 'limits']
                                    assert pairs and all(isinstance(pair, ast.Tuple) and len(pair.elts) == 2
                                                         for pair in pairs), 'Numerical limits producer must provide lower/upper pair'
                                    argument_count = 2
                                else:
                                    raise AssertionError('SDK call with expanded arguments requires manual review')
                            if any(item.arg is None for item in node.keywords):
                                raise AssertionError('SDK call with expanded arguments requires manual review')
                            signature.bind(object(), *[object() for _ in range(argument_count)],
                                           **{item.arg: object() for item in node.keywords})
                            return str(signature)
                        check(label, bind_call)
                        checked.append(label)
                    elif isinstance(node.func, ast.Name) and node.func.id == 'initialize_feather_system':
                        check(f'{location}:{node.lineno}: initialize_feather_system signature',
                              lambda node=node: str(inspect.signature(initialize_feather_system).bind(
                                  *[object() for _ in node.args], **{item.arg: object() for item in node.keywords})))
                if isinstance(node, ast.Attribute) and isinstance(node.value, ast.Attribute):
                    path = dotted(node)
                    owner = path.split('.', 1)[0]
                    if owner in types and '.PARAM' in path:
                        if location.endswith('quest_sdk_compat.py') and path == 'motor.PARAM_SET.mech_pos':
                            continue  # Explicit fallback for the prior SDK only; native route checked dynamically below.
                        def attr_check(path=path, owner=owner):
                            value = types[owner]
                            for name in path.split('.')[1:]:
                                value = value._TELEMETRY_CLASS.PARAMS if name == 'PARAMS' and hasattr(value, '_TELEMETRY_CLASS') else getattr(value, name)
                            return repr(value)
                        check(f'{location}:{node.lineno}: SDK parameter {path}', attr_check)
        report['sdk_call_sites'] = len(checked)
        if (project / 'quest_sdk_compat.py').exists():
            from quest_sdk_compat import motor_position_param, motor_feedback_age_s
            def feedback_contract():
                motor = SimpleNamespace(PARAMS=RobstrideMotorTelemetry.PARAMS,
                    telemetry=SimpleNamespace(get_latest_timestamp=lambda param, default: 9.9))
                assert motor_position_param(motor) == RobstrideMotorTelemetry.PARAMS.FB_POSITION
                assert math.isclose(motor_feedback_age_s(motor, 10.0), .1, abs_tol=1e-12)
                return 'Native feedback code and seconds-based age preserved'
            check('native motor feedback parameter/timestamp contract', feedback_contract)

        def native_base_contract():
            notebook = json.loads((project / 'meta_quest_hand.ipynb').read_text(encoding='utf-8'))
            cells = {cell['id']: ''.join(cell['source']) for cell in notebook['cells'] if cell['cell_type'] == 'code'}
            assert nav_type is ThreeWheelHolonomicRobstrideNavigationSystem, 'Use the actual branch native navigation API for this notebook'
            initialize = ast.parse(cells['initialize'])
            assignments = [node.value for node in ast.walk(initialize)
                           if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name)
                               and target.id == 'nav' for target in node.targets)]
            assert len(assignments) == 1
            native = assignments[0].body if isinstance(assignments[0], ast.IfExp) else assignments[0]
            assert dotted(native) == 'robot.navigation_system', 'Notebook navigation must be the native robot system'
            settings = ast.parse(cells['settings'])
            strict_defaults = [node.value for node in settings.body if isinstance(node, ast.Assign)
                               and any(isinstance(target, ast.Name) and target.id == 'BASE_STRICT_DIRECTIONS'
                                       for target in node.targets)]
            assert len(strict_defaults) == 1 and isinstance(strict_defaults[0], ast.Constant) \
                and strict_defaults[0].value is False, 'Continuous steering must default to BASE_STRICT_DIRECTIONS=False'
            inspect.signature(nav_type.set_strict_directions).bind(object(), False)
            inspect.signature(nav_type.get_strict_directions).bind(object())
            for value in (False, True):
                assert nav_type.get_strict_directions(SimpleNamespace(_strict_directions=value)) is value
            velocity_calls = []
            strict_calls = []
            for cid, source in cells.items():
                for node in ast.walk(ast.parse(source)):
                    if isinstance(node, ast.Name):
                        assert node.id not in ('LegacyNavigation', 'BASE_SPEED'), (cid, node.id)
                    if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and dotted(node.func.value) == 'nav':
                        assert not node.keywords, (cid, node.func.attr)
                        if node.func.attr == 'set_velocity':
                            assert len(node.args) == 3
                            velocity_calls.append(cid)
                        elif node.func.attr == 'set_strict_directions':
                            assert cid == 'initialize' and len(node.args) == 1 \
                                and isinstance(node.args[0], ast.Name) and node.args[0].id == 'BASE_STRICT_DIRECTIONS'
                            strict_calls.append(node.lineno)
                        else:
                            assert node.func.attr == 'get_strict_directions' and not node.args, (cid, node.func.attr)
            assert len(strict_calls) == 1, 'Configure steering mode once during initialization'
            initialized_with_zero = []
            for parent in ast.walk(initialize):
                for field, statements in ast.iter_fields(parent):
                    if not isinstance(statements, list):
                        continue
                    prior_nav_call = None
                    for statement in statements:
                        if (not isinstance(statement, ast.Expr) or not isinstance(statement.value, ast.Call)
                                or not isinstance(statement.value.func, ast.Attribute)
                                or dotted(statement.value.func.value) != 'nav'):
                            continue
                        call = statement.value
                        if call.func.attr == 'set_strict_directions':
                            assert prior_nav_call is not None and prior_nav_call.func.attr == 'set_velocity' \
                                and len(prior_nav_call.args) == 3 and all(isinstance(argument, ast.Constant)
                                    and type(argument.value) in (int, float) and argument.value == 0
                                    for argument in prior_nav_call.args), 'Set zero velocity before configuring steering mode'
                            initialized_with_zero.append(call.lineno)
                        prior_nav_call = call
            assert initialized_with_zero == strict_calls, 'Steering mode must be configured directly after a zero velocity request'
            assert len(velocity_calls) >= 5 and 'setup-home' in velocity_calls and 'torso-functions' in velocity_calls
            return 'Native velocity API; initialization applies continuous steering after zero velocity; public getter verified without hardware'
        check('native base velocity API and stop contract', native_base_contract)

        config_path = (args.config or project.parent / 'configs/robot_conf.py').resolve(strict=True)
        config_bytes = {path: path.read_bytes() for path in config_path.parent.rglob('*.py')}
        urdf_path = args.urdf
        if urdf_path is None:
            settings = next(source for location, source in all_sources(project) if location.endswith(':settings'))
            tree = ast.parse(settings)
            for node in tree.body:
                if isinstance(node, ast.Assign) and any(isinstance(item, ast.Name) and item.id == 'URDF' for item in node.targets):
                    urdf_path = eval(compile(ast.Expression(node.value), '<URDF config expression>', 'eval'),
                                     {'__builtins__': {}, 'PROJECT': project, 'Path': Path})
        if urdf_path is None:
            raise AssertionError('Specify --urdf for this project')
        urdf_path = Path(urdf_path).resolve(strict=True)
        try:
            raw_config = load_configs(config_path)
            report['raw_sdk_findings'].append({'name': 'unmigrated SDK config load', 'success': True})
        except Exception as exc:
            report['raw_sdk_findings'].append({'name': 'unmigrated SDK config load', 'success': False,
                                               'error': f'{type(exc).__name__}: {exc}'})
        original = check('migrated app config load', lambda: app_config_loader(config_path, urdf_path,
                           include_torso=True, include_navigation=True, include_neck=True, hand_sides=()))
        if original is not None:
            before = original.model_dump_json()
            from feathersdk.robot.actuators.ezmotion import EC_PER_ROT
            removed = []
            for system in ('arms', 'torso', 'neck', 'navigation'):
                path = config_path.parent / 'systems' / (system + '_system_conf.py')
                expected = source_config(path, EC_PER_ROT)
                check(system + ' original configuration values preserved', lambda expected=expected, system=system:
                      compare_preserved(expected, getattr(original, system + '_system_config'), system, removed))
            report['source_fields_absent_in_branch_models'] = removed
            for torso, nav, neck, sides in itertools.product((False, True), (False, True), (False, True),
                                                            ((), ('left',), ('right',), ('left', 'right'))):
                label = f'config selection torso={torso}, nav={nav}, neck={neck}, hands={sides}'
                def config_check(torso=torso, nav=nav, neck=neck, sides=sides):
                    result = app_config_loader(config_path, urdf_path, include_torso=torso,
                                                include_navigation=nav, include_neck=neck, hand_sides=sides)
                    validate_model(result)
                    for flag, field in ((torso, 'torso_system_config'), (nav, 'navigation_system_config'),
                                        (neck, 'neck_system_config')):
                        assert (getattr(result, field) is not None) == flag, field
                    hands = result.manipulation_system_config
                    assert (hands is None) if args.standalone_hands else ((hands is not None) == bool(sides))
                    if args.hand_config_loader:
                        hand_configs = class_from_spec(args.hand_config_loader)(config_path, sides)
                        assert set(hand_configs) == set(sides), (sides, hand_configs)
                        original_hands = source_config(config_path.parent / 'systems/manipulation_system_conf.py', EC_PER_ROT)
                        for side, hand_config in hand_configs.items():
                            expected_hand = getattr(original_hands, side + '_hand')
                            expected_fields = vars(expected_hand)
                            actual_fields = vars(hand_config) if not isinstance(hand_config, dict) else hand_config
                            for key, value in expected_fields.items():
                                assert actual_fields[key] == value, (side, key, value, actual_fields.get(key))
                    if hands is not None:
                        for side in ('left', 'right'):
                            assert (getattr(hands, side + '_hand', None) is not None) == (side in sides), side
                    assert original.model_dump_json() == before, 'original config was mutated'
                    return {'class': type(result).__name__, 'hand_class': type(hands).__name__ if hands else None}
                check(label, config_check)
            check('original config files unchanged', lambda:
                  all(path.read_bytes() == value for path, value in config_bytes.items()) or
                  (_ for _ in ()).throw(AssertionError('Original configuration files changed')))
    except Exception as exc:
        report['issues'].append({'name': 'SDK contract harness', 'error': f'{type(exc).__name__}: {exc}',
                                 'traceback': traceback.format_exc()})
    finally:
        sys.setprofile(profile)
    report['profile_guard_active'] = sys.getprofile() is profile
    report['success'] = not report['issues']
    if args.report:
        args.report.write_text(json.dumps(report, indent=2, default=repr) + '\n', encoding='utf-8')
    print(json.dumps(report, indent=2, default=repr))
    return 0 if report['success'] else 1


REPORT_DIRECTORY = None
MOTOR_CONFIG_TYPE = None
KP_LIMITS = KD_LIMITS = None
if __name__ == '__main__':
    raise SystemExit(main())
