import copy
from pathlib import Path
import sys
import time
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'outputs'))
from quest_pose_receiver import ARM_SWITCH, HEADER, parse_packet, ArmRunGate
from test_quest_controls import packet


def button_packet(a=0, b=0, run=False):
    old=packet()
    header=list(HEADER.unpack_from(old));header[1]=4;header[3]=284
    return HEADER.pack(*header)+old[HEADER.size:]+ARM_SWITCH.pack(a,b,int(run))


def snapshot(a=0,b=0,run=False,session=42,now=10.0,received=None):
    p=parse_packet(button_packet(a,b,run))
    p['session']=session;p['receive_s']=now if received is None else received
    p['sent_s']=p['receive_s']
    return dict(status='receiving',latest=p)


class Buttons(unittest.TestCase):
    def test_v4_wire_format_and_invalid_state(self):
        p=parse_packet(button_packet(4,2,True))
        self.assertEqual(p['arm_switch'],dict(a_press=4,b_press=2,run_requested=True))
        self.assertEqual(p['calibration_id'],7)
        self.assertAlmostEqual(p['controls']['torso_y'],-0.5)
        with self.assertRaises(ValueError):parse_packet(button_packet(run=2))

    def test_requires_new_a_then_b_and_a_again(self):
        gate=ArmRunGate()
        self.assertFalse(gate.update(snapshot(5,0,True),10))
        self.assertTrue(gate.update(snapshot(6,0,True),10))
        self.assertFalse(gate.update(snapshot(6,1,False),10))
        self.assertFalse(gate.update(snapshot(6,1,True),10))
        self.assertTrue(gate.update(snapshot(7,1,True),10))

    def test_lost_b_packet_still_stops_and_b_wins_over_a(self):
        gate=ArmRunGate();gate.update(snapshot(),10)
        self.assertTrue(gate.update(snapshot(1,0,True),10))
        # First B packet was lost and A was then pressed: repeated B counter still wins.
        self.assertFalse(gate.update(snapshot(2,1,True),10))
        self.assertFalse(gate.update(snapshot(2,1,True),10))
        self.assertTrue(gate.update(snapshot(3,1,True),10))

    def test_stale_session_and_disconnect_require_fresh_a(self):
        gate=ArmRunGate();gate.update(snapshot(),10)
        gate.update(snapshot(1,0,True),10)
        self.assertFalse(gate.update(snapshot(1,0,True,received=9.6),10))
        self.assertFalse(gate.update(snapshot(1,0,True),10))
        self.assertTrue(gate.update(snapshot(2,0,True),10))
        self.assertFalse(gate.update(snapshot(2,0,True,session=43),10))
        bad=snapshot(3,0,True,session=43);bad['latest']['poses']['right']['connected']=False
        self.assertFalse(gate.update(bad,10))

    def test_old_app_cannot_enable(self):
        gate=ArmRunGate();p=parse_packet(packet());p['receive_s']=10
        self.assertFalse(gate.update(dict(status='receiving',latest=p),10))


if __name__=='__main__':unittest.main(verbosity=2)
