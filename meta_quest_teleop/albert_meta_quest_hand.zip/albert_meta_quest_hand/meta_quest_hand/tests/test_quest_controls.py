"""Synthetic protocol tests; these do not operate hardware."""
import csv
import math
from pathlib import Path
import socket
import struct
import sys
import tempfile
import time
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'outputs'))
from quest_pose_receiver import (HEADER, TIMING, POSE, ANCHOR, MAGIC, CONTROLS,
    CONTROL_NAMES, parse_packet, PoseReceiver, format_snapshot)


def packet(version=3, values=(0.1, 0.2, 0.3, 0.4, -0.5), available=31, seq=0):
    size = {1: 160, 2: 248, 3: 272}[version]
    data = HEADER.pack(MAGIC, version, 1, size, 42, seq, time.monotonic())
    data += TIMING.pack(-1, 0, -1) + POSE.pack(63, 3, 1, 2, 3, 0, 0, 0, 1)*3
    if version >= 2:
        data += struct.pack('<I', 7) + ANCHOR.pack(1, 2, 3, 0, 0, 0, 1)*3
    if version >= 3:
        data += CONTROLS.pack(available, *values)
    return data


class Controls(unittest.TestCase):
    def test_five_values_and_anchors(self):
        p = parse_packet(packet())
        self.assertEqual(p['calibration_id'], 7)
        self.assertEqual(len(p['controls']), 8)
        self.assertIsNone(p['controls']['base_turn'])
        self.assertIsNone(p['controls']['base_x'])
        self.assertIsNone(p['controls']['base_y'])
        for actual, expected in zip(p['controls'].values(), (0.1, 0.2, 0.3, 0.4, -0.5)):
            self.assertAlmostEqual(actual, expected, places=6)
        self.assertEqual(parse_packet(packet(values=(0, 1, 0, 1, 1)))['controls']['torso_y'], 1)

    def test_unavailable_and_legacy(self):
        p = parse_packet(packet(available=4))
        self.assertIsNone(p['controls']['left_trigger'])
        self.assertAlmostEqual(p['controls']['right_trigger'], 0.3)
        self.assertIsNone(p['controls']['torso_y'])
        for version in (1, 2):
            self.assertTrue(all(v is None for v in parse_packet(packet(version))['controls'].values()))

    def test_reject_invalid_inputs(self):
        for data in (packet(available=32), packet(values=(math.nan, 0, 0, 0, 0)),
                     packet(values=(0, -0.1, 0, 0, 0)), packet(values=(0, 0, 2, 0, 0)),
                     packet(values=(0, 0, 0, 0, -1.1)), packet()[:-1]):
            with self.assertRaises(ValueError):
                parse_packet(data)

    def test_udp_logging_display_and_v3_ping(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / 'poses.csv'
            receiver = PoseReceiver('127.0.0.1', 0).start(path)
            client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            client.settimeout(1)
            target = receiver.sock.getsockname()
            try:
                client.sendto(HEADER.pack(MAGIC, 3, 2, 28, 42, 1, time.monotonic()), target)
                pong, _ = client.recvfrom(2048)
                self.assertEqual(HEADER.unpack_from(pong)[1:4], (3, 3, 44))
                start = time.monotonic()
                for seq in range(30):
                    time.sleep(max(0, start + seq/30 - time.monotonic()))
                    client.sendto(packet(seq=seq), target)
                deadline = time.monotonic() + 1
                while receiver.snapshot()['unique_packets'] < 30 and time.monotonic() < deadline:
                    time.sleep(0.01)
                snapshot = receiver.snapshot()
                self.assertEqual(snapshot['unique_packets'], 30)
                self.assertEqual(snapshot['unresolved_gaps'], 0)
                self.assertIn('torso_y=-0.500', format_snapshot(snapshot))
            finally:
                client.close()
                receiver.stop()
            with path.open(newline='') as f:
                rows = list(csv.DictReader(f))
            self.assertEqual(len(rows), 30)
            for name, expected in zip(CONTROL_NAMES, (0.1, 0.2, 0.3, 0.4, -0.5)):
                self.assertAlmostEqual(float(rows[-1][name]), expected, places=6)


if __name__ == '__main__':
    unittest.main(verbosity=2)
