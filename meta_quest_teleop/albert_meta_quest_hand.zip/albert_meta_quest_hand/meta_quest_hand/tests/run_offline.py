"""Compile and run app tests with SDK/hardware imports blocked.

Run once per app in a fresh Python process:
  python3 -B /tmp/run_offline.py APP_DIRECTORY --tests --report /tmp/app-summary.json

No notebook is executed wholesale. Tests can use ephemeral loopback UDP and
Unix socketpairs; robot-facing socket families and non-loopback traffic fail.
The module-level guard also runs when multiprocessing spawn reloads __main__.
"""
from __future__ import annotations

import argparse
import importlib.abc
import ipaddress
import json
import os
from pathlib import Path
import re
import socket
import stat
import sys
import unittest


class OfflineOnlyImports(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split('.')[0] in {'feathersdk', 'can', 'serial', 'pyzed'}:
            raise ImportError(f'Offline app test blocked hardware import: {fullname}')
        return None


def _loopback(address):
    if not isinstance(address, tuple) or not address:
        return False
    try:
        return ipaddress.ip_address(address[0]).is_loopback
    except ValueError:
        return False


def _audit(event, args):
    if event == 'socket.__new__':
        if args[1] not in (socket.AF_INET, socket.AF_INET6, socket.AF_UNIX):
            raise RuntimeError(f'Offline test blocked socket family: {args[1]}')
        if args[2] & 0xF not in (socket.SOCK_STREAM, socket.SOCK_DGRAM):
            raise RuntimeError(f'Offline test blocked socket type: {args[2]}')
    elif event in ('socket.connect', 'socket.bind', 'socket.sendto'):
        sock, address = args[0], args[1]
        if sock.family in (socket.AF_INET, socket.AF_INET6):
            if not _loopback(address):
                raise RuntimeError(f'Offline test blocked {event}: {address!r}')
            if event == 'socket.bind' and address[1] != 0:
                raise RuntimeError(f'Offline tests must bind an ephemeral port: {address!r}')
        elif event in ('socket.connect', 'socket.bind'):
            raise RuntimeError(f'Offline tests allow anonymous Unix socketpairs only: {event}')
    elif event == 'socket.getaddrinfo':
        if args[0] not in (None, 'localhost', '127.0.0.1', '::1'):
            raise RuntimeError(f'Offline test blocked name lookup: {args[0]!r}')
    elif event in ('subprocess.Popen', 'os.system'):
        raise RuntimeError(f'Offline app tests blocked external command: {event}')
    elif event == 'open':
        path = args[0]
        if isinstance(path, (str, bytes)):
            decoded = os.fsdecode(path)
            if decoded.startswith('/dev/') and decoded not in ('/dev/null', '/dev/urandom', '/dev/random'):
                shared_memory = re.fullmatch(r'/dev/shm/pym-[0-9]+-[a-z0-9_]+', decoded)
                if shared_memory:
                    try:
                        regular = stat.S_ISREG(os.lstat(decoded).st_mode)
                    except FileNotFoundError:
                        flags = args[2]
                        regular = bool(flags & os.O_CREAT and flags & os.O_EXCL)
                    if regular:
                        return
                raise RuntimeError(f'Offline app tests blocked device access: {decoded}')


sys.dont_write_bytecode = True
sys.meta_path.insert(0, OfflineOnlyImports())
sys.addaudithook(_audit)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('project', type=Path)
    parser.add_argument('--tests', action='store_true')
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    project = args.project.resolve(strict=True)
    counts = {'python_files': 0, 'notebook_code_cells': 0}
    for path in sorted(project.rglob('*.py')):
        if '__pycache__' not in path.parts:
            compile(path.read_text(encoding='utf-8-sig'), str(path), 'exec')
            counts['python_files'] += 1
    for path in sorted(project.glob('*.ipynb')):
        for number, cell in enumerate(json.loads(path.read_text(encoding='utf-8'))['cells']):
            if cell['cell_type'] == 'code':
                source = ''.join(cell['source'])
                compile(source, f'{path}:{cell.get("id", number)}', 'exec')
                counts['notebook_code_cells'] += 1
    print('Compile checks:', json.dumps(counts), flush=True)
    summary = {'project': str(project), 'compile': counts}
    if args.tests:
        sys.path[:0] = [str(project), str(project / 'tests')]
        suite = unittest.defaultTestLoader.discover(str(project / 'tests'), pattern='test_*.py')
        result = unittest.TextTestRunner(verbosity=1).run(suite)
        summary['tests'] = {'run': result.testsRun, 'failures': len(result.failures),
                            'errors': len(result.errors), 'skipped': len(result.skipped),
                            'failure_ids': [case.id() for case, _ in result.failures],
                            'error_ids': [case.id() for case, _ in result.errors]}
        summary['success'] = result.wasSuccessful()
    else:
        summary['success'] = True
    if args.report:
        args.report.write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
    print('Summary:', json.dumps(summary), flush=True)
    return 0 if summary['success'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
