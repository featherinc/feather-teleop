import copy
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace, ModuleType
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from quest_trajectory_replay import load_replay_config


class Config(SimpleNamespace):
    def model_copy(self, update, deep):
        result = copy.deepcopy(self)
        result.__dict__.update(update)
        return result


class HandConfigTests(unittest.TestCase):
    def test_only_selected_hands_added_without_modifying_original_sdk_config(self):
        original = Config(torso_system_config='torso', navigation_system_config='nav',
                          manipulation_system_config=Config(left_hand='left', right_hand='right'))
        module = ModuleType('feathersdk.configs')
        module.load_configs = lambda _: original
        with tempfile.TemporaryDirectory() as temp, patch.dict(sys.modules, {'feathersdk.configs': module}):
            path = Path(temp) / 'config.py'
            path.write_text('')
            for sides in ((), ('left',), ('right',), ('left', 'right')):
                result = load_replay_config(path, path, hand_sides=sides, sdk_generation='legacy')
                if not sides:
                    self.assertIsNone(result.manipulation_system_config)
                else:
                    for side in ('left', 'right'):
                        self.assertEqual(getattr(result.manipulation_system_config, side + '_hand'),
                                         side if side in sides else None)
                self.assertEqual(original.manipulation_system_config.right_hand, 'right')
                self.assertEqual(original.manipulation_system_config.left_hand, 'left')
            original.manipulation_system_config = None
            with self.assertRaisesRegex(ValueError, 'Configure'):
                load_replay_config(path, path, hand_sides=('left',), sdk_generation='legacy')


if __name__ == '__main__':
    unittest.main()
