import copy
import math
import socket
import struct
import time
import unittest
from types import SimpleNamespace
from unittest.mock import Mock, patch
from quest_pose_receiver import HEADER, BASE_CONTROLS, BASE_POSE_SIZE, TURN_CONTROL, TURN_POSE_SIZE, parse_packet, packet_row, CSV_FIELDS, PoseReceiver
from test_quest_buttons import button_packet, snapshot
from test_quest_notebook import Tests as NotebookFixture


def base_packet(x=0.0,y=0.0,available=3):
    old=button_packet(1,0,True)
    h=list(HEADER.unpack_from(old));h[1]=5;h[3]=BASE_POSE_SIZE
    return HEADER.pack(*h)+old[HEADER.size:]+BASE_CONTROLS.pack(available,x,y)


def turn_packet(turn=0.0, available=1, x=0.0, y=0.0):
    old = base_packet(x,y)
    h = list(HEADER.unpack_from(old)); h[1]=6; h[3]=TURN_POSE_SIZE
    return HEADER.pack(*h) + old[HEADER.size:] + TURN_CONTROL.pack(available,turn)


class BaseTests(unittest.TestCase):
    def setUp(self):
        fixture=NotebookFixture();fixture.setUp();self.addCleanup(fixture.doCleanups)
        self.ns,self.robot=fixture.namespace()
        self.ns.update(BASE_LINEAR_SPEED=.2, BASE_YAW_SPEED=1., BASE_DEADZONE=.15)
        self.fixture=fixture

    def test_v5_packet_and_legacy(self):
        p=parse_packet(base_packet(.4,-.8))
        self.assertEqual(len(base_packet()),296)
        self.assertAlmostEqual(p['controls']['base_x'],.4,places=6)
        self.assertAlmostEqual(p['controls']['base_y'],-.8,places=6)
        self.assertEqual(p['arm_switch']['a_press'],1)
        self.assertIsNone(parse_packet(button_packet())['controls']['base_x'])
        self.assertIsNone(parse_packet(base_packet(available=0))['controls']['base_y'])
        for packet in [base_packet(float('nan'),0),base_packet(1.1,0),base_packet(available=4),base_packet()[:-1]]:
            with self.assertRaises(ValueError):parse_packet(packet)

    def test_v6_rotation_input_and_legacy(self):
        p = parse_packet(turn_packet(.6, x=.2, y=-.4))
        self.assertEqual(len(turn_packet()),304)
        self.assertAlmostEqual(p['controls']['base_turn'],.6,places=6)
        self.assertAlmostEqual(p['controls']['base_x'],.2,places=6)
        self.assertAlmostEqual(p['controls']['base_y'],-.4,places=6)
        self.assertIsNone(parse_packet(base_packet())['controls']['base_turn'])
        self.assertIsNone(parse_packet(turn_packet(available=0))['controls']['base_turn'])
        for packet in (turn_packet(float('nan')),turn_packet(1.1),turn_packet(available=2),turn_packet()[:-1]):
            with self.assertRaises(ValueError): parse_packet(packet)
        p.update(receive_s=1,gap_ms=None,rtt_ms=None,one_way_estimate_ms=None)
        self.assertIn('base_turn',CSV_FIELDS)
        self.assertAlmostEqual(packet_row(p,('127.0.0.1',5005))['base_turn'],.6,places=6)

    def test_drive_rotation_directions_and_limits(self):
        diagonal = round(.2 / math.sqrt(2), 4)
        cases = [(0,1,.2,0.), (0,-1,-.2,0.), (-1,0,0.,.2), (1,0,0.,-.2),
                 (1,1,diagonal,-diagonal), (-1,1,diagonal,diagonal),
                 (1,-1,-diagonal,-diagonal), (-1,-1,-diagonal,diagonal),
                 (0,.575,.1,0.)]
        for x,y,vx,vy in cases:
            result = self.ns['base_command'](parse_packet(base_packet(x,y)), True)
            self.assertEqual(result, ('drive',vx,vy,0.))
        for turn,expected in [(1,-1),(-1,1),(.575,-.5)]:
            result=self.ns['base_command'](parse_packet(turn_packet(turn,x=1,y=1)),True)
            self.assertEqual(result, ('rotate',0.,0.,expected))

    def test_continuous_translation_all_directions(self):
        for degrees in range(720):
            theta = math.radians(degrees / 2)
            x, y = math.sin(theta), math.cos(theta)
            mode, vx, vy, omega = self.ns['base_command'](parse_packet(base_packet(x,y)), True)
            self.assertEqual(mode, 'drive')
            self.assertAlmostEqual(vx, .2*y, delta=.000051)
            self.assertAlmostEqual(vy, -.2*x, delta=.000051)
            self.assertAlmostEqual(math.hypot(vx,vy), .2, delta=.000071)
            self.assertEqual(omega, 0.)

    def test_radial_deadzone_is_proportional_and_diagonal_is_normalized(self):
        for fraction in (.25,.5,.75,1.):
            radius=.15 + .85*fraction
            x,y=radius*math.sin(.8),radius*math.cos(.8)
            mode,vx,vy,omega=self.ns['base_command'](parse_packet(base_packet(x,y)),True)
            self.assertEqual(mode,'drive')
            self.assertAlmostEqual(vx,.2*fraction*math.cos(.8),delta=.000051)
            self.assertAlmostEqual(vy,-.2*fraction*math.sin(.8),delta=.000051)
            self.assertEqual(omega,0.)
        for x,y in ((1.,1.),(-1.,1.),(1.,-1.),(-1.,-1.)):
            _,vx,vy,_=self.ns['base_command'](parse_packet(base_packet(x,y)),True)
            self.assertAlmostEqual(math.hypot(vx,vy),.2,delta=.000071)
        self.assertIsNone(self.ns['base_command'](parse_packet(base_packet(.1,.1)),True))

    def test_right_rotation_does_not_depend_on_left_tracking(self):
        p = parse_packet(turn_packet(1))
        p['poses']['left']['tracked']=False
        self.assertEqual(self.ns['base_command'](p,True),('rotate',0.,0.,-1.))
        p['poses']['right']['tracked']=False
        self.assertIsNone(self.ns['base_command'](p,True))

    def test_right_y_does_not_rotate_base(self):
        p = parse_packet(turn_packet())
        p['controls']['torso_y']=1.0
        self.assertIsNone(self.ns['base_command'](p,True))

    def test_diagonal_worker_uses_sdk_translation(self):
        state = self.moving_state()
        state['latest']['controls'].update(base_x=1, base_y=1)
        calls = self.run_worker([state])
        diagonal=round(.2/math.sqrt(2),4)
        self.assertEqual(calls[0],('velocity',diagonal,-diagonal,0.))
        self.assertEqual(calls[-1], ('velocity',0.,0.,0.))

    def test_drive_rotate_mode_switch_stops_before_dispatch(self):
        forward = self.moving_state()
        turn = copy.deepcopy(forward)
        turn['latest']['controls'].update(base_turn=1)
        calls = self.run_worker([forward, turn, forward])
        self.assertEqual(calls, [('velocity',.2,0.,0.), ('velocity',0.,0.,0.),
                                ('velocity',0.,0.,-1.), ('velocity',0.,0.,0.),
                                ('velocity',.2,0.,0.), ('velocity',0.,0.,0.)])

    def test_held_forward_sideways_and_yaw_refresh_each_tick_without_transition_zero(self):
        self.assertIs(self.ns['BASE_STRICT_DIRECTIONS'],False)
        self.assertEqual(self.ns['CONTROL_HZ'],30.)
        for controls,expected in (({'base_x':0.,'base_y':1.},(.2,0.,0.)),
                                  ({'base_x':-1.,'base_y':0.},(0.,.2,0.)),
                                  ({'base_turn':1.},(0.,0.,-1.))):
            with self.subTest(controls=controls):
                state=self.moving_state()
                state['latest']['controls'].update(controls)
                calls=self.run_worker([state,state,state,state])
                self.assertEqual(calls,[('velocity',*expected)]*4 + [('velocity',0.,0.,0.)])
                self.assertEqual(len(self.worker_wait_delays),4)
                for delay in self.worker_wait_delays:self.assertAlmostEqual(delay,1./30.)
                self.assertEqual(self.ns['base_errors'],[])

    def test_only_true_mode_transitions_insert_zero_during_active_refresh(self):
        drive=self.moving_state();turn=copy.deepcopy(drive)
        turn['latest']['controls']['base_turn']=1.
        calls=self.run_worker([drive,drive,turn,turn,drive,drive])
        self.assertEqual(calls,[('velocity',.2,0.,0.)]*2 + [('velocity',0.,0.,0.)]
                             + [('velocity',0.,0.,-1.)]*2 + [('velocity',0.,0.,0.)]
                             + [('velocity',.2,0.,0.)]*2 + [('velocity',0.,0.,0.)])

    def test_held_sideways_refresh_recovers_native_projected_speed_and_stale_stops(self):
        from test_sdk_body_compat import branch_navigation
        native,events=branch_navigation()
        native.set_strict_directions(False)
        events.clear()
        samples=[]
        def send(vx,vy,omega):
            native.set_velocity(vx,vy,omega)
            samples.append(dict(native._target_velocities))
        def feedback(tick):
            if tick in (1,2):
                fraction=.5 if tick==1 else 1.
                for motor in native.turning_motors:
                    motor.actual=native._target_angles[motor.config.name]*fraction
                native._thread_step()
        held=self.moving_state()
        held['latest']['controls'].update(base_x=-1.,base_y=0.)
        stale=copy.deepcopy(held);stale['latest']['receive_s']=9.6
        calls=self.run_worker([held,held,held,stale,stale],send=send,after_wait=feedback)
        self.assertEqual(calls,[('velocity',0.,.2,0.)]*3 + [('velocity',0.,0.,0.)]*2)
        for motor in native.drive_motors:
            with self.subTest(wheel=motor.config.name):
                name=motor.config.name
                self.assertAlmostEqual(samples[0][name],0.)
                self.assertAlmostEqual(samples[1][name],(10./3.)/math.sqrt(2))
                self.assertAlmostEqual(samples[2][name],10./3.)
                self.assertEqual(samples[3][name],0.)
                self.assertEqual(samples[4][name],0.)
        self.assertEqual(self.ns['base_errors'],[])

    def test_rotation_stops_on_b_stale_session_tracking_release(self):
        for reason in ('b','stale','session','tracking','release'):
            first = self.moving_state()
            first['latest']['controls'].update(base_x=0,base_y=0,base_turn=-1)
            second = copy.deepcopy(first)
            if reason == 'b': second['latest']['arm_switch'].update(b_press=1,run_requested=False)
            if reason == 'stale': second['latest']['receive_s']=9.6
            if reason == 'session': second['latest']['session']=99
            if reason == 'tracking': second['latest']['poses']['right']['tracked']=False
            if reason == 'release': second['latest']['controls'].update(base_turn=0)
            calls = self.run_worker([first,second])
            self.assertEqual(calls, [('velocity',0.,0.,1.), ('velocity',0.,0.,0.),
                                    ('velocity',0.,0.,0.)])

    def test_release_untracked_missing_or_not_running_stops(self):
        ns=self.ns
        for p,running in [(parse_packet(base_packet(.05,.05)),True),(parse_packet(base_packet(0,1)),False),
                          (parse_packet(button_packet()),True),(parse_packet(base_packet(available=0)),True)]:
            self.assertIsNone(ns['base_command'](p,running))
        p=parse_packet(base_packet(0,1));p['poses']['left']['tracked']=False
        self.assertIsNone(ns['base_command'](p,True))

    def test_invalid_analog_input_stops_instead_of_submitting_nonfinite_twist(self):
        for field in ('base_x','base_y','base_turn'):
            for value in (math.nan,math.inf,-math.inf,1.01,-1.01):
                with self.subTest(field=field,value=value):
                    packet=parse_packet(turn_packet(x=0,y=1))
                    packet['controls'][field]=value
                    self.assertIsNone(self.ns['base_command'](packet,True))

    def run_worker(self,states,*,allowed=True,send=None,after_wait=None):
        ns=self.ns;index=[0];calls=[]
        wait_delays=[];self.worker_wait_delays=wait_delays
        class Done:
            def is_set(self):return index[0]>=len(states)
            def wait(self,dt):
                wait_delays.append(dt)
                index[0]+=1
                if after_wait is not None:after_wait(index[0])
        def set_velocity(vx,vy,omega):
            if send is not None:send(vx,vy,omega)
            calls.append(('velocity',vx,vy,omega))
        legacy={name:Mock(side_effect=AssertionError('Legacy base API must not be called'))
                for name in ('orient_and_move','set_speed','rotate_in_place')}
        ns.update(nav=SimpleNamespace(set_velocity=set_velocity,**legacy),
                  base_lock=__import__('threading').Lock(),base_errors=[],base_last_command=None,
                  torso_done=Done(),torso_allowed=__import__('threading').Event(),
                  active_key=(42,7),active_b=0,
                  receiver=SimpleNamespace(latest_snapshot=lambda:states[index[0]]))
        if allowed:ns['torso_allowed'].set()
        with patch.object(time,'monotonic',lambda:10.0):ns['base_loop']()
        for method in legacy.values():method.assert_not_called()
        return calls

    def moving_state(self):
        s=snapshot(1,0,True,now=10)
        s['latest']['controls'].update(base_x=0,base_y=1)
        return s

    def test_b_stale_new_session_and_release_stop_worker(self):
        for reason in ['b','stale','future','session','recenter','release','tracking','status','missing']:
            with self.subTest(reason=reason):
                first=self.moving_state();second=copy.deepcopy(first)
                if reason=='b':second['latest']['arm_switch'].update(b_press=1,run_requested=False)
                if reason=='stale':second['latest']['receive_s']=9.6
                if reason=='future':second['latest']['receive_s']=10.01
                if reason=='session':second['latest']['session']=99
                if reason=='recenter':second['latest']['recenter_id']=1
                if reason=='release':second['latest']['controls'].update(base_x=0,base_y=0)
                if reason=='tracking':second['latest']['poses']['left']['connected']=False
                if reason=='status':second['status']='stale'
                if reason=='missing':second['latest']=None
                calls=self.run_worker([first,first,second,second])
                self.assertEqual(calls,[('velocity',.2,0.,0.)]*2 + [('velocity',0.,0.,0.)]*2)
                self.assertEqual(self.ns['base_errors'],[])

    def test_closed_or_cleared_shared_motion_gate_stops_base(self):
        state=self.moving_state()
        self.assertEqual(self.run_worker([state],allowed=False),
                         [('velocity',0.,0.,0.)])
        calls=self.run_worker([state,state],after_wait=lambda tick:self.ns['torso_allowed'].clear())
        self.assertEqual(calls,[('velocity',.2,0.,0.),('velocity',0.,0.,0.),
                                ('velocity',0.,0.,0.)])

    def test_extra_a_preserves_active_reference_and_continuous_base_refresh(self):
        a=self.moving_state();b=copy.deepcopy(a)
        b['latest']['calibration_id']=8;b['latest']['arm_switch']['a_press']=2
        calls=self.run_worker([a,b])
        self.assertEqual(calls,[('velocity',.2,0.,0.),('velocity',.2,0.,0.),
                                ('velocity',0.,0.,0.)])

    def test_initialize_stops_native_base_before_changing_steering_policy(self):
        for strict in (False,True):
            with self.subTest(strict=strict):
                ns=self.ns;events=[]
                navigation=SimpleNamespace(
                    set_velocity=lambda *v:events.append(('velocity',*v)),
                    set_strict_directions=lambda value:events.append(('strict',value)))
                self.robot.navigation_system=navigation
                ns.update(RUN_HARDWARE=True,CONTROL_BASE=True,CONTROL_TORSO=False,
                          BASE_STRICT_DIRECTIONS=strict,manipulation=None)
                initializer=Mock(side_effect=AssertionError('Existing fake robot must be reused'))
                with patch.dict(__import__('sys').modules,{'feathersdk.robot.robot':
                                SimpleNamespace(initialize_feather_system=initializer)}):
                    exec(self.fixture.cells()['initialize'],ns)
                initializer.assert_not_called()
                self.assertIs(ns['nav'],navigation)
                self.assertEqual(events,[('velocity',0.,0.,0.),('strict',strict)])

    def test_initialize_with_live_base_worker_fails_before_any_policy_or_motion_call(self):
        ns=self.ns
        navigation=SimpleNamespace(set_velocity=Mock(),set_strict_directions=Mock())
        previous_listener=SimpleNamespace(close=Mock())
        self.robot.navigation_system=navigation
        ns.update(RUN_HARDWARE=True,CONTROL_BASE=True,CONTROL_TORSO=False,
                  BASE_STRICT_DIRECTIONS=False,base_thread=SimpleNamespace(is_alive=lambda:True),
                  manipulation=previous_listener)
        initializer=Mock(side_effect=AssertionError('Live worker must prevent initialization'))
        with patch.dict(__import__('sys').modules,{'feathersdk.robot.robot':
                        SimpleNamespace(initialize_feather_system=initializer)}):
            with self.assertRaisesRegex(RuntimeError,'Stop section 7'):
                exec(self.fixture.cells()['initialize'],ns)
        initializer.assert_not_called()
        previous_listener.close.assert_not_called()
        navigation.set_velocity.assert_not_called()
        navigation.set_strict_directions.assert_not_called()

    def test_home_stops_base_before_arms(self):
        ns=self.ns;events=[]
        ns.update(nav=SimpleNamespace(set_velocity=lambda *v:events.append(('base',*v))),
                  base_lock=__import__('threading').Lock(),torso_allowed=__import__('threading').Event())
        ns['arms'].disable=lambda:events.append(('arms','home'))
        ns['home_and_disable_arms']()
        self.assertEqual(events,[('base',0.,0.,0.),('arms','home')])

    def test_optional_setup_home_stops_native_base_before_arm_commands(self):
        ns=self.ns;events=[]
        def arm(side):
            return SimpleNamespace(enable=lambda:events.append((side,'enable')),
                                   home=lambda:events.append((side,'home')))
        ns.update(RUN_HARDWARE=True,nav=SimpleNamespace(
                    set_velocity=lambda *v:events.append(('base',*v))),
                  left_arm=arm('left'),right_arm=arm('right'),
                  arms=SimpleNamespace(disable=lambda:events.append(('arms','disable'))))
        with patch.object(time,'sleep',lambda delay:None):
            exec(self.fixture.cells()['setup-home'],ns)
        self.assertEqual(events,[('base',0.,0.,0.),('left','enable'),('right','enable'),
                                 ('left','home'),('right','home'),('arms','disable')])

    def test_base_error_is_reported_and_attempts_zero(self):
        def send(vx,vy,omega):
            if vx or vy or omega:raise RuntimeError('navigation failed')
        calls=self.run_worker([self.moving_state()],send=send)
        self.assertEqual(calls,[('velocity',0.,0.,0.)])
        self.assertEqual([str(error) for error in self.ns['base_errors']],['navigation failed'])

    def test_cleanup_stop_error_is_recorded_after_dispatch_failure(self):
        attempts=[]
        def send(vx,vy,omega):
            attempts.append((vx,vy,omega))
            raise RuntimeError('navigation failed' if vx else 'zero failed')
        self.assertEqual(self.run_worker([self.moving_state()],send=send),[])
        self.assertEqual(attempts,[(.2,0.,0.),(0.,0.,0.)])
        self.assertEqual([str(error) for error in self.ns['base_errors']],
                         ['navigation failed','zero failed'])

    def test_config_keeps_navigation_only_when_requested(self):
        from quest_trajectory_replay import load_replay_config
        class Config(SimpleNamespace):
            def model_copy(self,update,deep):
                result=copy.deepcopy(self);result.__dict__.update(update);return result
        original=Config(torso_system_config=None,navigation_system_config={'base':'original'})
        with patch.dict(__import__('sys').modules,{'feathersdk.configs':SimpleNamespace(load_configs=lambda p:original)}):
            a=load_replay_config(__file__,__file__,include_navigation=True,sdk_generation='legacy')
            b=load_replay_config(__file__,__file__,sdk_generation='legacy')
        self.assertEqual(a.navigation_system_config,original.navigation_system_config)
        self.assertIsNone(b.navigation_system_config)

if __name__=='__main__':unittest.main()
