import math
from pathlib import Path
import socket
import struct
import sys
import time
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'outputs'))
from quest_pose_receiver import HEADER, TIMING, POSE, MAGIC, parse_packet, PoseReceiver


def packet(seq=0, session=123, sent=None, flags=63, state=3, q=(0, 0, 0, 1)):
    return (HEADER.pack(MAGIC, 1, 1, 160, session, seq, time.monotonic() if sent is None else sent)
            + TIMING.pack(-1, 0, -1) + POSE.pack(flags, state, 1, 2, 3, *q) * 3)


class Validation(unittest.TestCase):
    def test_valid(self):
        p = parse_packet(packet())
        self.assertTrue(p['poses']['head']['position_valid'])
        self.assertEqual(p['poses']['left']['quaternion_xyzw'], [0, 0, 0, 1])

    def test_missing_tracking(self):
        p = parse_packet(packet(flags=13, state=0, q=(0, 0, 0, 0)))
        self.assertFalse(p['poses']['head']['rotation_valid'])
        self.assertFalse(p['poses']['head']['position_valid'])

    def test_bad_values_and_lengths(self):
        for data in (b'', packet()[:-1], packet()+b'X', b'FAIL'+packet()[4:],
                     packet(q=(0, 0, 0, 2)), packet(q=(math.nan, 0, 0, 1)),
                     packet(flags=127), packet(sent=math.inf)):
            with self.assertRaises(ValueError):
                parse_packet(data)

    def test_gap_duplicate_reorder_restart_and_wrap(self):
        r = PoseReceiver()
        peer = ('127.0.0.1', 1234)
        for seq in (10, 12, 12, 11):
            r._accept(parse_packet(packet(seq)), peer, time.monotonic())
        s = r.snapshot()
        self.assertEqual((s['unique_packets'], s['unresolved_gaps'], s['duplicates'], s['reordered']), (3, 0, 1, 1))
        self.assertEqual(s['latest']['seq'], 12)
        for seq in (2**32-1, 0, 1):
            r._accept(parse_packet(packet(seq, session=456)), peer, time.monotonic())
        self.assertEqual(r.snapshot()['unresolved_gaps'], 0)
        r._accept(parse_packet(packet(20)), peer, time.monotonic())
        self.assertEqual(r.snapshot()['session'], 456)

    def test_live_udp_ping_and_30hz(self):
        r = PoseReceiver('127.0.0.1', 0).start()
        target = r.sock.getsockname()
        client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        client.settimeout(1)
        try:
            t1 = time.monotonic()
            client.sendto(HEADER.pack(MAGIC, 1, 2, 28, 123, 1, t1), target)
            reply, _ = client.recvfrom(2048)
            t4 = time.monotonic()
            self.assertEqual(len(reply), 44)
            self.assertEqual(HEADER.unpack_from(reply)[2], 3)
            t2, t3 = struct.unpack_from('<dd', reply, 28)
            rtt = t4-t1-(t3-t2)
            offset = ((t2-t1)+(t3-t4))/2
            self.assertGreaterEqual(rtt, 0)
            start = time.monotonic()
            for i in range(60):
                time.sleep(max(0, start + i/30 - time.monotonic()))
                data = bytearray(packet(i))
                TIMING.pack_into(data, 28, rtt, offset, time.monotonic()-t4)
                client.sendto(data, target)
            time.sleep(0.08)
            s = r.snapshot()
            self.assertEqual(s['unique_packets'], 60)
            self.assertEqual(s['unresolved_gaps'], 0)
            self.assertTrue(28 < s['receive_hz'] < 32, s['receive_hz'])
            self.assertIsNotNone(s['rtt_ms'])
            print('SYNTHETIC loopback:', {k:s[k] for k in ('receive_hz','unique_packets','unresolved_gaps','gap_ms','rtt_ms')})
        finally:
            client.close()
            r.stop()


if __name__ == '__main__':
    unittest.main(verbosity=2)
