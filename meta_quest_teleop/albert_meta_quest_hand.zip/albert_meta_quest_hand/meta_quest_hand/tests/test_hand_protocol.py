import importlib.util
import os
from pathlib import Path
import socket
import struct
import sys
import time
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import quest_pose_receiver as receiver


def wire(version=9, left=2, right=4, available=3, seq=1):
    r = receiver
    pose = r.POSE.pack(63, 3, 1, 2, 3, 0, 0, 0, 1)
    anchor = r.ANCHOR.pack(1, 2, 3, 0, 0, 0, 1)
    body = (r.TIMING.pack(-1, 0, -1) + pose * 3 + struct.pack('<I', 1) + anchor * 3
            + r.CONTROLS.pack(31, .2, .3, .4, .5, .6) + r.ARM_SWITCH.pack(1, 0, 1)
            + r.BASE_CONTROLS.pack(3, .1, .2) + r.TURN_CONTROL.pack(1, .3) + r.RECENTER.pack(5))
    if version >= 8:
        body += r.HAND_SELECT.pack(available, left, right)
    return r.HEADER.pack(r.MAGIC, version, 1, r.HEADER.size + len(body), 12, seq, 1.) + body


class HandProtocolTests(unittest.TestCase):
    def test_extended_packet_keeps_every_previous_field(self):
        old, new = receiver.parse_packet(wire(7)), receiver.parse_packet(wire())
        self.assertEqual(len(wire()), 320)
        for key in old:
            if key not in ('hand_buttons', 'version'):
                self.assertEqual(old[key], new[key], key)
        self.assertIsNone(old['hand_buttons'])
        self.assertEqual(new['hand_buttons'], dict(available=True, left_available=True, right_available=True,
                                                  left_select_press=2, right_select_press=4))
        legacy = receiver.parse_packet(wire(8, available=1))
        self.assertNotIn('left_available', legacy['hand_buttons'])
        new.update(receive_s=1., gap_ms=None, rtt_ms=None, one_way_estimate_ms=None)
        row = receiver.packet_row(new, ('127.0.0.1', 5005))
        self.assertEqual(row['left_select_press'], 2)
        self.assertEqual(row['right_select_press'], 4)

    def test_invalid_length_or_availability_rejected(self):
        for data in (wire()[:-1], wire() + b'x', wire(available=4), wire(8, available=2)):
            with self.assertRaises(ValueError):
                receiver.parse_packet(data)

    def test_both_app_versions_receive_matching_pongs(self):
        r = receiver.PoseReceiver('127.0.0.1', 0).start()
        client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        client.settimeout(1)
        try:
            for version in (7, 8, 9):
                client.sendto(receiver.HEADER.pack(receiver.MAGIC, version, 2, 28, 12, 1, time.monotonic()), r.sock.getsockname())
                data, _ = client.recvfrom(100)
                self.assertEqual(receiver.HEADER.unpack_from(data)[1:3], (version, 3))
        finally:
            client.close()
            r.stop()

    def test_status_acknowledges_consumed_input_and_repeats_while_homing(self):
        r = receiver.PoseReceiver('127.0.0.1', 0).start()
        client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        client.settimeout(1)
        try:
            def exchange(seq):
                client.sendto(wire(seq=seq), r.sock.getsockname())
                data, _ = client.recvfrom(100)
                self.assertEqual(receiver.HEADER.unpack_from(data)[1:6], (9, 4, 40, 12, seq))
                return struct.unpack_from('<III', data, 28)
            self.assertEqual(exchange(1), (0, 1, 0))  # A pose monitor never commands motors.
            state = r.latest_snapshot()
            r.set_control_state('homing', state)
            self.assertEqual(exchange(2), (3, 1, 0))
            self.assertEqual(exchange(3), (3, 1, 0))
            # A later start must not be acknowledged by cached READY.
            r.set_control_state('ready', dict(latest=dict(session=12, arm_switch=dict(a_press=0, b_press=0))))
            self.assertEqual(exchange(4), (1, 0, 0))
            r.set_control_state('frozen', state)
            self.assertEqual(exchange(5), (4, 1, 0))
        finally:
            client.close()
            r.stop()

    def test_optional_gripper_receiver_copies_accept_same_packet(self):
        # Deployment validation supplies two staging copies beside this folder.
        for folder in ('meta_quest_hand', 'quest_teleoperation_improved'):
            path = Path(os.environ.get('HAND_COMPAT_ROOT', ROOT.parent)) / folder / 'quest_pose_receiver.py'
            if not path.exists():
                continue
            spec = importlib.util.spec_from_file_location('_hand_compat_' + folder, path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            self.assertEqual(module.parse_packet(wire())['controls'], receiver.parse_packet(wire())['controls'])
            self.assertEqual(module.parse_packet(wire())['hand_buttons']['left_select_press'], 2)


if __name__ == '__main__':
    unittest.main()
