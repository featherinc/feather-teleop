import copy
import csv
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
from test_quest_buttons import snapshot

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'outputs'))
import quest_trajectory_replay as replay_module


import time
import threading
class Tests(unittest.TestCase):

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.folder = Path(self.temp.name)
        self.specs, homes = ({}, {})
        self.rows = []
        for side, suffix in [('left', 'L'), ('right', 'R')]:
            names = [p + suffix for p in ['Sp', 'Sr', 'Sw', 'Ep', 'Ww', 'Wr', 'Wp']]
            self.specs[side] = {n: dict(name=f'{side}_{n}', lower=-1, upper=1, velocity=0.2, acceleration=0.3) for n in reversed(names)}
            homes[side] = dict(joint_names=names, joints_rad=[0] * 7)
        for t in [0.0, 0.1, 0.2]:
            for side in self.specs:
                row = dict(elapsed_s=t, calibration_id=1, side=side, converged='True', tracking_valid='True')
                row.update({f'joint_{i + 1}_rad': t * (i + 1) / 10 for i in range(7)})
                self.rows.append(row)
        (self.folder / 'calibration.json').write_text(json.dumps([dict(calibration_id=1, homes=homes)]))

    def load(self):
        with (self.folder / 'comparison.csv').open('w', newline='') as f:
            w = csv.DictWriter(f, fieldnames=self.rows[0].keys())
            w.writeheader()
            w.writerows(self.rows)
        return replay_module.load_trajectory(self.folder, self.specs)




    def fake_robot(self, plan):

        class Arm:

            def __init__(arm, side):
                arm.positions = copy.deepcopy(plan['frames'][0]['positions'][side])
                arm.calls = []
                arm.actuators_by_name = {s['name']: SimpleNamespace(config=SimpleNamespace(urdf_joint_name=j, angle_range=(-1, 1), max_velocity=0.2, max_acceleration=0.3), PARAM_SET=SimpleNamespace(mech_pos='position'), read_param=lambda p, block: 0.0) for j, s in self.specs[side].items()}

            def enable(arm):
                arm.calls.append(('enable', {}))

            def home(arm):
                arm.calls.append(('home', {}))
                arm.positions = {name: 0.0 for name in arm.positions}

            def freeze(arm, **kwargs):
                arm.calls.append(('freeze', kwargs))

            def set_targets(arm, **kwargs):
                arm.calls.append(('target', kwargs))
                arm.positions.update(kwargs['positions'])

            def capture_position(arm):
                return dict(arm.positions)
        system = SimpleNamespace(left_arm=Arm('left'), right_arm=Arm('right'))

        def disable():
            for arm in (system.left_arm, system.right_arm):
                arm.calls.append(('home_disable', {}))
                arm.positions = {n: 0.0 for n in arm.positions}
            time.sleep(0.05)
        system.disable = disable
        return SimpleNamespace(arms_system=system)

    def cells(self):
        roots=[Path(__file__).resolve().parents[1], Path(__file__).resolve().parents[1]/'outputs']
        path=next(p/'meta_quest_hand.ipynb' for p in roots if (p/'meta_quest_hand.ipynb').exists())
        return {c['id']:''.join(c['source']) for c in json.loads(path.read_text(encoding='utf-8'))['cells'] if c['cell_type']=='code'}

    def namespace(self, skip_hand_helpers=False):
        cells=self.cells()
        ns={}
        # Exercise this copied notebook from the local improved folder as well
        # as from its eventual robot path, without weakening its module guard.
        settings=cells['settings'].replace(
            "PROJECT = Path('/home/feather/Workspace/featheros/showcase/team/albert/meta_quest_hand')",
            f"PROJECT = Path({str(Path(__file__).resolve().parents[1])!r})")
        exec(settings,ns)
        plan=self.load()
        robot=self.fake_robot(plan)
        ns.update(RUN_HARDWARE=False,CONTROL_NECK=False,CONTROL_BASE=False,PROJECT=self.folder, home_target=copy.deepcopy(plan['frames'][0]['positions']),motor_specs=self.specs,robot=robot,CONTROL_HANDS=False,
                  arms=robot.arms_system,left_arm=robot.arms_system.left_arm,
                  right_arm=robot.arms_system.right_arm,torso=None,START_DELAY=0,REPLAY_SPEED=.5)
        import numpy as np
        from quest_television_ik import comparison_rows, COMPARISON_FIELDS
        class Mapper:
            def __init__(m):
                m.key=m.calibration=None
                m.accepted={}
                m.arms={side:SimpleNamespace(joint_names=list(reversed(list(specs))),
                    fk=lambda q:(np.zeros(3),np.eye(3)),home_p=np.zeros(3),home_R=np.eye(3))
                    for side,specs in self.specs.items()}
            def start_parallel(m):
                m.parallel_started = True
            def close(m):
                m.parallel_closed = True
            def set_sdk_joint_limits(m, limits):
                m.sdk_joint_limits=limits
            def process(m,packet):
                m.key=(packet['session'],packet['calibration_id'])
                m.calibration={'session':packet['session'],'calibration_id':packet['calibration_id']}
                result={}
                for side in m.arms:
                    m.accepted.setdefault(side,dict(joints_rad=[0.]*7,wrist=[0.,0.,0.,0.,0.,0.,1.]))
                    valid=packet['poses'][side]['position_valid'] and packet['poses'][side]['rotation_valid']
                    value=packet.get('live_value',.1)
                    if valid:
                        m.accepted[side]['joints_rad']=[value]*7
                    candidate=(dict(converged=True, iterations=1, position_error_mm=0.,
                                    rotation_error_deg=0., failure_reason=None,
                                    seed_source='accepted', warm_start_used=True,
                                    database_fallback_used=False) if valid else None)
                    result[side]=m._output(side,packet['poses'][side],[0.,0.,0.,0.,0.,0.,1.],
                                           candidate=candidate,
                                           reason='following' if valid else 'tracking_lost')
                return result
            def _output(m,side,original,target,candidate=None,reason='tracking_lost'):
                return dict(raw=original['position_m']+original['quaternion_xyzw'], target=target,
                    **copy.deepcopy(m.accepted[side]),converged=bool(candidate and candidate['converged']),
                    holding=reason!='following', reason=reason, candidate=candidate,
                    position_error_mm=0.,rotation_error_deg=0.,solve_ms=0.,
                    iterations=None if candidate is None else candidate.get('iterations'),
                    candidate_position_error_mm=None if candidate is None else candidate.get('position_error_mm'),
                    candidate_rotation_error_deg=None if candidate is None else candidate.get('rotation_error_deg'),
                    candidate_limit_joints=None if candidate is None else candidate.get('candidate_limit_joints'),
                    failure_reason=None if candidate is None else candidate.get('failure_reason'),
                    seed_source=None if candidate is None else candidate.get('seed_source'),
                    warm_start_used=None if candidate is None else candidate.get('warm_start_used'),
                    database_fallback_used=None if candidate is None else candidate.get('database_fallback_used'))
        ns.update(mapper=Mapper(),comparison_rows=comparison_rows,COMPARISON_FIELDS=COMPARISON_FIELDS)
        for key in ['arm-functions','hand-functions','torso-functions','preflight']:
            if key == 'hand-functions' and skip_hand_helpers:
                continue
            exec(cells[key],ns)
        return ns,robot


    def receiver(self,now,stop=False):
        class Receiver:
            def start(r,*args): return r
            def stop(r): r.stopped=True
            def set_control_state(r, phase, state=None): r.control_phase=phase
            def latest_snapshot(r):
                if getattr(r,'stopped',False):
                    return r.last_state
                r.last_state=r.snapshot()
                return r.last_state
            def snapshot(r):
                t=now[0]
                if t>1.1: raise KeyboardInterrupt()
                a,b,run=(0,0,False) if t<.02 else (1,0,True) if t<.18 else (1,1,False) if t<.28 else (2,1,True) if t<.8 else (2,2,False)
                state=snapshot(a,b,run,now=t)
                state['latest'].update(seq=int(t*1000),calibration_id=a,live_value=min(t,.5))
                return state
        return Receiver()










    def test_b_during_ik_and_expired_results_never_send_motion(self):
        for fault in ['b','expired']:
            with self.subTest(fault=fault):
                ns,robot=self.namespace()
                now=[0.0];stopped=[False]
                receiver=self.receiver(now)
                def state():
                    if now[0]>.5: raise KeyboardInterrupt()
                    a=1 if now[0]>=.02 else 0
                    s=snapshot(a,int(stopped[0]),bool(a) and not stopped[0],now=now[0])
                    s['latest'].update(seq=int(now[0]*1000),calibration_id=a,live_value=.4)
                    return s
                receiver.snapshot=state
                original=ns['solve_live']
                def solve(p,previous):
                    result=original(p,previous)
                    if fault=='b': stopped[0]=True
                    else: now[0]+=.31
                    return result
                ns.update(RUN_HARDWARE=True,PoseReceiver=lambda:receiver,solve_live=solve)
                with patch.object(time,'monotonic',lambda:now[0]), \
                     patch.object(time,'sleep',lambda dt:now.__setitem__(0,now[0]+dt)):
                    exec(self.cells()['run'],ns)
                for arm in [robot.arms_system.left_arm,robot.arms_system.right_arm]:
                    targets=[kw['positions'] for name,kw in arm.calls if name=='target']
                    self.assertTrue(targets)
                    self.assertTrue(all(v==0 for t in targets for v in t.values()))
                    self.assertEqual(arm.calls[-1][0],'home_disable' if fault=='b' else 'freeze')
                    if fault=='expired':
                        self.assertFalse(any(name=='home_disable' for name,_ in arm.calls))

    def test_timeout_freezes_without_homing_and_ignores_recovery_and_a(self):
        ns,robot=self.namespace();now=[0.0];receiver=self.receiver(now)
        def state():
            t=now[0]
            if t>1.0: raise KeyboardInterrupt()
            a=0 if t<.02 else 1 if t<.7 else 2
            s=snapshot(a,0,bool(a),now=t,received=.10 if .10<t<.60 else t)
            s['latest'].update(seq=int(t*1000),calibration_id=a,live_value=.2)
            return s
        receiver.snapshot=state
        targets=[]
        original=robot.arms_system.left_arm.set_targets
        robot.arms_system.left_arm.set_targets=lambda **kw:(targets.append(now[0]),original(**kw))
        ns.update(RUN_HARDWARE=True,PoseReceiver=lambda:receiver)
        with patch.object(time,'monotonic',lambda:now[0]), \
             patch.object(time,'sleep',lambda dt:now.__setitem__(0,now[0]+dt)):
            exec(self.cells()['run'],ns)
        for arm in [robot.arms_system.left_arm,robot.arms_system.right_arm]:
            self.assertFalse(any(name=='home_disable' for name,_ in arm.calls))
            self.assertEqual(sum(name=='enable' for name,_ in arm.calls),1)
            self.assertEqual(arm.calls[-1],('freeze',{'clean_parameters':False}))
        self.assertTrue(targets)
        self.assertLess(max(targets),.401)
        self.assertTrue(ns['frozen'])
        self.assertFalse(ns['torso_allowed'].is_set())





    def test_active_pose_packet_preserves_original_anchors_without_mutating_udp(self):
        ns,_=self.namespace()
        ns.update(active_key=(10,1),active_anchors={'head':{'position_m':[1,2,3]}})
        packet={'session':10,'calibration_id':3,'anchors':{'new':True},'seq':12}
        normalized=ns['active_pose_packet'](packet)
        self.assertEqual(normalized['calibration_id'],1)
        self.assertEqual(normalized['anchors'],ns['active_anchors'])
        self.assertEqual(packet['calibration_id'],3)
        self.assertEqual(packet['anchors'],{'new':True})












if __name__=='__main__': unittest.main(verbosity=2)
