"""Run only config integration tests with the SDK contract hardware guards.

Keep check_sdk_contract.py beside this runner. Run in a fresh interpreter:
  python -B run_native_config_tests.py APP_DIR --sdk-src REPO/feathersdk/src \
      --report /tmp/meta-quest-sdk-offline-7scrdite/native-config-tests.json
"""
from __future__ import annotations

import argparse
import importlib.abc
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import threading
import unittest

import check_sdk_contract as guards


class NoPeripheralImports(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split('.')[0] in {'can', 'serial', 'pyzed'}:
            raise ImportError('Native config test blocked peripheral import: ' + fullname)
        return None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('project', type=Path)
    parser.add_argument('--sdk-src', type=Path, required=True)
    parser.add_argument('--config', type=Path)
    parser.add_argument('--urdf', type=Path)
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    guards.REPORT_DIRECTORY = args.report.resolve().parent if args.report else None
    if guards.REPORT_DIRECTORY is not None:
        guards.REPORT_DIRECTORY.mkdir(parents=True, exist_ok=True)
        # Set this before the audit hook: tempfile's default-directory probe
        # writes outside the sole permitted report directory on Linux.
        # Individual test contexts still clean up their own child directories.
        tempfile.tempdir = str(guards.REPORT_DIRECTORY)
    sys.dont_write_bytecode = True
    sys.meta_path.insert(0, NoPeripheralImports())
    sys.addaudithook(guards.guard)
    sys.setprofile(guards.profile)
    threading.Thread.start = guards.denied
    os.environ['QUEST_TEST_NATIVE_SDK'] = '1'
    os.environ['NUMBA_DISABLE_JIT'] = '1'
    project = args.project.resolve(strict=True)
    sdk_src = args.sdk_src.resolve(strict=True)
    sys.path[:0] = [str(project), str(project / 'tests'), str(sdk_src)]
    constructors = guards.install_constructor_traps()
    sys.setprofile(guards.profile)
    # Exactly this config-only test module is collected; ordinary app tests
    # retain their separately audited loopback/fake-worker runner.
    test_path = project / 'tests' / 'test_sdk_config_native.py'
    spec = importlib.util.spec_from_file_location('test_sdk_config_native', test_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    # Staging can use the original checkout's read-only SDK/config/URDF sources.
    module.REPO = sdk_src.parents[1]
    if args.config:
        module.CONFIG = args.config.resolve(strict=True)
    if args.urdf:
        module.URDF = args.urdf.resolve(strict=True)
    suite = unittest.defaultTestLoader.loadTestsFromModule(module)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    sys.setprofile(guards.profile)
    summary = {'project': str(project), 'run': result.testsRun, 'success': result.wasSuccessful(),
               'failures': len(result.failures), 'errors': len(result.errors), 'skipped': len(result.skipped),
               'failure_ids': [case.id() for case, _ in result.failures],
               'error_ids': [case.id() for case, _ in result.errors],
               'constructor_traps': constructors,
               'profile_guard_active': sys.getprofile() is guards.profile}
    if args.report:
        args.report.write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(summary, indent=2))
    return 0 if summary['success'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
