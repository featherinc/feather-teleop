"""Run the improved live cell with synthetic input and robot doubles only."""
from pathlib import Path
import csv
import sys
import types
import unittest
from unittest.mock import patch
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'tests'))

# QuestIK's imports need Pinocchio, though this test supplies a fake mapper.
try:
    import pinocchio  # noqa: F401
except ImportError:
    sys.modules['pinocchio'] = types.ModuleType('pinocchio')
try:
    import scipy.spatial  # noqa: F401
except ImportError:
    scipy = types.ModuleType('scipy')
    spatial = types.ModuleType('scipy.spatial')
    transform = types.ModuleType('scipy.spatial.transform')
    spatial.KDTree = object
    transform.Rotation = object
    scipy.spatial = spatial
    spatial.transform = transform
    sys.modules.update({'scipy': scipy, 'scipy.spatial': spatial,
                        'scipy.spatial.transform': transform})

import test_quest_notebook as legacy
from test_quest_buttons import snapshot
import quest_television_ik as ik_module


class Clock:
    def __init__(self):
        self.now_s = 0.0

    def monotonic(self):
        return self.now_s

    def sleep(self, seconds):
        self.now_s += max(0.001, seconds)


class Receiver:
    def __init__(self, clock):
        self.clock = clock
        self.stopped = False
        self.samples = []
        self.phases = []

    def start(self, *_args):
        return self

    def stop(self):
        self.stopped = True

    def set_control_state(self, phase, state=None):
        self.control_phase = phase
        self.phases.append(phase)

    def latest_snapshot(self):
        t = self.clock.now_s
        if t >= 0.47 and not self.stopped:
            raise KeyboardInterrupt
        if t < .02:
            a, b, run = 0, 0, False
        elif t < .16:
            a, b, run = 1, 0, True
        elif t < .27:
            a, b, run = 1, 1, False
        else:
            a, b, run = 2, 1, True
        state = snapshot(a, b, run, now=t)
        state['latest'].update(seq=int(t * 1000), calibration_id=a, sent_s=t)
        self.samples.append((t, a, b, run))
        return state


class ImprovedNotebook(unittest.TestCase):
    def fixture(self):
        harness = legacy.Tests()
        harness.setUp()
        self.addCleanup(harness.doCleanups)
        ns, robot = harness.namespace()
        ns.update(RUN_HARDWARE=True, CONTROL_BASE=False, CONTROL_HANDS=False,
                  PROJECT=harness.folder)
        return harness, ns, robot

    def test_b_homes_then_fresh_a_restarts_with_async_logging(self):
        for detail in (False, True):
            with self.subTest(details=detail):
                harness, ns, robot = self.fixture()
                ns['mapper'].set_sdk_joint_limits = lambda _limits: None
                ns['COMPARISON_FIELDS'] = ['side', 'seq']
                ns['comparison_rows'] = lambda packet, result, elapsed, status: [
                    {'side': side, 'seq': packet['seq']} for side in ('left', 'right')]
                ns.update(RUN_HARDWARE=True, CONTROL_BASE=False, CONTROL_HANDS=False,
                          PROJECT=harness.folder)
                ns['LOG_MOTION_DETAILS'] = detail
                clock = Clock()
                receiver = Receiver(clock)
                ns['PoseReceiver'] = lambda: receiver
                with patch.object(time, 'monotonic', clock.monotonic), \
                     patch.object(time, 'sleep', clock.sleep), \
                     patch.object(ik_module, 'pose_values', lambda *_args: [0., 0., 0., 0., 0., 0., 1.]):
                    exec(harness.cells()['run'], ns)
                self.assertTrue(receiver.stopped)
                home = receiver.phases.index("homing")
                self.assertEqual(receiver.phases[home + 1], "ready")
                self.assertIn("active", receiver.phases)
                self.assertTrue(ns['mapper'].parallel_started)
                self.assertTrue(ns['mapper'].parallel_closed)
                for arm in (robot.arms_system.left_arm, robot.arms_system.right_arm):
                    calls = [name for name, _ in arm.calls]
                    self.assertGreaterEqual(calls.count('enable'), 2)
                    self.assertGreaterEqual(calls.count('home_disable'), 2)
                    self.assertGreater(calls.count('target'), 0)
                sessions = list((harness.folder / 'recordings' / 'live').glob('session_*'))
                self.assertEqual(len(sessions), 1)
                self.assertTrue((sessions[0] / 'logging_summary.json').exists())
                self.assertEqual((sessions[0] / 'comparison.csv').exists(), detail)
                self.assertEqual((sessions[0] / 'feedback.csv').exists(), detail)
                with (sessions[0] / 'timing.csv').open(newline='') as stream:
                    rows = list(csv.DictReader(stream))
                self.assertTrue(rows)
                self.assertIn('kernel_to_python_ms', rows[0])
                self.assertIn('left_converged', rows[0])
                self.assertEqual(rows[0]['kernel_to_python_ms'], '')

    def test_worker_start_failure_never_enables_arms_and_closes_mapper(self):
        harness, ns, robot = self.fixture()
        clock = Clock()
        receiver = Receiver(clock)
        ns['PoseReceiver'] = lambda: receiver
        def fail():
            raise RuntimeError('worker startup failed')
        ns['mapper'].start_parallel = fail
        with self.assertRaisesRegex(RuntimeError, 'worker startup failed'):
            exec(harness.cells()['run'], ns)
        self.assertTrue(ns['mapper'].parallel_closed)
        self.assertTrue(receiver.stopped)
        self.assertFalse(robot.arms_system.left_arm.calls)
        self.assertFalse(robot.arms_system.right_arm.calls)

    def test_invalid_ik_measured_hold_and_bounded_recovery(self):
        _, ns, robot = self.fixture()
        ns['velocities'], ns['accelerations'] = ns['check_start']()
        base = 12345.0  # SDK telemetry uses monotonic nanoseconds, even after long uptime.
        ns['arm_motion'] = ns['new_arm_motion'](base)
        ns['mapper'].accepted = {side: dict(joints_rad=[0.] * 7,
            wrist=[0., 0., 0., 0., 0., 0., 1.]) for side in ('left', 'right')}
        packet = snapshot(1, 0, True, now=0.0)['latest']
        packet['calibration_id'] = 1
        left = robot.arms_system.left_arm
        captures = []
        original_capture = left.capture_position

        def capture():
            captures.append(True)
            return original_capture()

        left.capture_position = capture
        now = [base]
        stamp = [int(base * 1e9)]
        for arm in (left, robot.arms_system.right_arm):
            for motor in arm.actuators_by_name.values():
                motor.telemetry = types.SimpleNamespace(
                    get_latest_timestamp=lambda *_args, **_kwargs: stamp[0])

        def prepare(when, left_valid):
            now[0] = base + when
            stamp[0] = int(now[0] * 1e9)
            packet['sent_s'] = now[0]
            result, candidate = {}, {}
            for side in ('left', 'right'):
                valid = left_valid if side == 'left' else True
                item = dict(converged=True, iterations=1, position_error_mm=0.,
                            rotation_error_deg=0., failure_reason=None,
                            seed_source='accepted', warm_start_used=True,
                            database_fallback_used=False) if valid else None
                result[side] = ns['mapper']._output(
                    side, packet['poses'][side], [0., 0., 0., 0., 0., 0., 1.],
                    candidate=item, reason='following' if valid else 'tracking_lost')
                candidate[side] = {name: .4 for name in ns['home_target'][side]}
            positions, velocities = ns['prepare_arm_commands'](
                packet, result, candidate, now[0])
            return positions, velocities, result

        with patch.object(time, 'monotonic', lambda: now[0]), \
             patch.object(ik_module, 'pose_values', lambda *_args: [0., 0., 0., 0., 0., 0., 1.]):
            prepare(.033, True)
            moving_pos, moving_vel, _ = prepare(.066, True)
            self.assertTrue(any(v > 0 for v in moving_vel['left'].values()))
            held_pos, held_vel, held_result = prepare(.10, False)
            self.assertEqual(held_pos['left'], moving_pos['left'])
            self.assertTrue(all(v == 0 for v in held_vel['left'].values()))
            self.assertEqual(held_result['left']['command_state'], 'invalid_hold')
            self.assertEqual(len(captures), 0)

            left.positions = {name: .08 for name in left.positions}
            measured_pos, measured_vel, measured_result = prepare(.42, False)
            self.assertEqual(measured_pos['left'], left.positions)
            self.assertTrue(all(v == 0 for v in measured_vel['left'].values()))
            self.assertEqual(measured_result['left']['command_state'], 'persistent_hold')
            self.assertNotEqual(measured_result['right']['command_state'], 'persistent_hold')
            self.assertGreater(next(iter(measured_pos['right'].values())),
                               next(iter(held_pos['right'].values())))
            self.assertEqual(len(captures), 1)
            prepare(.45, False)
            self.assertEqual(len(captures), 1)

            recovered_pos, recovered_vel, recovered_result = prepare(.48, True)
            self.assertEqual(recovered_result['left']['command_state'], 'recovering')
            self.assertTrue(all(v == 0 for v in recovered_vel['left'].values()))
            self.assertGreater(next(iter(recovered_pos['left'].values())), .08)
            self.assertLessEqual(recovered_result['left']['max_step_rad'],
                                 .2 * 1.5 / ns['CONTROL_HZ'] + 1e-9)
            self.assertTrue(recovered_result['left']['converged'])

    def test_persistent_hold_waits_for_fresh_feedback_and_recovers_independently(self):
        _, ns, robot = self.fixture()
        ns['velocities'], ns['accelerations'] = ns['check_start']()
        base = 12345.0
        ns['arm_motion'] = ns['new_arm_motion'](base)
        ns['mapper'].accepted = {side: dict(joints_rad=[0.] * 7,
            wrist=[0., 0., 0., 0., 0., 0., 1.]) for side in ('left', 'right')}
        packet = snapshot(1, 0, True, now=0.0)['latest']
        now = [base]
        stamp = [int(base * 1e9)]
        left = robot.arms_system.left_arm
        for motor in left.actuators_by_name.values():
            motor.telemetry = types.SimpleNamespace(
                get_latest_timestamp=lambda *_args, **_kwargs: stamp[0])
        candidate = {side: {name: .4 for name in ns['home_target'][side]}
                     for side in ('left', 'right')}

        def prepare(when, left_valid):
            now[0] = base + when
            packet['sent_s'] = now[0]
            result = {}
            for side in ('left', 'right'):
                valid = left_valid if side == 'left' else True
                result[side] = ns['mapper']._output(
                    side, packet['poses'][side], [0., 0., 0., 0., 0., 0., 1.],
                    candidate={'converged': True} if valid else None,
                    reason='following' if valid else 'tracking_lost')
            positions, velocities = ns['prepare_arm_commands'](
                packet, result, candidate, now[0])
            return positions, velocities, result

        with patch.object(time, 'monotonic', lambda: now[0]), \
             patch.object(ik_module, 'pose_values', lambda *_args: [0., 0., 0., 0., 0., 0., 1.]):
            held_pos, _, _ = prepare(.01, False)
            left.positions = {name: .08 for name in left.positions}
            waiting_pos, waiting_vel, waiting_result = prepare(.32, False)
            self.assertEqual(waiting_result['left']['command_state'], 'feedback_wait')
            self.assertEqual(waiting_pos['left'], held_pos['left'])
            self.assertTrue(all(v == 0 for v in waiting_vel['left'].values()))
            self.assertGreater(next(iter(waiting_pos['right'].values())),
                               next(iter(held_pos['right'].values())))

            valid_pos, valid_vel, valid_result = prepare(.35, True)
            self.assertEqual(valid_result['left']['command_state'], 'feedback_wait')
            self.assertEqual(valid_pos['left'], held_pos['left'])
            self.assertTrue(all(v == 0 for v in valid_vel['left'].values()))
            self.assertGreater(next(iter(valid_pos['right'].values())),
                               next(iter(waiting_pos['right'].values())))

            stamp[0] = int((base + .38) * 1e9)
            rebased_pos, rebased_vel, rebased_result = prepare(.38, True)
            self.assertEqual(rebased_result['left']['command_state'], 'persistent_hold')
            self.assertEqual(rebased_pos['left'], left.positions)
            self.assertTrue(all(v == 0 for v in rebased_vel['left'].values()))

            recovered_pos, recovered_vel, recovered_result = prepare(.41, True)
            self.assertEqual(recovered_result['left']['command_state'], 'recovering')
            self.assertGreater(next(iter(recovered_pos['left'].values())), .08)
            self.assertTrue(all(v == 0 for v in recovered_vel['left'].values()))
            self.assertLessEqual(recovered_result['left']['max_step_rad'],
                                 .2 * 1.5 / ns['CONTROL_HZ'] + 1e-9)

    def test_live_watchdog_clears_endpoint_velocity_on_repeated_sequence(self):
        harness, ns, robot = self.fixture()
        ns['COMPARISON_FIELDS'] = ['side', 'seq']
        ns['comparison_rows'] = lambda packet, result, elapsed, status: [
            {'side': side, 'seq': packet['seq']} for side in ('left', 'right')]
        clock = Clock()
        events = []

        class PausingReceiver:
            stopped = False

            def start(self, *_args):
                return self

            def stop(self):
                self.stopped = True

            def set_control_state(self, phase, state=None):
                self.control_phase = phase

            def latest_snapshot(self):
                t = clock.now_s
                if t >= .27 and not self.stopped:
                    raise KeyboardInterrupt
                started = t >= .02
                received = min(t, .14)
                state = snapshot(int(started), 0, started, now=t, received=received)
                state['latest'].update(seq=int(received * 1000),
                                       calibration_id=int(started), sent_s=received)
                return state

        receiver = PausingReceiver()
        ns['PoseReceiver'] = lambda: receiver
        for arm in (robot.arms_system.left_arm, robot.arms_system.right_arm):
            original = arm.set_targets

            def record(*, _original=original, **kwargs):
                events.append((clock.now_s, dict(kwargs['positions']),
                               dict(kwargs['target_velocities'])))
                return _original(**kwargs)

            arm.set_targets = record
        with patch.object(time, 'monotonic', clock.monotonic), \
             patch.object(time, 'sleep', clock.sleep), \
             patch.object(ik_module, 'pose_values', lambda *_args: [0., 0., 0., 0., 0., 0., 1.]):
            exec(harness.cells()['run'], ns)
        self.assertTrue(receiver.stopped)
        moving = [(t, pos) for t, pos, velocity in events
                  if any(abs(v) > 0 for v in velocity.values())]
        stopped = [(t, pos) for t, pos, velocity in events
                   if t >= .14 and all(v == 0 for v in velocity.values())]
        self.assertTrue(moving, events)
        self.assertTrue(stopped, events)
        self.assertTrue(any(t > moving[-1][0] and pos == moving[-1][1]
                            and t < .14 + .3 for t, pos in stopped))


if __name__ == '__main__':
    unittest.main()
