"""Native base preflight validation without SDK imports or command dispatch."""

import copy
import inspect
import math
from types import SimpleNamespace
import unittest
from unittest.mock import Mock

from quest_sdk_compat import validate_base_navigation


def navigation():
    def set_velocity(vx, vy, omega, orient_only=False):
        pass

    def set_strict_directions(value):
        pass

    velocity = Mock()
    velocity.__signature__ = inspect.signature(set_velocity)
    strict_setter = Mock()
    strict_setter.__signature__ = inspect.signature(set_strict_directions)
    return SimpleNamespace(
        config=SimpleNamespace(wheel_radius=.1,
                               wheel_positions=[(.3, 0), (-.2, -.25), (-.2, .25)]),
        drive_motors=[SimpleNamespace(config=SimpleNamespace(name='drive_' + side, max_velocity=10.47))
                      for side in ('center', 'right', 'left')],
        turning_motors=[SimpleNamespace(config=SimpleNamespace(
            name='turning_' + side, angle_range=(-math.radians(100), math.radians(100))))
                        for side in ('center', 'right', 'left')],
        set_velocity=velocity, set_strict_directions=strict_setter,
        get_strict_directions=Mock(return_value=True))


class NativeBaseConfigTests(unittest.TestCase):
    def setUp(self):
        self.nav = navigation()

    def validate(self, **settings):
        return validate_base_navigation(self.nav, **dict(
            {'linear_speed': .2, 'yaw_speed': 1.0, 'deadzone': .15}, **settings))

    def assert_no_commands(self):
        if isinstance(self.nav.set_velocity, Mock):
            self.nav.set_velocity.assert_not_called()
        if isinstance(getattr(self.nav, 'set_strict_directions', None), Mock):
            self.nav.set_strict_directions.assert_not_called()

    def test_native_geometry_and_settings_pass_without_commands_or_mutation(self):
        before = copy.deepcopy((self.nav.config, self.nav.drive_motors, self.nav.turning_motors))
        self.assertIsNone(self.validate())
        self.assertEqual((self.nav.config, self.nav.drive_motors, self.nav.turning_motors), before)
        self.nav.get_strict_directions.assert_called_once_with()
        self.assert_no_commands()

    def test_body_speed_settings_are_not_compared_to_wheel_rad_per_second_limits(self):
        for drive in self.nav.drive_motors:
            drive.config.max_velocity = .01
        self.assertIsNone(self.validate(linear_speed=.2, yaw_speed=1.0))
        self.assert_no_commands()

    def test_signature_checks_never_dispatch_velocity(self):
        called = []
        for bad in (None, lambda vx, vy: called.append((vx, vy)),
                    lambda *, vx, vy, omega: called.append((vx, vy, omega))):
            with self.subTest(method=bad):
                self.nav.set_velocity = bad
                with self.assertRaisesRegex(RuntimeError, 'set_velocity'):
                    self.validate()
        self.assertEqual(called, [])
        self.nav.get_strict_directions.assert_not_called()

    def test_public_strict_getter_is_required_and_must_return_true(self):
        for getter in (None, lambda required: True, lambda: False, lambda: 1, lambda: None):
            with self.subTest(getter=getter):
                self.nav.get_strict_directions = getter
                self.nav._strict_directions = True
                with self.assertRaisesRegex(RuntimeError, 'strict|signature'):
                    self.validate()
                self.assert_no_commands()

    def test_continuous_steering_mode_is_accepted_without_setting_it(self):
        self.nav.get_strict_directions.return_value = False
        self.nav._strict_directions = True  # Validation must read the public getter.
        before = copy.deepcopy((self.nav.config, self.nav.drive_motors, self.nav.turning_motors))
        self.assertIsNone(self.validate(strict_directions=False))
        self.nav.get_strict_directions.assert_called_once_with()
        self.assertEqual((self.nav.config, self.nav.drive_motors, self.nav.turning_motors), before)
        self.assertTrue(self.nav._strict_directions)
        self.assert_no_commands()

    def test_requested_strict_mode_must_be_a_bool_before_any_navigation_read(self):
        for value in (0, 1, 0.0, 'False', b'False', None):
            with self.subTest(strict_directions=value):
                with self.assertRaisesRegex(ValueError, 'strict.*bool'):
                    self.validate(strict_directions=value)
        self.nav.get_strict_directions.assert_not_called()
        self.assert_no_commands()

    def test_public_strict_state_must_match_either_requested_mode_and_be_bool(self):
        for requested, actual in ((True, False), (False, True), (False, 0),
                                  (True, 1), (False, None), (True, 'True')):
            with self.subTest(requested=requested, actual=actual):
                self.nav.get_strict_directions.return_value = actual
                with self.assertRaisesRegex(RuntimeError, 'strict'):
                    self.validate(strict_directions=requested)
                self.assert_no_commands()

    def test_public_strict_setter_signature_is_required_without_dispatching_it(self):
        calls = []
        for setter in (None, lambda: calls.append(None),
                       lambda value, required: calls.append(value),
                       lambda *, value: calls.append(value)):
            with self.subTest(setter=setter):
                self.nav.set_strict_directions = setter
                with self.assertRaisesRegex(RuntimeError, 'set_strict_directions'):
                    self.validate(strict_directions=False)
                self.assert_no_commands()
        del self.nav.set_strict_directions
        with self.assertRaisesRegex(RuntimeError, 'set_strict_directions'):
            self.validate()
        self.assertEqual(calls, [])
        self.nav.get_strict_directions.assert_not_called()
        self.assert_no_commands()

    def test_unresolved_nonfinite_or_nonpositive_wheel_radius_is_rejected(self):
        for value in (None, 0, -.1, math.nan, math.inf, -math.inf, True, 'invalid', '0.06', b'0.06'):
            with self.subTest(radius=value):
                self.nav.config.wheel_radius = value
                with self.assertRaisesRegex(ValueError, 'wheel radius'):
                    self.validate()
                self.assert_no_commands()

    def test_exactly_three_finite_two_dimensional_wheel_positions_are_required(self):
        invalid = (None, [], [(0, 0)] * 2, [(0, 0)] * 4,
                   [(0, 0), (0,), (0, 0)], [(0, 0), (0, 0, 0), (0, 0)],
                   [(0, 0), (math.nan, 0), (0, 0)], [(0, 0), (0, math.inf), (0, 0)],
                   [(0, 0), ('invalid', 0), (0, 0)], [(0, 0), ('0.1', 0), (0, 0)],
                   [(0, 0), (0, b'0.1'), (0, 0)], [(0, 0), (True, 0), (0, 0)],
                   {(0, 0): 1, (1, 0): 2, (0, 1): 3})
        for positions in invalid:
            with self.subTest(positions=positions):
                self.nav.config.wheel_positions = positions
                with self.assertRaisesRegex(ValueError, 'position|positions'):
                    self.validate()
                self.assert_no_commands()

    def test_geometry_requires_three_uniquely_named_drive_and_turning_motors(self):
        for attribute in ('drive_motors', 'turning_motors'):
            for shape in ('missing', 'short', 'long', 'duplicate', 'nameless'):
                with self.subTest(attribute=attribute, shape=shape):
                    self.nav = navigation()
                    motors = getattr(self.nav, attribute)
                    if shape == 'missing':
                        delattr(self.nav, attribute)
                    elif shape == 'short':
                        setattr(self.nav, attribute, motors[:2])
                    elif shape == 'long':
                        setattr(self.nav, attribute, motors + [copy.deepcopy(motors[0])])
                    elif shape == 'duplicate':
                        motors[1].config.name = motors[0].config.name
                    else:
                        motors[1].config.name = None
                    with self.assertRaisesRegex(ValueError, 'motors'):
                        self.validate()
                    self.assert_no_commands()

    def test_each_steering_range_must_be_finite_ordered_and_cover_sideways_headings(self):
        invalid = (None, (0,), (-math.pi, 0, math.pi), (math.nan, math.pi),
                   (-math.pi, math.inf), (math.pi, -math.pi), (0, 0),
                   ('-1.75', 1.75), (-1.75, b'1.75'),
                   (-math.radians(89), math.pi), (-math.pi, math.radians(89)))
        for index in range(3):
            for limits in invalid:
                with self.subTest(index=index, limits=limits):
                    self.nav = navigation()
                    self.nav.turning_motors[index].config.angle_range = limits
                    with self.assertRaisesRegex(ValueError, 'Steering range'):
                        self.validate()
                    self.assert_no_commands()
        for turn in self.nav.turning_motors:
            turn.config.angle_range = (-math.pi / 2, math.pi / 2)
        self.assertIsNone(self.validate())
        self.assert_no_commands()

    def test_each_drive_velocity_limit_must_be_positive_and_finite(self):
        for index in range(3):
            for limit in (None, 0, -1, math.nan, math.inf, True, 'invalid', '10.47', b'10.47'):
                with self.subTest(index=index, limit=limit):
                    self.nav = navigation()
                    self.nav.drive_motors[index].config.max_velocity = limit
                    with self.assertRaisesRegex(ValueError, 'Drive limit'):
                        self.validate()
                    self.assert_no_commands()

    def test_speed_settings_and_deadzone_are_validated_without_reading_or_commanding_navigation(self):
        for name in ('linear_speed', 'yaw_speed'):
            for value in (0, -1, math.nan, math.inf, True, None, 'invalid', '0.2', '1', b'1'):
                with self.subTest(setting=name, value=value):
                    with self.assertRaisesRegex(ValueError, 'speed'):
                        self.validate(**{name: value})
        for value in (-.001, 1, 2, math.nan, math.inf, True, None, 'invalid', '0.1', b'0.1'):
            with self.subTest(deadzone=value):
                with self.assertRaisesRegex(ValueError, 'deadzone'):
                    self.validate(deadzone=value)
        self.nav.get_strict_directions.assert_not_called()
        self.assert_no_commands()
        for value in (0, .999):
            self.assertIsNone(self.validate(deadzone=value))
        self.assert_no_commands()


if __name__ == '__main__':
    unittest.main()
