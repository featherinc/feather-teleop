"""Recenter protocol and control tests. Uses fake SDK arms; no hardware."""
import copy
import time
import unittest
from unittest.mock import patch

import quest_pose_receiver as receiver_module
from quest_pose_receiver import HEADER, RECENTER, RECENTER_POSE_SIZE, parse_packet, ArmRunGate, packet_row
from test_quest_base import turn_packet
from test_quest_buttons import snapshot
import test_quest_notebook as notebook_tests


def recenter_packet(epoch):
    old = turn_packet(.4, x=.2, y=-.3)
    header = list(HEADER.unpack_from(old))
    header[1], header[3] = 7, RECENTER_POSE_SIZE
    return HEADER.pack(*header) + old[HEADER.size:] + RECENTER.pack(epoch)


def state(a=0, b=0, run=False, epoch=0, now=10.):
    s = snapshot(a, b, run, now=now)
    s['latest']['recenter_id'] = epoch
    return s


class RecenterProtocolTests(unittest.TestCase):
    def test_wire_format_legacy_and_recording(self):
        p = parse_packet(recenter_packet(17))
        self.assertEqual(len(recenter_packet(17)), 308)
        self.assertEqual(p['recenter_id'], 17)
        self.assertAlmostEqual(p['controls']['base_turn'], .4, places=6)
        self.assertEqual(parse_packet(turn_packet())['recenter_id'], 0)
        p.update(receive_s=1, gap_ms=None, rtt_ms=None, one_way_estimate_ms=None)
        row = packet_row(p, ('127.0.0.1', 5005))
        self.assertEqual(row['recenter_id'], 17)
        self.assertEqual(row['calibration_id'], p['calibration_id'])
        with self.assertRaises(ValueError):parse_packet(recenter_packet(17)[:-1])

    def test_recenter_ready_requires_a_but_lost_event_packet_does_not_lose_a(self):
        gate = ArmRunGate()
        self.assertFalse(gate.update(state(), 10))
        self.assertFalse(gate.update(state(epoch=1), 10))
        self.assertTrue(gate.update(state(a=1, run=True, epoch=1), 10))
        gate = ArmRunGate(); gate.update(state(), 10)
        self.assertTrue(gate.update(state(a=1, run=True, epoch=7), 10))

    def test_running_recenter_cancels_run_even_if_extra_a_arrives_together(self):
        gate = ArmRunGate(); gate.update(state(), 10)
        self.assertTrue(gate.update(state(a=1, run=True), 10))
        self.assertFalse(gate.update(state(a=2, run=True, epoch=3), 10))
        self.assertIn('recentered', gate.reason)
        self.assertFalse(gate.update(state(a=2, run=True, epoch=3), 10))
        self.assertFalse(gate.update(state(a=2, b=1, epoch=3), 10))
        self.assertTrue(gate.update(state(a=3, b=1, run=True, epoch=3), 10))

    def test_recenter_counter_wrap_still_cancels(self):
        gate = ArmRunGate(); gate.update(state(epoch=0xffffffff), 10)
        gate.update(state(a=1, run=True, epoch=0xffffffff), 10)
        self.assertFalse(gate.update(state(a=1, run=True, epoch=1), 10))


class RecenterNotebookTests(unittest.TestCase):
    def setUp(self):
        self.fixture = notebook_tests.Tests()
        self.fixture.setUp()
        self.addCleanup(self.fixture.doCleanups)
        self.ns, self.robot = self.fixture.namespace()

    def run_cell(self, state_function, solve_wrapper=None):
        now = [0.]
        receiver = self.fixture.receiver(now)
        receiver.snapshot = lambda: state_function(now[0])
        self.ns.update(RUN_HARDWARE=True, PoseReceiver=lambda: receiver)
        if solve_wrapper:self.ns['solve_live'] = solve_wrapper(self.ns['solve_live'])
        with patch.object(time, 'monotonic', lambda: now[0]), \
             patch.object(time, 'sleep', lambda dt: now.__setitem__(0, now[0] + dt)):
            exec(self.fixture.cells()['run'], self.ns)

    def test_recenter_while_running_freezes_without_home_or_reenable(self):
        def states(t):
            if t > .6:raise KeyboardInterrupt()
            a = 0 if t < .02 else 1 if t < .3 else 2
            s = state(a=a, run=bool(a), epoch=int(t >= .15), now=t)
            s['latest'].update(seq=int(t*1000), calibration_id=a, live_value=.2)
            return s
        self.run_cell(states)
        self.assertTrue(self.ns['frozen'])
        self.assertFalse(self.ns['torso_allowed'].is_set())
        for arm in (self.robot.arms_system.left_arm, self.robot.arms_system.right_arm):
            self.assertEqual(sum(n == 'enable' for n, _ in arm.calls), 1)
            self.assertFalse(any(n == 'home_disable' for n, _ in arm.calls))
            self.assertEqual(arm.calls[-1][0], 'freeze')
            first_freeze = next(i for i, c in enumerate(arm.calls) if c[0] == 'freeze')
            self.assertFalse(any(n == 'target' for n, _ in arm.calls[first_freeze:]))

    def test_recenter_during_ik_discards_result_before_sdk_submission(self):
        recentered = [False]
        def states(t):
            if t > .4:raise KeyboardInterrupt()
            a = int(t >= .02)
            s = state(a=a, run=bool(a), epoch=int(recentered[0]), now=t)
            s['latest'].update(seq=int(t*1000), calibration_id=a, live_value=.4)
            return s
        def wrap(solve):
            def run(packet, previous):
                result = solve(packet, previous)
                recentered[0] = True
                return result
            return run
        self.run_cell(states, wrap)
        for arm in (self.robot.arms_system.left_arm, self.robot.arms_system.right_arm):
            commands = [kw['positions'] for n, kw in arm.calls if n == 'target']
            self.assertTrue(commands)
            self.assertTrue(all(q == 0 for positions in commands for q in positions.values()))
            self.assertFalse(any(n == 'home_disable' for n, _ in arm.calls))

    def test_b_then_a_after_recenter_accepts_new_references(self):
        def states(t):
            if t > .9:raise KeyboardInterrupt()
            a,b,run = ((0,0,False) if t<.02 else (1,0,True) if t<.4 else
                       (1,1,False) if t<.6 else (2,1,True))
            epoch = int(t >= .15)
            s=state(a,b,run,epoch,t)
            s['latest'].update(seq=int(t*1000),calibration_id=a,live_value=.2,
                               anchors={'new_origin':epoch})
            return s
        self.run_cell(states)
        self.assertEqual(self.ns['active_recenter_id'], 1)
        self.assertEqual(self.ns['active_anchors'], {'new_origin':1})
        for arm in (self.robot.arms_system.left_arm, self.robot.arms_system.right_arm):
            self.assertEqual(sum(n == 'enable' for n, _ in arm.calls), 2)
            names=[n for n,_ in arm.calls]
            self.assertLess(names.index('freeze'),names.index('home_disable'))

    def test_recenter_or_session_reset_is_not_a_b_command(self):
        self.ns.update(active_key=(42,1),active_b=0,active_recenter_id=0)
        p=state(a=1,run=False,epoch=1,now=time.monotonic())
        self.assertFalse(self.ns['b_requests_home'](p))
        p['latest']['session']=43
        self.assertFalse(self.ns['b_requests_home'](p))
        p['latest']['arm_switch']['b_press']=1
        self.assertTrue(self.ns['b_requests_home'](p))


if __name__ == '__main__':unittest.main(verbosity=2)
