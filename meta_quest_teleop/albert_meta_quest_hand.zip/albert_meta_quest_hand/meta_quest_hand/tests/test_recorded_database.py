"""Offline real-URDF checks. No SDK import, robot initialization, or motor IO."""
import tempfile
import hashlib
import unittest
from pathlib import Path
from unittest.mock import patch
import numpy as np
from quest_television_ik import ArmModel, QuestIK, DATABASE_PATH


class RecordedDatabaseTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.arms = {side: ArmModel(side) for side in ('left', 'right')}

    def test_named_order_and_right_mirror(self):
        with np.load(DATABASE_PATH, allow_pickle=False) as db:
            q, names = db['q'], db['joint_names'].tolist()
        self.assertEqual(q.shape, (619, 7))
        for side, arm in self.arms.items():
            expected = q[:, [names.index(n[:-1]+'L') for n in arm.joint_names]]
            np.testing.assert_array_equal(arm.recorded_q, expected * (1 if side == 'left' else -1))
            # Current URDF has roll before pitch, unlike the recorded database.
            self.assertEqual(arm.joint_names[-2:], ['Wr'+side[0].upper(), 'Wp'+side[0].upper()])

    def test_fk_is_from_current_model_and_home_is_present(self):
        for arm in self.arms.values():
            info = arm.database_info
            self.assertEqual(info['retained']+info['excluded'], 619)
            self.assertGreaterEqual(info['retained'], 5)
            self.assertEqual(len(arm.database.datapoints), info['retained']+1)
            np.testing.assert_array_equal(arm.database.joint_positions[0], np.zeros(7))
            for q, p, R in arm.database.datapoints:
                actual_p, actual_R = arm.fk(q)
                np.testing.assert_allclose(p, actual_p, atol=1e-12)
                np.testing.assert_allclose(R, actual_R, atol=1e-12)
                self.assertTrue(np.all(q >= arm.arm.q_lower) and np.all(q <= arm.arm.q_upper))

    def test_repeated_worker_limits_do_not_rebuild_database(self):
        arm = self.arms['left']
        database = arm.database
        with patch.object(arm, '_build_database', side_effect=AssertionError('Rebuilt per tick')):
            for _ in range(50):
                arm.set_sdk_joint_limits(arm.arm.q_lower, arm.arm.q_upper)
        self.assertIs(database, arm.database)

    def test_changed_limits_refilter_and_adapt_only_wrists(self):
        arm = ArmModel('left')
        old = arm.database
        lo, hi = arm.arm.q_lower.copy(), arm.arm.q_upper.copy()
        hi[0] = 0.9 * hi[0]
        arm.set_sdk_joint_limits(lo, hi)
        self.assertIsNot(old, arm.database)
        wrist = np.array([name.startswith(('Ww', 'Wr', 'Wp')) for name in arm.joint_names])
        keep = np.all(((arm.recorded_q >= lo) & (arm.recorded_q <= hi))[:, ~wrist], axis=1)
        expected = arm.recorded_q[keep].copy()
        expected[:, wrist] = np.clip(expected[:, wrist], lo[wrist], hi[wrist])
        np.testing.assert_array_equal(arm.database.joint_positions[1:], expected)
        self.assertEqual(arm.database_info['retained'], int(keep.sum()))
        # A failed update must preserve the last valid bounds and lookup.
        old = arm.database
        with self.assertRaisesRegex(ValueError, 'need at least 5'):
            arm.set_sdk_joint_limits(np.zeros(7), np.zeros(7))
        self.assertIs(old, arm.database)
        np.testing.assert_array_equal(arm.arm.q_upper, hi)

    def test_missing_or_invalid_data_fails_without_random_fallback(self):
        with tempfile.TemporaryDirectory() as folder:
            file = Path(folder)/'samples.npz'
            with self.assertRaises(FileNotFoundError):
                ArmModel('left', database_path=file)
            with np.load(DATABASE_PATH, allow_pickle=False) as db:
                data = {key: db[key].copy() for key in db.files}
            data['q'][0, 0] = np.nan
            np.savez(file, **data)
            with self.assertRaisesRegex(ValueError, 'finite'):
                ArmModel('left', database_path=file)
            data['q'][0, 0] = 0.
            data['joint_names'] = np.array(['bad']*7)
            np.savez(file, **data)
            with self.assertRaisesRegex(ValueError, 'joint order/schema'):
                ArmModel('left', database_path=file)

    def test_original_source_provenance_and_right_reconstruction(self):
        with np.load(DATABASE_PATH, allow_pickle=False) as db:
            self.assertEqual(int(db['schema_version']), 2)
            self.assertEqual(db['source_counts'].tolist(), [311, 308])
            self.assertEqual(db['source_sides'].tolist(), ['left', 'right'])
            q = db['q'].copy()
            for i, side in enumerate(('left', 'right')):
                selected = db['row_source_side'] == side
                original = q[selected] * (1 if side == 'left' else -1)
                np.testing.assert_array_equal(db['row_source_index'][selected], np.arange([311, 308][i]))
                self.assertEqual(hashlib.sha256(original.tobytes()).hexdigest(), str(db['source_q_sha256s'][i]))
            self.assertEqual(str(db['source_sha256s'][0]), '80d282aa3852c6055384db101cd308f2b1eb0f104a256b0f8d13b94c5083abcc')
            self.assertEqual(str(db['source_sha256s'][1]), '8538a7eeedd812e68ead9f7223e8816e7bd426aec5cd2ff14a8a656afa847537')
        right = self.arms['right']
        index = [['SpL', 'SrL', 'SwL', 'EpL', 'WwL', 'WpL', 'WrL'].index(n[:-1]+'L')
                 for n in right.joint_names]
        np.testing.assert_array_equal(right.recorded_q[311:], -q[311:, index])
        for arm in self.arms.values():
            sources = arm.database_info['sources']
            self.assertEqual([s['recorded'] for s in sources], [311, 308])
            self.assertEqual(arm.database_info['source'], ';'.join(s['path'] for s in sources))
            self.assertEqual(sum(s['retained'] for s in sources), arm.database_info['retained'])
            self.assertEqual(sum(s['excluded'] for s in sources), arm.database_info['excluded'])

    def test_schema_one_recording_remains_supported(self):
        with tempfile.TemporaryDirectory() as folder:
            file = Path(folder)/'original.npz'
            with np.load(DATABASE_PATH, allow_pickle=False) as db:
                np.savez(file, q=db['q'][:311], joint_names=db['joint_names'],
                    schema_version=np.array(1), source_sha256=db['source_sha256'])
            arm = ArmModel('left', database_path=file)
            self.assertEqual(arm.database_info['recorded'], 311)
            self.assertEqual(len(arm.database_info['sources']), 1)
            self.assertEqual(arm.database_info['sources'][0]['side'], 'left')

    def test_corrupt_provenance_is_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            file = Path(folder)/'corrupt.npz'
            with np.load(DATABASE_PATH, allow_pickle=False) as db:
                data = {key: db[key].copy() for key in db.files}
            data['row_source_index'][311] = 1
            np.savez(file, **data)
            with self.assertRaisesRegex(ValueError, 'provenance'):
                ArmModel('right', database_path=file)

    def test_home_and_retained_exact_pose_solutions(self):
        for arm in self.arms.values():
            for q, p, R in arm.database.datapoints:
                candidate = arm.solve(p, R)
                self.assertTrue(candidate['converged'])
                self.assertLess(candidate['position_error_mm'], 3.)
            home = arm.solve(arm.home_p, arm.home_R)
            np.testing.assert_allclose(home['joints_rad'], np.zeros(7), atol=1e-5)

    def test_parallel_worker_uses_same_file_and_results(self):
        mapper = QuestIK()
        mapper.start_parallel()
        try:
            mapper.parallel.wait_ms = 1000  # Numerical parity test, not a timing benchmark.
            jobs = {}
            expected = {}
            for side, arm in mapper.arms.items():
                _, p, R = arm.database.datapoints[10]
                expected[side] = arm.solve(p, R)
                jobs[side] = dict(position=p, rotation=R, previous_q=[0.]*7,
                    limits=(arm.arm.q_lower, arm.arm.q_upper))
            results = mapper.parallel.solve(jobs)
            for side, (actual, error) in results.items():
                self.assertIsNone(error)
                self.assertTrue(actual['converged'])
                np.testing.assert_allclose(actual['joints_rad'], expected[side]['joints_rad'], atol=1e-10)
        finally:
            mapper.close()

    def test_wrist_adaptation_preserves_upper_arm_and_original_recording(self):
        for side, arm in self.arms.items():
            with self.subTest(side=side):
                raw = arm.recorded_q.copy()
                lo, hi = arm.arm.q_lower, arm.arm.q_upper
                wrist = np.array([name.startswith(('Ww', 'Wr', 'Wp')) for name in arm.joint_names])
                allowed = (raw >= lo) & (raw <= hi)
                keep = np.all(allowed[:, ~wrist], axis=1)
                adjusted = arm.database.joint_positions[1:]
                np.testing.assert_array_equal(adjusted[:, ~wrist], raw[keep][:, ~wrist])
                np.testing.assert_array_equal(adjusted[:, wrist],
                    np.clip(raw[keep][:, wrist], lo[wrist], hi[wrist]))
                unchanged = np.all(allowed[keep], axis=1)
                np.testing.assert_array_equal(adjusted[unchanged], raw[keep][unchanged])
                self.assertGreater(arm.database_info['wrist_adjusted'], 0)
                self.assertEqual(arm.database_info['wrist_adjusted'], int((~unchanged).sum()))
                self.assertEqual(arm.database_info['original_valid'], int(unchanged.sum()))
                np.testing.assert_array_equal(arm.recorded_q, raw)
                # The adjusted wrist orientations must not keep their old FK labels.
                differences = []
                for old_q, new_q in zip(raw[keep][~unchanged], adjusted[~unchanged]):
                    p0, R0 = arm.fk(old_q)
                    p1, R1 = arm.fk(new_q)
                    differences.append(np.linalg.norm(p0-p1)+np.linalg.norm(R0-R1))
                self.assertGreater(max(differences), 1e-3)

    def test_shoulder_and_elbow_violations_are_excluded_even_with_bad_wrists(self):
        for side in ('left', 'right'):
            arm = ArmModel(side)
            lo, hi = arm.arm.q_lower, arm.arm.q_upper
            suffix = side[0].upper()
            shoulder = arm.joint_names.index('Sp'+suffix)
            elbow = arm.joint_names.index('Ep'+suffix)
            wrist = arm.joint_names.index('Wp'+suffix)
            valid = np.zeros((5, 7))
            valid[:, shoulder] = np.linspace(0, 0.1 if hi[shoulder] >= 0.1 else -0.1, 5)
            valid[0, wrist] = hi[wrist]+0.2
            bad = np.zeros((2, 7))
            bad[0, shoulder] = lo[shoulder]-0.1
            bad[1, elbow] = hi[elbow]+0.1
            bad[:, wrist] = hi[wrist]+0.2
            arm.recorded_q = np.vstack([valid, bad])
            arm.recorded_source_sides = np.full(len(arm.recorded_q), 'left')
            arm.recorded_source_indices = np.arange(len(arm.recorded_q))
            arm.database_sources = [dict(side='left', recorded=len(arm.recorded_q),
                path='synthetic_test_fixture', sha256='synthetic_test_fixture')]
            db, info = arm._build_database(lo, hi)
            self.assertEqual(info['retained'], 5)
            self.assertEqual(info['excluded'], 2)
            self.assertEqual(info['wrist_adjusted'], 1)
            expected = valid.copy()
            expected[0, wrist] = hi[wrist]
            np.testing.assert_array_equal(db.joint_positions[1:], expected)


if __name__ == '__main__':
    unittest.main()
