"""Offline bridge tests: no live camera, thread, process or pyzed import."""
import importlib.util
from io import BytesIO
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import Mock, patch

import numpy as np
from PIL import Image

import quest_video as video


CAPTURE_PATH = Path(__file__).resolve().parents[5] / "TeleVision/teleop/quest_zed.py"


def load_bridge():
    spec = importlib.util.spec_from_file_location("_offline_quest_zed_bridge", CAPTURE_PATH)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


bridge = load_bridge()


def publish_fake(path, *, sequence=7, timestamp=10., left=None, right=None,
                 calibration=(262., 263., 320., 180., 0., .12, 0.), stereo=True, omit=()):
    if left is None:
        left = np.zeros((360, 640, 3), np.uint8)
        left[..., 0] = np.arange(640, dtype=np.uint16) % 256
        left[..., 1] = 50
    if right is None:
        right = np.zeros((360, 640, 3), np.uint8)
        right[..., 2] = np.arange(360, dtype=np.uint16)[:, None] % 256
        right[..., 1] = 100
    fields = dict(sequence=np.asarray(sequence), timestamp=np.asarray(timestamp), left=left, right=right,
                  calibration=np.asarray(calibration), stereo=np.asarray(stereo))
    temporary = path.with_suffix('.tmp')
    with temporary.open('wb') as stream:
        np.savez(stream, **{key: value for key, value in fields.items() if key not in omit})
    os.replace(temporary, path)
    return left, right


class CaptureBridgeTests(unittest.TestCase):
    def test_import_and_constructor_never_start_capture_or_import_pyzed(self):
        before = {name for name in sys.modules if name.startswith(('pyzed', 'feathersdk'))}
        with patch('subprocess.Popen') as popen, patch('subprocess.run') as run, patch('threading.Thread.start') as thread:
            loaded = load_bridge()
            camera = loaded.StereoCamera(model='zed-2i', serial=35928961, fps=30)
            self.assertTrue(camera.native_stereo)
            self.assertFalse(camera.status()['healthy'])
            self.assertEqual(camera.status()['source'], 'zed-2i')
            popen.assert_not_called()
            run.assert_not_called()
            thread.assert_not_called()
        self.assertEqual({name for name in sys.modules if name.startswith(('pyzed', 'feathersdk'))}, before)
        self.assertFalse(hasattr(camera, 'set_eye_distance'))
        self.assertFalse(hasattr(camera, 'metric_stereo'))

    def test_original_eye_pixels_independent_quality75_jpegs_and_atomic_metadata(self):
        camera = bridge.StereoCamera()
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'frame.npz'
            left, right = publish_fake(path)
            self.assertEqual(camera._read_frame(path, 0), 7)
            jpeg, calibration, stereo = camera.latest_calibrated_jpeg()
            self.assertEqual(jpeg[:2], (7, 10.))
            self.assertEqual(jpeg[-2:], (640, 360))
            self.assertEqual(calibration, (262., 263., 320., 180., 0., .12, 0.))
            self.assertTrue(stereo)
            self.assertNotEqual(jpeg[2], jpeg[3])
            for pixels, encoded in zip((left, right), jpeg[2:4]):
                expected = BytesIO()
                Image.fromarray(pixels).save(expected, format='JPEG', quality=75)
                self.assertEqual(encoded, expected.getvalue())
            np.testing.assert_array_equal(camera.latest()[2], left)
            np.testing.assert_array_equal(camera.latest()[3], right)
            self.assertFalse(camera.latest()[2].flags.writeable)
            publish_fake(path, sequence=8, timestamp=10.2, calibration=(300., 301., 310., 170., 0., .119, 0.))
            self.assertEqual(camera._read_frame(path, 7), 8)
            newest, newest_calibration, stereo = camera.latest_calibrated_jpeg()
            self.assertEqual(newest[:2], (8, 10.2))
            self.assertEqual(newest_calibration[:4], (300., 301., 310., 170.))
            self.assertTrue(stereo)
            self.assertEqual(jpeg[:2], (7, 10.))
            self.assertEqual(calibration[:4], (262., 263., 320., 180.))

    def test_duplicates_and_older_snapshots_cannot_replace_latest_pair(self):
        camera = bridge.StereoCamera()
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'frame.npz'
            publish_fake(path)
            camera._read_frame(path, 0)
            original = camera.latest_calibrated_jpeg()
            for sequence in (7, 6):
                publish_fake(path, sequence=sequence, timestamp=20.)
                self.assertEqual(camera._read_frame(path, 7), 7)
                self.assertEqual(camera.latest_calibrated_jpeg(), original)

    def test_invalid_or_missing_native_metadata_never_publishes_mono(self):
        faults = ({'stereo': False}, {'stereo': 1}, {'omit': ('calibration',)},
                  {'omit': ('stereo',)}, {'calibration': (0., 262., 320., 180., 0., .12, 0.)},
                  {'calibration': (262., 262., 320., 180., 0., 0., 0.)},
                  {'calibration': (262., 262., 320., 180., 0., .12, float('nan'))},
                  {'timestamp': float('nan')}, {'sequence': 7.5},
                  {'right': np.zeros((180, 320, 3), np.uint8)},
                  {'left': np.zeros((360, 640, 3), np.float32)})
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'frame.npz'
            for fault in faults:
                with self.subTest(fault=tuple(fault)):
                    camera = bridge.StereoCamera()
                    publish_fake(path, **fault)
                    with self.assertRaises(ValueError):
                        camera._read_frame(path, 0)
                    self.assertEqual(camera.latest_calibrated_jpeg(), (None, None, False))
                    self.assertFalse(camera.healthy())

    def test_fresh_stale_future_and_exited_producer_status(self):
        camera = bridge.StereoCamera()
        camera.proc = Mock()
        camera.proc.poll.return_value = None
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'frame.npz'
            publish_fake(path)
            camera._read_frame(path, 0)
        for now, expected in ((10.1, True), (10.5, False), (9.9, False), (float('nan'), False)):
            with self.subTest(now=now), patch.object(bridge.time, 'monotonic', return_value=now):
                self.assertEqual(camera.healthy(), expected)
        with patch.object(bridge.time, 'monotonic', return_value=10.1):
            camera.proc.poll.return_value = 2
            self.assertFalse(camera.healthy())
            camera.proc.poll.return_value = None
            camera.error = 'Invalid native stereo calibration'
            self.assertFalse(camera.healthy())
            self.assertEqual(camera.status()['error'], camera.error)

    def test_native_video_protocol_transmits_both_original_jpegs(self):
        camera = bridge.StereoCamera()
        camera.proc = Mock()
        camera.proc.poll.return_value = None
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'frame.npz'
            publish_fake(path)
            camera._read_frame(path, 0)
        with patch.object(video.time, 'monotonic', return_value=10.1):
            packet = video.video_packet(camera, 0, native=True)
        header = video.HEADER.unpack(packet[:video.HEADER.size])
        self.assertEqual(header[:5], (b'QVID', 3, 0, 52, 7))
        self.assertEqual(packet[header[3]:], camera.latest_jpeg()[2] + camera.latest_jpeg()[3])
        self.assertEqual(header[-2:], tuple(len(image) for image in camera.latest_jpeg()[2:4]))

    def test_start_forwards_camera_options_without_depth_or_ipd_flags(self):
        camera = bridge.StereoCamera('camera-python', synthetic=True, model='zed-2i', serial=35928961, fps=30)
        process, thread = Mock(), Mock()
        process.poll.return_value = None
        ordinary_temporary_directory = tempfile.TemporaryDirectory
        with ordinary_temporary_directory() as directory:
            worker = Path(directory) / 'quest_zed_worker.py'
            worker.write_text('')

            def capture_directory_in_test_root(**options):
                # The offline audit blocks /dev paths. Keep production's shared
                # memory preference while making this fixture use ordinary disk.
                return ordinary_temporary_directory(**dict(options, dir=directory))

            with patch.object(bridge, 'WORKER', worker), patch.object(bridge.subprocess, 'Popen', return_value=process) as start, patch.object(bridge.threading, 'Thread', return_value=thread), patch.object(bridge.tempfile, 'TemporaryDirectory', side_effect=capture_directory_in_test_root):
                try:
                    self.assertIs(camera.start(), camera)
                    self.assertIs(camera.start(), camera)
                    self.assertTrue(Path(camera.directory.name).is_relative_to(Path(directory)))
                    start.assert_called_once()
                    args = start.call_args.args[0]
                    self.assertEqual(args[0], 'camera-python')
                    for flag, value in (('--model', 'zed-2i'), ('--serial', '35928961'), ('--fps', '30')):
                        self.assertEqual(args[args.index(flag) + 1], value)
                    self.assertIn('--test-pattern', args)
                    self.assertNotIn('--metric-stereo', args)
                    self.assertEqual(start.call_args.kwargs['env']['PYTHONNOUSERSITE'], '1')
                    thread.start.assert_called_once()
                finally:
                    capture_directory = Path(camera.directory.name)
                    camera.close()
                self.assertFalse(capture_directory.exists())
                process.terminate.assert_called_once()

    def test_probe_filters_model_and_serial_and_requires_successful_unique_device(self):
        inventory = {'devices': [{'model_key': 'zed-2i', 'serial': 1}, {'model_key': 'zed-2i', 'serial': 2},
                                 {'model_key': 'zed-x', 'serial': 3}, {'model_key': 'zed-2i', 'serial': 0}]}
        result = Mock(stdout='ZED diagnostics\n' + json.dumps(inventory), stderr='', returncode=0)
        with patch.object(bridge.subprocess, 'run', return_value=result) as run:
            self.assertFalse(bridge.probe_camera('camera-python', model='zed-2i')['ready'])
            self.assertTrue(bridge.probe_camera('camera-python', serial=2, model='zed-2i')['ready'])
            self.assertFalse(bridge.probe_camera('camera-python', serial=3, model='zed-2i')['ready'])
            args = run.call_args.args[0]
            self.assertEqual(args[-2:], ['--model', 'zed-2i'])
            result.returncode = 2
            self.assertFalse(bridge.probe_camera('camera-python', serial=2, model='zed-2i')['ready'])


if __name__ == '__main__':
    unittest.main()
