"""Exercise ZED capture with an in-memory pyzed double; never open a camera."""
import builtins
from contextlib import ExitStack, redirect_stdout
import importlib.util
import io
import json
from pathlib import Path
import signal
import sys
import tempfile
from types import ModuleType, SimpleNamespace
import unittest
from unittest import mock

import numpy as np


WORKER = Path(__file__).resolve().parents[5] / 'TeleVision' / 'teleop' / 'quest_zed_worker.py'


def load_worker():
    spec = importlib.util.spec_from_file_location('capture_worker_under_test', WORKER)
    worker = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(worker)
    return worker


class FakeClock:
    def __init__(self):
        self.now = 100.
        self.sleeps = []
        self.signals = {}

    def monotonic(self):
        return self.now

    def sleep(self, duration):
        self.sleeps.append(duration)
        self.now += duration
        self.signals[signal.SIGTERM]()

    def register_signal(self, number, handler):
        self.signals[number] = handler


class FakeZed:
    def __init__(self, clock, width=16, height=18):
        self.clock = clock
        self.instances = []
        self.devices = [SimpleNamespace(camera_model='MODEL.ZED_2I', serial_number=101),
                        SimpleNamespace(camera_model='MODEL.ZED_X', serial_number=202)]
        self.left = np.arange(height * width * 4, dtype=np.uint8).reshape(height, width, 4)
        self.right = np.bitwise_xor(self.left, np.uint8(173))
        self.calibration = [400., 410., 8., 9., .12]
        self.open_result = 'SUCCESS'
        self.grab_result = 'SUCCESS'
        self.retrieve_result = 'SUCCESS'
        owner = self

        class Camera:
            @staticmethod
            def get_device_list():
                return owner.devices

            @staticmethod
            def get_sdk_version():
                return '4.2.fake'

            def __init__(self):
                owner.instances.append(self)
                self.closed = False
                self.retrieved = []
                self.grabs = 0
                self.info_sizes = []

            def open(self, params):
                self.params = params
                return owner.open_result

            def get_camera_information(self, resolution):
                self.info_sizes.append((resolution.width, resolution.height))
                fx, fy, cx, cy, baseline = owner.calibration
                units = self.params.coordinate_units
                cal = SimpleNamespace(left_cam=SimpleNamespace(fx=fx, fy=fy, cx=cx, cy=cy),
                                      right_cam=SimpleNamespace(fx=999., fy=999., cx=1., cy=2.),
                                      get_camera_baseline=lambda: baseline if units == 'METER' else baseline * 1000.)
                return SimpleNamespace(camera_configuration=SimpleNamespace(calibration_parameters=cal))

            def grab(self, runtime):
                if runtime.enable_depth or runtime.enable_fill_mode:
                    raise AssertionError('Depth processing must be disabled')
                self.grabs += 1
                owner.clock.now += .04
                return owner.grab_result

            def retrieve_image(self, mat, view, memory, resolution):
                if memory != 'CPU':
                    raise AssertionError('Expected CPU image retrieval')
                if (resolution.width, resolution.height) != (owner.left.shape[1], owner.left.shape[0]):
                    raise AssertionError('Capture and calibration dimensions differ')
                self.retrieved.append(view)
                mat.data = owner.left if view == 'LEFT' else owner.right
                owner.clock.now += .01
                return owner.retrieve_result

            def retrieve_measure(self, *args, **kwargs):
                raise AssertionError('Depth retrieval is forbidden')

            def close(self):
                self.closed = True

        class InitParameters:
            def __init__(self):
                self.coordinate_units = 'MILLIMETER'

            def set_from_serial_number(self, serial):
                self.serial = serial

        class Mat:
            def get_data(self):
                return self.data

        self.sl = ModuleType('pyzed.sl')
        self.sl.Camera = Camera
        self.sl.InitParameters = InitParameters
        self.sl.RuntimeParameters = lambda: SimpleNamespace(enable_depth=True, enable_fill_mode=True)
        self.sl.Mat = Mat
        self.sl.Resolution = lambda width, height: SimpleNamespace(width=width, height=height)
        self.sl.RESOLUTION = SimpleNamespace(HD720='HD720', AUTO='AUTO')
        self.sl.DEPTH_MODE = SimpleNamespace(NONE='NONE')
        self.sl.UNIT = SimpleNamespace(METER='METER')
        self.sl.ERROR_CODE = SimpleNamespace(SUCCESS='SUCCESS')
        self.sl.VIEW = SimpleNamespace(LEFT='LEFT', RIGHT='RIGHT')
        self.sl.MEM = SimpleNamespace(CPU='CPU')
        self.package = ModuleType('pyzed')
        self.package.sl = self.sl


class CaptureWorkerTests(unittest.TestCase):
    def setUp(self):
        self.worker = load_worker()
        self.clock = FakeClock()
        self.fake = FakeZed(self.clock)
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.directory = Path(self.temp.name)

    def run_main(self, extra=(), *, parent=77):
        output = io.StringIO()
        arguments = ['--output-dir', str(self.directory), '--model', 'zed-2i',
                     '--width', '16', '--height', '18', '--parent-pid', '77', *extra]
        with ExitStack() as stack:
            stack.enter_context(mock.patch.dict(sys.modules, {'pyzed': self.fake.package, 'pyzed.sl': self.fake.sl}))
            stack.enter_context(mock.patch.object(self.worker.signal, 'signal', self.clock.register_signal))
            stack.enter_context(mock.patch.object(self.worker.time, 'monotonic', self.clock.monotonic))
            stack.enter_context(mock.patch.object(self.worker.time, 'sleep', self.clock.sleep))
            stack.enter_context(mock.patch.object(self.worker.os, 'getppid', return_value=parent))
            stack.enter_context(redirect_stdout(output))
            result = self.worker.main(arguments)
        return result, output.getvalue()

    def read_frame(self):
        with np.load(self.directory / 'frame.npz', allow_pickle=False) as frame:
            return {key: frame[key].copy() for key in frame.files}

    def test_import_does_not_import_camera_or_construct_it(self):
        original = builtins.__import__

        def guarded(name, *args, **kwargs):
            if name.split('.')[0] in {'pyzed', 'feathersdk', 'can', 'serial'}:
                raise AssertionError('Hardware import on capture module import: ' + name)
            return original(name, *args, **kwargs)

        with mock.patch('builtins.__import__', guarded):
            worker = load_worker()
        self.assertTrue(callable(worker.main))
        self.assertEqual(self.fake.instances, [])

    def test_native_pair_and_matching_calibration_are_published_without_depth(self):
        result, output = self.run_main()
        self.assertEqual(result, 0)
        camera, = self.fake.instances
        self.assertTrue(camera.closed)
        self.assertEqual(camera.params.serial, 101)
        self.assertEqual(camera.params.camera_resolution, 'HD720')
        self.assertEqual(camera.params.camera_fps, 30)
        self.assertEqual(camera.params.depth_mode, 'NONE')
        self.assertEqual(camera.params.coordinate_units, 'METER')
        self.assertFalse(camera.params.enable_right_side_measure)
        self.assertEqual(camera.info_sizes, [(16, 18)])
        self.assertEqual(camera.retrieved, ['LEFT', 'RIGHT'])
        self.assertEqual(camera.grabs, 1)
        frame = self.read_frame()
        self.assertTrue(np.array_equal(frame['left'], self.fake.left[:, :, [2, 1, 0]]))
        self.assertTrue(np.array_equal(frame['right'], self.fake.right[:, :, [2, 1, 0]]))
        self.assertFalse(np.array_equal(frame['left'], frame['right']))
        self.assertEqual(frame['left'].dtype, np.uint8)
        self.assertTrue(np.allclose(frame['calibration'], [400., 410., 8., 9., 0., .12, 0.], rtol=1e-6))
        self.assertEqual(frame['calibration'].dtype, np.float32)
        self.assertTrue(frame['stereo'].item())
        self.assertEqual(frame['stereo'].dtype, np.bool_)
        self.assertEqual(frame['sequence'].item(), 1)
        self.assertAlmostEqual(frame['timestamp'].item(), 100.04)
        self.assertAlmostEqual(self.clock.sleeps[0], 1 / 15 - .06)
        self.assertFalse((self.directory / 'frame.tmp').exists())
        self.assertEqual(json.loads(output)['camera']['serial'], 101)
        self.assertEqual(json.loads(output)['sdk'], '4.2.fake')

    def test_zed_x_selection_uses_auto_resolution_and_requested_publish_rate(self):
        self.run_main(['--model', 'zed-x', '--serial', '202', '--fps', '10'])
        camera, = self.fake.instances
        self.assertEqual(camera.params.serial, 202)
        self.assertEqual(camera.params.camera_resolution, 'AUTO')
        self.assertEqual(camera.params.camera_fps, 30)
        self.assertAlmostEqual(self.clock.sleeps[0], .1 - .06)

    def test_serial_disambiguates_two_matching_cameras(self):
        self.fake.devices.append(SimpleNamespace(camera_model='MODEL.ZED_2I', serial_number=303))
        self.run_main(['--serial', '303'])
        self.assertEqual(self.fake.instances[0].params.serial, 303)

    def test_missing_or_ambiguous_selection_never_constructs_camera(self):
        for devices in ([], [self.fake.devices[0], self.fake.devices[0]]):
            with self.subTest(devices=devices):
                self.fake.devices = devices
                with self.assertRaisesRegex(RuntimeError, 'Expected one'):
                    self.run_main()
                self.assertEqual(self.fake.instances, [])
                self.assertFalse((self.directory / 'frame.npz').exists())

    def test_bad_calibration_fails_before_grab_and_closes_camera(self):
        for calibration in ([400., 410., 8., 9., 120.], [float('nan'), 410., 8., 9., .12],
                            [400., 0., 8., 9., .12]):
            with self.subTest(calibration=calibration):
                self.fake.calibration = calibration
                with self.assertRaisesRegex(RuntimeError, 'Invalid ZED stereo calibration'):
                    self.run_main()
                self.assertTrue(self.fake.instances[-1].closed)
                self.assertEqual(self.fake.instances[-1].grabs, 0)
                self.assertFalse((self.directory / 'frame.npz').exists())

    def test_capture_failures_close_camera_without_publishing(self):
        for failure, message in (('open_result', 'open failed'), ('grab_result', 'grab failed'),
                                 ('retrieve_result', 'retrieve failed')):
            with self.subTest(failure=failure):
                self.fake.open_result = self.fake.grab_result = self.fake.retrieve_result = 'SUCCESS'
                setattr(self.fake, failure, 'FAILURE')
                with self.assertRaisesRegex(RuntimeError, message):
                    self.run_main()
                self.assertTrue(self.fake.instances[-1].closed)
                self.assertFalse((self.directory / 'frame.npz').exists())

    def test_parent_exit_stops_before_capture_and_closes_camera(self):
        self.run_main(parent=78)
        self.assertTrue(self.fake.instances[0].closed)
        self.assertEqual(self.fake.instances[0].grabs, 0)
        self.assertFalse((self.directory / 'frame.npz').exists())

    def test_synthetic_pair_does_not_import_camera_and_publishes_stereo_metadata(self):
        original = builtins.__import__

        def guarded(name, *args, **kwargs):
            if name.split('.')[0] in {'pyzed', 'feathersdk', 'can', 'serial', 'quest_stereo'}:
                raise AssertionError('Synthetic capture imported hardware/reprojection: ' + name)
            return original(name, *args, **kwargs)

        with mock.patch('builtins.__import__', guarded):
            self.run_main(['--test-pattern'])
        self.assertEqual(self.fake.instances, [])
        frame = self.read_frame()
        self.assertFalse(np.array_equal(frame['left'], frame['right']))
        self.assertTrue(np.array_equal(frame['right'], frame['left'][:, :, [2, 1, 0]]))
        self.assertTrue(frame['stereo'].item())
        self.assertTrue(np.allclose(frame['calibration'], [16., 16., 8., 9., 0., .12, 0.], rtol=1e-6))


if __name__ == '__main__':
    unittest.main()
