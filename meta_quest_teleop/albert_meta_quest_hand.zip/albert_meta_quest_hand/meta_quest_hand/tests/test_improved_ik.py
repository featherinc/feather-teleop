"""Offline checks for original TeleVision IK; no robot, URDF, or Quest needed."""
import sys
import types
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

try:
    import scipy.spatial  # noqa: F401
except ImportError:
    scipy = types.ModuleType('scipy')
    spatial = types.ModuleType('scipy.spatial')
    transform = types.ModuleType('scipy.spatial.transform')
    spatial.KDTree = object
    transform.Rotation = object
    scipy.spatial = spatial
    spatial.transform = transform
    sys.modules.update({'scipy': scipy, 'scipy.spatial': spatial,
                        'scipy.spatial.transform': transform})

try:
    import pinocchio  # noqa: F401
except ImportError:
    sys.modules['pinocchio'] = types.ModuleType('pinocchio')

import television_ik_core as core
from quest_television_ik import ArmModel, QuestIK, comparison_rows, CANDIDATE_FIELDS


class FakeDB:
    def __init__(self, seed):
        self.seed = np.array(seed, dtype=float)
        self.calls = 0

    def weighted_joint_seed(self, *_args, **_kwargs):
        self.calls += 1
        return self.seed.copy()


class FakePin:
    LOCAL_WORLD_ALIGNED = 1

    def __init__(self):
        self.jacobian_calls = 0

    def forwardKinematics(self, _model, data, q):
        data.oMf[0].translation = np.array([q[0], 0., 0.])

    def updateFramePlacements(self, *_args):
        pass

    def computeJointJacobians(self, *_args):
        self.jacobian_calls += 1

    def getFrameJacobian(self, *_args):
        J = np.zeros((6, 7))
        J[0, 0] = 1.
        return J

    def log3(self, _rotation):
        return np.zeros(3)

    def integrate(self, _model, q, dq):
        return q + dq


def fake_arm():
    frame = types.SimpleNamespace(translation=np.zeros(3), rotation=np.eye(3))
    return types.SimpleNamespace(model=object(), data=types.SimpleNamespace(oMf=[frame]),
        neutral_q=np.zeros(7), arm_q_ids=np.arange(7), arm_v_ids=np.arange(7),
        ee_frame_id=0, dq=np.zeros(7), q_lower=np.full(7, -1.),
        q_upper=np.full(7, 1.))


class ImprovedIKTests(unittest.TestCase):
    def test_parallel_mapper_keeps_offsets_and_uses_commanded_seed(self):
        import quest_television_ik as module
        mapper = QuestIK.__new__(QuestIK)
        mapper.key, mapper.blocked_key, mapper.scale = ('session', 1), None, 1.5
        mapper.axis_map = np.array([[0., -1., 0.], [1., 0., 0.], [0., 0., 1.]])
        mapper.anchors = {side: (np.array([1., 2., 3.]), np.eye(3)) for side in ('left', 'right')}
        mapper.arms = {side: types.SimpleNamespace(home_p=np.array([.2, .3, .4]), home_R=np.eye(3),
            arm=fake_arm(), ik_time_budget_ms=12.) for side in ('left', 'right')}
        mapper.accepted = {side: dict(joints_rad=[.1] * 7, wrist=[0.] * 7) for side in mapper.arms}
        received = []
        def solve(jobs):
            received.append(jobs)
            return {'left': (dict(converged=True, joints_rad=[.2] * 7, wrist=[.3] * 7), None),
                    'right': (None, 'ik_worker_timeout')}
        mapper.parallel = types.SimpleNamespace(solve=solve)
        mapper._output = lambda side, original=None, target=None, candidate=None, reason='tracking_lost': dict(
            holding=reason != 'following', reason=reason, joints_rad=mapper.accepted[side]['joints_rad'][:])
        pose = dict(position_m=[1.1, 2.2, 3.3], rotation=mapper.axis_map,
                    position_valid=True, rotation_valid=True)
        packet = dict(session='session', calibration_id=1, poses={side: pose for side in mapper.arms})
        with patch.object(module, 'pose_arrays', lambda p: (np.array(p['position_m']), p['rotation'])), \
             patch.object(module, 'pose_values', lambda p, r: p.tolist() + [0., 0., 0., 1.]):
            result = mapper.process(packet)
            self.assertEqual(set(received[0]), {'left', 'right'})
            np.testing.assert_allclose(received[0]['left']['position'], [-.1, .45, .85])
            np.testing.assert_allclose(received[0]['left']['rotation'], mapper.axis_map)
            self.assertEqual(received[0]['left']['previous_q'], [.1] * 7)
            self.assertEqual(result['left']['joints_rad'], [.2] * 7)
            self.assertEqual(result['right']['joints_rad'], [.1] * 7)
            self.assertTrue(result['right']['holding'])
            # The real controller can limit a candidate before commanding it.
            mapper.accepted['left']['joints_rad'] = [.15] * 7
            mapper.process(packet)
            self.assertEqual(received[1]['left']['previous_q'], [.15] * 7)

    def test_original_always_queries_database_even_at_home(self):
        pin = FakePin()
        db = FakeDB(np.zeros(7))
        with patch.object(core, 'pin', pin):
            for _ in range(2):
                q, norm, mm, iteration = core.TeleVisionIK()._compute_single_arm_ik(
                    fake_arm(), db, np.zeros(3), np.eye(3))
                np.testing.assert_allclose(q, 0.)
                self.assertEqual(iteration, 0)
                self.assertEqual(norm, 0.)
        self.assertEqual(db.calls, 2)
        self.assertEqual(pin.jacobian_calls, 2)

    def test_original_uses_full_sixty_iterations_and_clips_limits(self):
        pin = FakePin()
        db = FakeDB(np.zeros(7))
        with patch.object(core, 'pin', pin):
            q, norm, mm, iteration = core.TeleVisionIK()._compute_single_arm_ik(
                fake_arm(), db, np.array([2., 0., 0.]), np.eye(3))
        self.assertEqual(iteration, 59)
        self.assertEqual(pin.jacobian_calls, 60)
        self.assertEqual(db.calls, 1)
        self.assertEqual(q[0], 1.)
        self.assertGreater(mm, 3.)

    def test_adapter_ignores_previous_seed_and_rechecks_final_fk(self):
        pin = FakePin()
        arm = ArmModel.__new__(ArmModel)
        arm.arm = fake_arm()
        arm.solver = core.TeleVisionIK()
        arm.database = FakeDB(np.zeros(7))
        arm.joint_names = [f'joint_{i}' for i in range(7)]
        arm.fk = lambda q: (np.array([q[0], 0., 0.]), np.eye(3))
        import quest_television_ik as module
        with patch.object(core, 'pin', pin), patch.object(module, 'pin', pin), \
             patch.object(module, 'pose_values', lambda p, r: p.tolist() + [0., 0., 0., 1.]):
            result = arm.solve(np.zeros(3), np.eye(3), previous_q=np.ones(7))
        self.assertTrue(result['converged'])
        self.assertEqual(result['joints_rad'], [0.] * 7)
        self.assertEqual(result['seed_source'], 'database')
        self.assertFalse(result['warm_start_used'])
        self.assertFalse(result['database_fallback_used'])
        self.assertEqual(arm.database.calls, 1)

    def test_sdk_limits_intersect_urdf_and_reject_empty(self):
        arm = ArmModel.__new__(ArmModel)
        arm.model = types.SimpleNamespace(lowerPositionLimit=np.full(7, -1.),
                                          upperPositionLimit=np.full(7, 1.))
        arm.arm = types.SimpleNamespace(q_lower=None, q_upper=None)
        lower, upper = arm.set_sdk_joint_limits(np.full(7, -0.5), np.full(7, 2.))
        np.testing.assert_allclose(lower, -0.5)
        np.testing.assert_allclose(upper, 1.)
        with self.assertRaises(ValueError):
            arm.set_sdk_joint_limits(np.full(7, 2.), np.full(7, 3.))

    def test_held_output_keeps_candidate_diagnostics_in_csv(self):
        mapper = QuestIK.__new__(QuestIK)
        mapper.accepted = {'left': {'joints_rad': [0.] * 7,
                                    'wrist': [0., 0., 0., 0., 0., 0., 1.]}}
        candidate = dict(converged=False, solve_ms=2.5, iterations=8,
            position_error_mm=12., rotation_error_deg=4.,
            failure_reason='iteration_limit', seed_source='database',
            warm_start_used=True)
        result = mapper._output('left', candidate=candidate, reason='ik_failed')
        self.assertTrue(result['holding'])
        self.assertEqual(result['candidate_position_error_mm'], 12.)
        self.assertEqual(result['failure_reason'], 'iteration_limit')
        self.assertTrue(set(CANDIDATE_FIELDS).issubset(result))
        packet = dict(seq=1, calibration_id=1, poses={side: dict(
            position_m=[0., 0., 0.], quaternion_xyzw=[0., 0., 0., 1.],
            position_valid=True, rotation_valid=True) for side in ('left', 'right')})
        rows = comparison_rows(packet, {'left': result, 'right': result}, 0., '')
        self.assertEqual(rows[0]['candidate_position_error_mm'], 12.)
        self.assertEqual(rows[0]['iterations'], 8)


if __name__ == '__main__':
    unittest.main()
