"""Config-only branch integration tests; no robot or transport is constructed.

The metaclass checks run everywhere. To test installed native branch models,
set QUEST_TEST_NATIVE_SDK=1 and put REPO/feathersdk/src first on PYTHONPATH.
"""

import ast
import copy
import inspect
import json
import math
import os
from pathlib import Path
from types import SimpleNamespace
from typing import TypeVar
import tempfile
import unittest
from unittest.mock import patch
from xml.etree import ElementTree

import quest_sdk_config
from quest_trajectory_replay import load_replay_config


PROJECT = Path(__file__).resolve().parents[1]
REPO = Path(__file__).resolve().parents[5]
CONFIG = PROJECT.parent / 'configs/robot_conf.py'
URDF = (PROJECT.parent / 'URDF_C_Arm_03_description-20260625T192804Z-3-001'
        / 'URDF_C_Arm_03_description/urdf/URDF_C_Arm_03.urdf')


def native_allocator(config_class):
    """Use the actual Configurable.__new__ contract without invoking __init__."""
    source = REPO / 'feathersdk/src/feathersdk/configs/configurable.py'
    tree = ast.parse(source.read_text())
    cls = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == 'Configurable')
    method = copy.deepcopy(next(node for node in cls.body if isinstance(node, ast.FunctionDef)
                               and node.name == '__new__'))
    method.returns = None
    for arg in method.args.args + method.args.kwonlyargs:
        arg.annotation = None
    method.args.vararg.annotation = None
    method.args.kwarg.annotation = None

    class Configurable:
        pass

    class RobstrideMotor(Configurable):
        # Any constructor call would be an error; the extracted allocator is
        # intentionally exercised on its own with no actuator/system setup.
        def __init__(self, *args, **kwargs):
            raise AssertionError('Hardware initialization must never run')

    namespace = dict(_CONFIGURABLE_CLASS_TO_CONFIG={'RobstrideMotor': config_class},
                     TypeVar=TypeVar, isclass=inspect.isclass, PyDBaseModel=object,
                     Configurable=Configurable)
    code = ast.fix_missing_locations(ast.Module(body=[method], type_ignores=[]))
    exec(compile(code, str(source), 'exec'), namespace)
    return lambda config: namespace['__new__'](RobstrideMotor, config)


class NativeConstructorContractTests(unittest.TestCase):
    def test_actual_branch_allocator_accepts_exact_class_without_initialization(self):
        class MotorConfig:
            pass
        config = MotorConfig()
        allocated = native_allocator(MotorConfig)(config)
        self.assertIs(allocated.config, config)

    def test_actual_branch_allocator_rejects_config_subclass(self):
        class MotorConfig:
            pass
        class TunedSubclass(MotorConfig):
            pass
        with self.assertRaisesRegex(TypeError, 'not expected class'):
            native_allocator(MotorConfig)(TunedSubclass())


class ReplayConfigLoaderTests(unittest.TestCase):
    def test_default_and_explicit_native_delegate_all_selection_options(self):
        for options in ({}, {'sdk_generation': 'native'}):
            with self.subTest(options=options), patch.object(quest_sdk_config, 'load_branch_config') as loader:
                result = load_replay_config('config.py', 'robot.urdf', include_torso=True,
                            include_navigation=False, include_neck=True, hand_sides=('right',), **options)
                self.assertIs(result, loader.return_value)
                loader.assert_called_once_with('config.py', 'robot.urdf', include_torso=True,
                            include_navigation=False, include_neck=True, hand_sides=('right',))

    def test_unknown_generation_fails_before_loading_sdk_or_config(self):
        with patch.object(quest_sdk_config, 'load_branch_config') as loader:
            with self.assertRaisesRegex(ValueError, 'sdk_generation'):
                load_replay_config('missing.py', 'missing.urdf', sdk_generation='automatic')
            loader.assert_not_called()

    def test_explicit_comms_override_is_forwarded_by_public_native_loader(self):
        with patch.object(quest_sdk_config, 'load_branch_config') as loader:
            result = load_replay_config('config.py', 'robot.urdf', comms_config_path='transport.py')
            self.assertIs(result, loader.return_value)
            self.assertEqual(loader.call_args.kwargs['comms_config_path'], 'transport.py')

    def test_legacy_comms_override_fails_clearly_instead_of_silently_using_local_transport(self):
        with self.assertRaisesRegex(ValueError, 'only supported with the native'):
            load_replay_config('missing.py', 'missing.urdf', sdk_generation='legacy',
                               comms_config_path='transport.py')

    def test_missing_default_or_explicit_transport_fails_before_sdk_imports(self):
        with tempfile.TemporaryDirectory() as directory:
            missing = Path(directory) / 'missing_comms_manager_conf.py'
            for options in ({}, {'comms_config_path': missing}):
                with self.subTest(options=options), patch.object(quest_sdk_config, 'SYSTEM_COMMS_CONFIG', missing), patch.object(quest_sdk_config, '_native_symbols') as native:
                    with self.assertRaisesRegex(FileNotFoundError, 'Selected SDK communications config is missing') as caught:
                        quest_sdk_config.load_branch_config(CONFIG, URDF, **options)
                    self.assertIn(str(missing), str(caught.exception))
                    native.assert_not_called()

    def test_selected_transport_directory_fails_before_sdk_imports(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(quest_sdk_config, '_native_symbols') as native:
            with self.assertRaisesRegex(FileNotFoundError, 'must be a file'):
                quest_sdk_config.load_branch_config(CONFIG, URDF, comms_config_path=directory)
            native.assert_not_called()


@unittest.skipUnless(os.environ.get('QUEST_TEST_NATIVE_SDK') == '1',
                     'Requires explicit config-only native branch SDK environment')
class NativeConfigTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import feathersdk
        from feathersdk.robot.actuators.robstride import RobstrideMotorConfig
        from feathersdk.quill_defs.python_qdefs.robstride_qdef import rob_kp_lim, rob_kd_lim
        cls.sdk_class = RobstrideMotorConfig
        cls.kp_limits, cls.kd_limits = rob_kp_lim, rob_kd_lim
        if not Path(feathersdk.__file__).resolve().is_relative_to(REPO / 'feathersdk/src'):
            raise AssertionError('Native tests must use this checkout\'s branch SDK')
        cls.symbols = quest_sdk_config._native_symbols()
        cls.config = quest_sdk_config.load_branch_config(CONFIG, URDF,
                         include_torso=True, include_navigation=True, include_neck=True)
        cls.motors = []
        for side in ('left', 'right'):
            arm = getattr(cls.config.arms_system_config, side + '_arm')
            cls.motors.extend(getattr(arm, name) for name in type(arm).model_fields
                              if name.endswith('_motor'))

    def test_native_motor_type_and_constructor_contract_accept_every_arm(self):
        allocator = native_allocator(self.sdk_class)
        for motor in self.motors:
            with self.subTest(motor=motor.name):
                self.assertIs(type(motor), self.sdk_class)
                self.assertIs(allocator(motor).config, motor)

    def test_all_hardware_models_match_known_ids_without_replacing_albert_tuning(self):
        # Independent hardware identity fixture from the current system
        # declarations and the supplied successful arms_v1_test_left report.
        # In particular, neither wrist-roll motor is RS00 and no drive is RS01.
        expected_by_id = {
            0x10: ('shoulder_pitch_right', 'RS04'),
            0x11: ('shoulder_roll_right', 'RS04'),
            0x12: ('shoulder_yaw_right', 'RS03'),
            0x13: ('elbow_right', 'RS03'),
            0x14: ('wrist_yaw_right', 'RS02'),
            0x15: ('wrist_roll_right', 'RS02'),
            0x16: ('wrist_pitch_right', 'RS00'),
            0x20: ('shoulder_pitch_left', 'RS04'),
            0x21: ('shoulder_roll_left', 'RS04'),
            0x22: ('shoulder_yaw_left', 'RS03'),
            0x23: ('elbow_left', 'RS03'),
            0x24: ('wrist_yaw_left', 'RS02'),
            0x25: ('wrist_roll_left', 'RS02'),
            0x26: ('wrist_pitch_left', 'RS00'),
            0x30: ('neck_pitch', 'RS05'),
            0x31: ('neck_yaw', 'RS05'),
            0x70: ('turning_center', 'RS02'),
            0x71: ('turning_right', 'RS02'),
            0x72: ('turning_left', 'RS02'),
            0x73: ('drive_center', 'RS02'),
            0x74: ('drive_right', 'RS02'),
            0x75: ('drive_left', 'RS02'),
        }
        motors = list(self.motors)
        for field in ('neck_system_config', 'navigation_system_config'):
            system = getattr(self.config, field)
            motors.extend(getattr(system, name) for name in type(system).model_fields
                          if name.endswith('_motor'))
        self.assertEqual(len(motors), 22)
        by_id = {motor.id: motor for motor in motors}
        self.assertEqual(set(by_id), set(expected_by_id))
        self.assertEqual(len(by_id), len(motors))
        for identifier, (name, model) in expected_by_id.items():
            with self.subTest(id=hex(identifier), motor=name):
                self.assertEqual((by_id[identifier].name, by_id[identifier].version.name), (name, model))
        for identifier in (0x15, 0x25):
            with self.subTest(wrist_roll=hex(identifier)):
                wrist = by_id[identifier]
                self.assertEqual(wrist.max_torque, 4.)
                self.assertEqual(wrist.max_velocity, 3.)
                self.assertEqual(wrist.default_op_kp, 40.)
                self.assertEqual(wrist.default_op_kd, 3.)
        base_geometry = {
            0x73: (1, 'BpC', 'wheel_link_center_1'),
            0x74: (1, 'BpR', 'wheel_link_right_1'),
            0x75: (-1, 'BpL', 'wheel_link_left_1'),
        }
        for identifier, (direction, joint, link) in base_geometry.items():
            with self.subTest(drive=hex(identifier)):
                drive = by_id[identifier]
                self.assertEqual(drive.max_torque, 5.5)
                self.assertEqual(drive.max_velocity, 10.47)
                self.assertEqual((drive.direction, drive.urdf_joint_name, drive.urdf_link_name),
                                 (direction, joint, link))
        self.assertEqual(self.config.torso_system_config.lift_motor.id, 0x09)

    def test_selected_motor_urdf_references_and_drive_meshes_exist(self):
        # Parse the selected file directly: creating URDFLoader would allow
        # Pinocchio/cache initialization and is unnecessary for this check.
        before = URDF.read_bytes()
        root = ElementTree.fromstring(before)
        links = {link.attrib['name']: link for link in root.findall('link')}
        joints = {joint.attrib['name']: joint for joint in root.findall('joint')}
        self.assertEqual(len(links), len(root.findall('link')))
        self.assertEqual(len(joints), len(root.findall('joint')))
        motors = list(self.motors)
        for field in ('neck_system_config', 'torso_system_config', 'navigation_system_config'):
            system = getattr(self.config, field)
            motors.extend(getattr(system, name) for name in type(system).model_fields
                          if name.endswith('_motor'))
        self.assertEqual(len(motors), 23)
        required_joints = {motor.name for motor in self.motors}
        navigation = self.config.navigation_system_config
        required_joints.update(getattr(navigation, name).name for name in type(navigation).model_fields
                               if name.endswith('_motor'))
        for motor in motors:
            with self.subTest(motor=motor.name):
                # Neck/torso may omit these optional SDK fields. Validate any
                # reference they declare; arm/base joint references are required.
                if motor.name in required_joints:
                    self.assertTrue(motor.urdf_joint_name)
                if motor.urdf_joint_name:
                    self.assertIn(motor.urdf_joint_name, joints)
                if motor.urdf_link_name:
                    self.assertIn(motor.urdf_link_name, links)
        package_root = URDF.parent.parent
        package_prefix = f'package://{package_root.name}/'
        for name in ('drive_center_motor', 'drive_right_motor', 'drive_left_motor'):
            drive = getattr(navigation, name)
            with self.subTest(drive=drive.name):
                self.assertTrue(drive.urdf_link_name)
                joint = joints[drive.urdf_joint_name]
                self.assertEqual(joint.find('child').attrib['link'], drive.urdf_link_name)
                meshes = links[drive.urdf_link_name].findall('visual/geometry/mesh')
                self.assertTrue(meshes, 'Wheel geometry requires a visual mesh')
                for mesh in meshes:
                    uri = mesh.attrib['filename']
                    self.assertTrue(uri.startswith(package_prefix), uri)
                    mesh_path = (package_root / uri[len(package_prefix):]).resolve(strict=True)
                    self.assertTrue(mesh_path.is_relative_to(package_root.resolve()))
                    self.assertTrue(mesh_path.is_file(), str(mesh_path))
                    self.assertEqual(mesh_path.suffix.lower(), '.stl')
                    self.assertEqual(tuple(map(float, mesh.attrib['scale'].split())), (.001, .001, .001))
        self.assertEqual(URDF.read_bytes(), before)

    def test_actual_sdk_wheel_resolver_accepts_selected_links_without_initialization(self):
        from feathersdk.robot.actuator_systems import navigation_system
        resolve = navigation_system.ThreeWheelHolonomicRobstrideNavigationSystem._resolve_wheel_geometry
        original = self.config.navigation_system_config
        original_before = original.model_dump_json()
        drives = [getattr(original, name) for name in
                  ('drive_center_motor', 'drive_right_motor', 'drive_left_motor')]
        # Independent, deliberately different centers/radii expose wheel order
        # and averaging errors. These values never replace robot geometry.
        fixture = {
            'wheel_link_center_1': SimpleNamespace(center=(-.13, 0., .06), radius=.051, width=.04),
            'wheel_link_right_1': SimpleNamespace(center=(.17, -.18, .06), radius=.052, width=.04),
            'wheel_link_left_1': SimpleNamespace(center=(.17, .18, .06), radius=.053, width=.04),
        }
        cases = [('independent fixture', fixture)]
        cache = URDF.parent / 'wheel_geometries.json'
        cache_before = cache.read_bytes() if cache.is_file() else None
        if cache_before is not None:
            cached = json.loads(cache_before)
            xml_links = {link.attrib['name'] for link in ElementTree.fromstring(URDF.read_bytes()).findall('link')}
            self.assertTrue(cached)
            self.assertTrue({drive.urdf_link_name for drive in drives}.issubset(cached))
            for name, geometry in cached.items():
                with self.subTest(cached_link=name):
                    self.assertIn(name, xml_links)
                    self.assertEqual(geometry['name'], name)
                    self.assertEqual(len(geometry['center']), 3)
                    self.assertTrue(all(math.isfinite(value) for value in geometry['center']))
                    for field in ('radius', 'width'):
                        self.assertTrue(math.isfinite(geometry[field]))
                        self.assertGreater(geometry[field], 0.)
            cases.append(('installed cache', {name: SimpleNamespace(**geometry)
                                             for name, geometry in cached.items()}))
        with patch.object(navigation_system, 'info'):
            for source, geometries in cases:
                with self.subTest(source=source):
                    config = original.model_copy(update={'wheel_positions': [], 'wheel_radius': 0.}, deep=True)
                    loader = SimpleNamespace(urdf_path=URDF, wheel_geometries=geometries)
                    target = SimpleNamespace(config=config, robot=SimpleNamespace(urdf_loader=loader),
                                             drive_motors=[SimpleNamespace(config=drive) for drive in drives])
                    resolve(target)
                    selected = [geometries[drive.urdf_link_name] for drive in drives]
                    self.assertEqual(config.wheel_positions, [(float(g.center[0]), float(g.center[1]))
                                                              for g in selected])
                    self.assertAlmostEqual(config.wheel_radius, sum(g.radius for g in selected) / 3)
            # The original mismatched link must fail this exact SDK lookup,
            # without constructing a motor, loading a robot, or sending commands.
            config = original.model_copy(update={'wheel_positions': [], 'wheel_radius': 0.}, deep=True)
            old_drive = drives[0].model_copy(update={'urdf_link_name': 'drive_wheel_center_link_1'}, deep=True)
            target = SimpleNamespace(config=config, robot=SimpleNamespace(urdf_loader=SimpleNamespace(
                                     urdf_path=URDF, wheel_geometries=fixture)),
                                     drive_motors=[SimpleNamespace(config=old_drive)])
            with self.assertRaisesRegex(ValueError, 'No wheel geometry.*drive_wheel_center_link_1'):
                resolve(target)
        self.assertEqual(original.model_dump_json(), original_before)
        if cache_before is not None:
            self.assertEqual(cache.read_bytes(), cache_before)

    def test_public_replay_loader_defaults_to_native_and_selects_requested_subset(self):
        from feathersdk.robot.robot import FeatherRobotConfig
        files_before = {path: path.read_bytes() for path in CONFIG.parent.rglob('*.py')}
        result = load_replay_config(CONFIG, URDF, include_torso=True, include_neck=True,
                                    hand_sides=('left',))
        self.assertIs(type(result), FeatherRobotConfig)
        self.assertIsNotNone(result.arms_system_config)
        self.assertIsNotNone(result.torso_system_config)
        self.assertIsNotNone(result.neck_system_config)
        self.assertIsNone(result.navigation_system_config)
        self.assertIsNone(result.manipulation_system_config)
        self.assertIsNone(result.battery_service_config)
        self.assertFalse(result.set_signal_handlers)
        self.assertEqual(result.urdf_path, URDF.resolve(strict=True))
        self.assertTrue(result.data_monitor_service_config.candump_enabled)
        shoulder = result.arms_system_config.left_arm.shoulder_pitch_motor
        self.assertIs(type(shoulder), self.sdk_class)
        self.assertEqual(shoulder.default_op_kp, 300)
        self.assertEqual(set(quest_sdk_config.read_hand_configs(CONFIG, ('left',))), {'left'})
        self.assertEqual({path: path.read_bytes() for path in files_before}, files_before)

    def test_default_native_transport_retains_installed_declarations_and_source_bytes(self):
        from feathersdk.robot.comms import CommsManagerConfig
        selected = quest_sdk_config.SYSTEM_COMMS_CONFIG.resolve(strict=True)
        before = selected.read_bytes()
        # Read expectations independently from the actual declaration rather
        # than prescribing which transport the user must currently select.
        tree = ast.parse(before.decode('utf-8'), filename=str(selected))
        assignments = [node for node in tree.body if isinstance(node, ast.Assign)
                       and any(isinstance(target, ast.Name) and target.id == 'comms_manager_config'
                               for target in node.targets)]
        self.assertEqual(len(assignments), 1)
        declaration = assignments[0].value
        self.assertIsInstance(declaration, ast.Call)
        self.assertEqual(declaration.func.id, 'CommsManagerConfig')
        self.assertTrue(all(item.arg is not None for item in declaration.keywords))
        expected = {item.arg: ast.literal_eval(item.value) for item in declaration.keywords}
        result = load_replay_config(CONFIG, URDF)
        comms = result.comms_manager_config
        self.assertIs(type(comms), CommsManagerConfig)
        self.assertFalse(set(expected) - set(CommsManagerConfig.model_fields))
        if expected.get('use_emulated_teensy', False):
            expected['teensy_ip'] = '127.0.0.1'  # The native model's documented validator.
        for field, value in expected.items():
            with self.subTest(field=field):
                self.assertEqual(getattr(comms, field), value)
        self.assertEqual(selected.read_bytes(), before)

    def test_explicit_comms_fixture_preserves_both_modes_and_default_source_selection(self):
        files_before = {path: path.read_bytes() for path in CONFIG.parent.rglob('*.py')}
        installed = quest_sdk_config.SYSTEM_COMMS_CONFIG
        installed_before = installed.read_bytes()
        with tempfile.TemporaryDirectory() as directory:
            selected = Path(directory) / 'comms_manager_conf.py'
            try:
                for emulated in (False, True):
                    with self.subTest(emulated=emulated):
                        selected.write_text("from feathersdk.robot.comms import CommsManagerConfig\n"
                            f"comms_manager_config = CommsManagerConfig(use_emulated_teensy={emulated!r}, "
                            "teensy_ip='10.2.3.4', max_can_rate=1200., teensy_operating_frequency=80., "
                            "teensy_telemetry_update_frequency=90., result_operating_frequency=150.)\n")
                        selected_before = selected.read_bytes()
                        result = load_replay_config(CONFIG, URDF, include_navigation=True,
                                                    comms_config_path=selected)
                        comms = result.comms_manager_config
                        self.assertEqual(comms.use_emulated_teensy, emulated)
                        self.assertEqual(comms.teensy_ip, '127.0.0.1' if emulated else '10.2.3.4')
                        self.assertEqual(comms.max_can_rate, 1200.)
                        self.assertEqual(comms.teensy_operating_frequency, 80.)
                        self.assertEqual(comms.teensy_telemetry_update_frequency, 90.)
                        self.assertEqual(comms.result_operating_frequency, 150.)
                        # Distinct rates/host make this default-source check
                        # meaningful even if Albert and installed flags agree.
                        with patch.object(quest_sdk_config, 'SYSTEM_COMMS_CONFIG', selected):
                            default = load_replay_config(CONFIG, URDF)
                        self.assertEqual(default.comms_manager_config.model_dump(), comms.model_dump())
                        self.assertEqual(result.arms_system_config.model_dump(), self.config.arms_system_config.model_dump())
                        self.assertEqual(result.navigation_system_config.model_dump(), self.config.navigation_system_config.model_dump())
                        self.assertEqual(selected.read_bytes(), selected_before)
            finally:
                # The audit checks absolute paths; Linux rmtree otherwise
                # unlinks a basename through dir_fd before removing the folder.
                selected.unlink(missing_ok=True)
        self.assertEqual(installed.read_bytes(), installed_before)
        self.assertEqual({path: path.read_bytes() for path in files_before}, files_before)

    def test_user_ids_limits_gains_and_motion_parameters_are_retained(self):
        # Capture declarations independently; every original keyword survives
        # in these namespaces, without invoking the migration factories.
        class EnumNames:
            def __getattr__(self, name):
                return name
        expected_symbols = dict(RobstrideVersion=EnumNames(), SafeStopPolicy=EnumNames(),
            NumericRange=lambda low, high: (low, high), deg2rad=math.radians,
            RobstrideMotorConfig=SimpleNamespace, RobstrideCalibrationConfig=SimpleNamespace,
            Robstride7MArmConfig=SimpleNamespace, ArmsSystemConfig=SimpleNamespace)
        expected = quest_sdk_config._declarations(CONFIG.parent / 'systems/arms_system_conf.py',
                                                  expected_symbols, 'arms_system_config')
        fields = ('id', 'name', 'urdf_joint_name', 'direction', 'angle_range', 'default_op_kp',
                  'default_op_kd', 'max_velocity', 'max_acceleration', 'max_jerk',
                  'max_torque', 'gravity_multiplier', 'loc_kp', 'spd_kp', 'calibration_timeout')
        for side in ('left', 'right'):
            expected_arm = getattr(expected, side + '_arm')
            actual_arm = getattr(self.config.arms_system_config, side + '_arm')
            for name, motor in vars(expected_arm).items():
                if not name.endswith('_motor'):
                    continue
                actual = getattr(actual_arm, name)
                for field in fields:
                    with self.subTest(motor=actual.name, field=field):
                        self.assertEqual(getattr(actual, field), getattr(motor, field))
                self.assertEqual(actual.version.name, motor.version)
                for field, value in vars(motor.calibration_config).items():
                    self.assertEqual(getattr(actual.calibration_config, field), value)
        self.assertEqual(self.config.arms_system_config.left_arm.shoulder_pitch_motor.default_op_kp, 300)

    def test_gain_factory_accepts_wire_boundaries_for_every_native_motor_version(self):
        build = self.symbols['RobstrideMotorConfig']
        prototype = self.motors[0].model_dump()
        prototype.update(max_torque=1.0, max_velocity=.5)
        for version in self.symbols['RobVersion']:
            with self.subTest(version=version.name):
                values = dict(prototype, version=version,
                              default_op_kp=self.kp_limits[version], default_op_kd=self.kd_limits[version])
                motor = build(**values)
                self.assertIs(type(motor), self.sdk_class)
                self.assertEqual(motor.default_op_kp, self.kp_limits[version])
                self.assertEqual(motor.default_op_kd, self.kd_limits[version])
                # The SDK still validates all ordinary fields on the real model.
                ordinary = motor.model_dump()
                ordinary.update(default_op_kp=0, default_op_kd=0)
                self.sdk_class.model_validate(ordinary, strict=True)

    def test_gain_factory_rejects_out_of_wire_range_and_nonfinite_values(self):
        build = self.symbols['RobstrideMotorConfig']
        prototype = self.motors[0].model_dump()
        prototype.update(max_torque=1.0, max_velocity=.5)
        for version in self.symbols['RobVersion']:
            for field, limit in (('default_op_kp', self.kp_limits[version]),
                                 ('default_op_kd', self.kd_limits[version])):
                for value in (limit + .01, -0.01, math.nan, math.inf):
                    with self.subTest(version=version.name, field=field, value=value):
                        values = dict(prototype, version=version, default_op_kp=0, default_op_kd=0)
                        values[field] = value
                        with self.assertRaises(ValueError):
                            build(**values)

    def test_all_selected_robstride_configs_fit_native_can_initialization_limits(self):
        from feathersdk.quill_defs.python_qdefs.robstride_qdef import RobVersion, rob_spd_lim, rob_torque_lim
        motors = list(self.motors)
        for field in ('neck_system_config', 'navigation_system_config'):
            system = getattr(self.config, field)
            motors.extend(getattr(system, name) for name in type(system).model_fields
                          if name.endswith('_motor'))
        self.assertEqual(len(motors), 22)
        for motor in motors:
            with self.subTest(motor=motor.name):
                self.assertIs(type(motor), self.sdk_class)
                self.assertGreater(motor.max_velocity, 0)
                self.assertLessEqual(motor.max_velocity, rob_spd_lim[motor.version])
                self.assertGreater(motor.max_torque, 0)
                self.assertLessEqual(motor.max_torque, rob_torque_lim[motor.version])
                self.assertLessEqual(motor.default_op_kp, self.kp_limits[motor.version])
                self.assertLessEqual(motor.default_op_kd, self.kd_limits[motor.version])
        # The corrected wrists must index the RS02 CAN tables. RS00 has
        # different velocity/torque encodings despite accepting these tunings.
        for motor in motors:
            if motor.id in (0x15, 0x25):
                with self.subTest(wrist_encoder=motor.name):
                    self.assertEqual(motor.version, RobVersion.RS02)
                    self.assertEqual((rob_spd_lim[motor.version], rob_torque_lim[motor.version]), (44., 17.))
                    self.assertEqual((rob_spd_lim[RobVersion.RS00], rob_torque_lim[RobVersion.RS00]), (33., 14.))

    def test_non_gain_validation_and_unknown_fields_are_not_bypassed(self):
        build = self.symbols['RobstrideMotorConfig']
        prototype = self.motors[0].model_dump()
        for changed in ({'id': 254}, {'angle_range': (1, 2)}, {'max_velocity': -1},
                        {'calibration_timeout': 999}, {'unknown_field': 1}):
            with self.subTest(changed=changed):
                with self.assertRaises((ValueError, TypeError)):
                    build(**dict(prototype, **changed))

    def test_optional_subsystems_and_hand_selection_leave_original_files_unchanged(self):
        from itertools import product
        files_before = {path: path.read_bytes() for path in CONFIG.parent.rglob('*.py')}
        original_before = self.config.model_dump_json()
        for torso, nav, neck, sides in product((False, True), (False, True), (False, True),
                                             ((), ('left',), ('right',), ('left', 'right'))):
            with self.subTest(torso=torso, nav=nav, neck=neck, sides=sides):
                result = quest_sdk_config.load_branch_config(CONFIG, URDF, include_torso=torso,
                            include_navigation=nav, include_neck=neck, hand_sides=sides)
                for field, selected in (('torso_system_config', torso),
                                        ('navigation_system_config', nav), ('neck_system_config', neck)):
                    self.assertEqual(getattr(result, field) is not None, selected)
                hands = quest_sdk_config.read_hand_configs(CONFIG, sides)
                self.assertEqual(set(hands), set(sides))
                for side, hand in hands.items():
                    self.assertEqual(hand.id, 0x28 if side == 'left' else 0x27)
                    self.assertEqual(hand.version, 'L6')
                self.assertIsNone(result.manipulation_system_config)
                self.assertIsNone(result.battery_service_config)
                self.assertEqual(self.config.model_dump_json(), original_before)
        self.assertEqual({path: path.read_bytes() for path in files_before}, files_before)


if __name__ == '__main__':
    unittest.main()
