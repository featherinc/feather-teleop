"""Synthetic timing and command safety tests; no robot or sockets are used."""

import math
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from quest_control import ArmCommandState, FixedRate


def arm(**kwargs):
    return ArmCommandState(
        {'a': 0.0, 'b': 0.0},
        {'a': 1.0, 'b': 2.0},
        {'a': 2.0, 'b': 4.0},
        {'a': (-1.0, 1.0), 'b': (-2.0, 2.0)},
        **kwargs,
    )


class SchedulerTests(unittest.TestCase):
    def test_absolute_schedule_and_no_catchup_burst(self):
        clock = FixedRate(30, 10.0)
        self.assertTrue(clock.ready(10.0))
        self.assertEqual(clock.advance(10.0), 0)
        self.assertEqual(clock.advance(10.01), 0)
        self.assertFalse(clock.ready(10.01))
        self.assertAlmostEqual(clock.wait_delay(10.03), .002)
        self.assertAlmostEqual(clock.wait_delay(10.032), 1 / 30 - .032)
        self.assertEqual(clock.advance(10.20), 5)
        self.assertFalse(clock.ready(10.20))
        self.assertAlmostEqual(clock.deadline, 10 + 7 / 30)
        self.assertEqual(clock.wait_delay(10.30), 0)
        self.assertEqual(clock.advance(10.30), 2)
        self.assertFalse(clock.ready(10.30))


class ArmTests(unittest.TestCase):
    def test_common_interpolation_and_variable_time_step(self):
        state = arm()
        first = state.update({'a': .5, 'b': 1.0}, True, 1.0, 1.0)
        self.assertEqual(first['reason'], 'continuity_limited')
        self.assertAlmostEqual(first['positions']['b'], 2 * first['positions']['a'])
        self.assertLessEqual(first['max_step_rad'], 2 / 30 + 1e-12)
        second = state.update({'a': .5, 'b': 1.0}, True, 1.10, 1.10)
        self.assertLessEqual(second['max_step_rad'], 3 / 30 + 1e-12)
        self.assertGreater(second['max_step_rad'], first['max_step_rad'])
        self.assertGreaterEqual(second['velocities']['a'], 0)
        self.assertLessEqual(second['velocities']['a'], .5)

    def test_bad_candidates_retry_feedback_until_measured_hold_succeeds(self):
        state = arm()
        state.update({'a': .2, 'b': .4}, True, 0.0, 0.0)
        held = state.positions.copy()
        for when, candidate in ((.01, {'a': math.nan, 'b': 0}),
                                (.10, {'a': 9.0, 'b': 0}),
                                (.31, {'a': 0.0})):
            result = state.update(candidate, True, when, when)
            self.assertEqual(result['positions'], held)
            self.assertEqual(result['velocities'], {'a': 0.0, 'b': 0.0})
        self.assertTrue(result['needs_measured_hold'])
        self.assertEqual(result['reason'], 'persistent_hold')
        self.assertAlmostEqual(result['failure_duration_s'], .30)
        next_result = state.update({'a': .8, 'b': 1.0}, True, .32, .32)
        self.assertTrue(next_result['needs_measured_hold'])
        self.assertEqual(next_result['positions'], held)
        state.measured_hold({'a': .1, 'b': .2}, .33)
        recovery = state.update({'a': .9, 'b': 1.8}, True, .34, .34)
        self.assertEqual(recovery['reason'], 'recovering')
        self.assertLessEqual(recovery['max_step_rad'], .02 + 1e-12)
        self.assertEqual(recovery['velocities'], {'a': 0.0, 'b': 0.0})

    def test_short_failure_recovers_without_feedback(self):
        state = arm()
        state.update({'a': .4, 'b': .8}, True, 0.0, 0.0)
        held = state.positions.copy()
        result = state.update({}, False, .10, .10)
        self.assertEqual(result['reason'], 'invalid_hold')
        self.assertFalse(result['needs_measured_hold'])
        recovered = state.update({'a': .8, 'b': 1.6}, True, .11, .11)
        self.assertEqual(recovered['reason'], 'recovering')
        self.assertGreater(recovered['positions']['a'], held['a'])
        self.assertEqual(recovered['velocities']['a'], 0)

    def test_feedforward_stale_stationary_and_reversal(self):
        state = arm()
        state.update({'a': .8, 'b': 0}, True, 0.0, 0.0)
        moving = state.update({'a': .8, 'b': 0}, True, .033, .033)
        self.assertGreater(moving['velocities']['a'], 0)
        stale = state.update({'a': .8, 'b': 0}, True, .066, .033)
        self.assertEqual(stale['velocities']['a'], 0)
        backward = state.update({'a': -.8, 'b': 0}, True, .099, .099)
        self.assertEqual(backward['velocities']['a'], 0)
        backing = state.update({'a': -.8, 'b': 0}, True, .132, .132)
        self.assertLess(backing['velocities']['a'], 0)
        still = state.update(dict(state.positions), True, .165, .165)
        self.assertEqual(still['velocities']['a'], 0)

    def test_out_of_order_timestamp_does_not_move_sample_baseline(self):
        state = arm()
        state.update({'a': .8, 'b': 0}, True, 0.0, 10.0)
        state.update({'a': .8, 'b': 0}, True, .033, 10.033)
        self.assertEqual(state.update({'a': .8, 'b': 0}, True, .066, 10.033)['velocities']['a'], 0)
        self.assertEqual(state.update({'a': .8, 'b': 0}, True, .099, 9.9)['velocities']['a'], 0)
        self.assertAlmostEqual(state._last_sample_s, 10.033)
        fresh = state.update({'a': .8, 'b': 0}, True, .132, 10.066)
        self.assertGreater(fresh['velocities']['a'], 0)

    def test_lowpass_and_local_time_acceleration_limit(self):
        state = ArmCommandState({'a': 0}, {'a': 1}, {'a': 100}, {'a': (-10, 10)})
        state.update({'a': 5}, True, 0, 0)
        result = state.update({'a': 5}, True, .033, .033)
        raw = .5 * result['max_step_rad'] / .033
        alpha = .033 / (.05 + .033)
        self.assertAlmostEqual(result['velocities']['a'], alpha * raw)
        state = arm()
        state.update({'a': .8, 'b': 0}, True, 0, 0)
        result = state.update({'a': .8, 'b': 0}, True, .01, 100.0)
        self.assertLessEqual(result['velocities']['a'], state.acceleration_limits['a'] * .01 + 1e-12)

    def test_watchdog_zero_and_reset(self):
        state = arm()
        state.update({'a': .8, 'b': 0}, True, 0.0, 0.0)
        state.update({'a': .8, 'b': 0}, True, .033, .033)
        pos = state.positions.copy()
        state.zero_velocity()
        self.assertEqual(state.positions, pos)
        self.assertEqual(state.velocities['a'], 0)
        result = state.update({'a': .8, 'b': 0}, True, .066, .066)
        self.assertEqual(result['velocities']['a'], 0)
        state.reset({'a': -.3, 'b': -.6}, 1.0)
        fresh = state.update({'a': .8, 'b': 1.6}, True, 1.01, 1.01)
        self.assertEqual(fresh['velocities'], {'a': 0.0, 'b': 0.0})
        self.assertLessEqual(fresh['max_step_rad'], .02 + 1e-12)

    def test_brakes_before_joint_limit(self):
        state = arm()
        state.reset({'a': .99, 'b': 0}, 0.0)
        result = state.update({'a': 1.0, 'b': 0}, True, .033, .033)
        self.assertGreater(result['positions']['a'], .99)
        self.assertLess(result['positions']['a'], 1.0)
        self.assertLessEqual(result['max_step_rad'], .01 / .15 * .033 + 1e-12)
        result = state.update({'a': 1.0, 'b': 0}, True, .066, .066)
        margin = 1.0 - result['positions']['a']
        self.assertLessEqual(result['velocities']['a'], margin / .15 + 1e-12)
        self.assertLessEqual(result['velocities']['a'], math.sqrt(4 * margin) + 1e-12)
        stationary = state.update(dict(state.positions), True, .099, .099)
        self.assertEqual(stationary['velocities']['a'], 0)


if __name__ == '__main__':
    unittest.main(verbosity=2)
