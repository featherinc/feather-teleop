"""ZED X / ZED 2i stereo video for the existing Quest app. No robot SDK imports.

Reuses TeleVision's StereoCamera in a separate process. TCP 5006 carries only
the latest pair of JPEGs; pose/control UDP remains on 5005.
"""
import argparse
import importlib.util
import json
import math
import os
from pathlib import Path
import shutil
import signal
import socket
import struct
import subprocess
import time

HEADER = struct.Struct('<4sBBHIfII')  # magic, version, status, bytes, seq, age_ms, JPEG sizes
CALIBRATION = struct.Struct('<7f')  # fx,fy,cx,cy,reserved,camera baseline,reserved
METRIC_REQUEST = struct.Struct('<If')
REQUEST = struct.Struct('<I')       # last displayed sequence
CONTROL = struct.Struct('<?d')     # local-only RUNNING heartbeat + monotonic timestamp
MAX_IMAGE_BYTES = 1_048_576
STALE_SECONDS = .5


def read_exact(connection, count):
    result = bytearray()
    while len(result) < count:
        data = connection.recv(count - len(result))
        if not data:
            raise EOFError('Video client disconnected')
        result.extend(data)
    return bytes(result)


def video_packet(camera, previous, active=True, metric=False, native=False):
    """v3 sends the original stereo pair; older clients receive 2D."""
    version = 3 if native else 2 if metric else 1
    metadata = native or metric
    header_size = HEADER.size + (CALIBRATION.size if metadata else 0)
    calibration, stereo = None, False
    if metadata:
        frame, calibration, stereo = camera.latest_calibrated_jpeg()
    else:
        frame = camera.latest_jpeg()
    status, seq, age_ms, left, right = 1, 0, 0., b'', b''
    if not active:
        status = 3
    elif frame is not None:
        sequence, stamp, ldata, rdata, width, height = frame
        seq = int(sequence) & 0xffffffff
        age = time.monotonic() - stamp
        if (camera.healthy() and math.isfinite(age) and 0 <= age < STALE_SECONDS
                and (width, height) == (640, 360)
                and 0 < len(ldata) <= MAX_IMAGE_BYTES and 0 < len(rdata) <= MAX_IMAGE_BYTES):
            age_ms = age * 1000
            status = 2 if seq == previous else 0
            if status == 0:
                left, right = ldata, rdata
                if not native and getattr(camera, 'native_stereo', False):
                    right = left  # Older APKs cannot identify the native-stereo protocol.
    extra = b''
    if metadata:
        good_calibration = (calibration is not None and len(calibration) == 7
            and all(math.isfinite(v) for v in calibration)
            and calibration[0] > 0 and calibration[1] > 0
            and 0 <= calibration[2] <= 640 and 0 <= calibration[3] <= 360
            and .02 <= calibration[5] <= .3)
        if not native or not good_calibration or not stereo:
            status |= 0x40
            right = left
        extra = CALIBRATION.pack(*(calibration if good_calibration else [0.]*7))
    if getattr(camera, 'synthetic', False):
        status |= 0x80
    return (HEADER.pack(b'QVID', version, status, header_size, seq, age_ms, len(left), len(right))
            + extra + left + right)

def load_capture(television):
    source = Path(television) / 'teleop/quest_zed.py'
    spec = importlib.util.spec_from_file_location('_quest_existing_zed', source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def write_status(path, **state):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(dict(pid=os.getpid(), **state)))
    os.replace(temporary, path)


class VideoStream:
    """Notebook handle. Start/stop a camera-only process without touching motors."""
    def __init__(self, television, bind='0.0.0.0', port=5006, fps=30, serial=None,
                 python=None, test_pattern=False, model='zed-x'):
        if model not in ('zed-x', 'zed-2i'):
            raise ValueError('Unknown ZED model: ' + str(model))
        self.model = model
        self.television = Path(television)
        self.python = str(python or self.television / '.env-quest/bin/python')
        self.bind, self.port, self.fps, self.serial = bind, port, fps, serial
        self.test_pattern = test_pattern
        self.process = self.log = None
        self.control = None
        self.last_active, self.last_sent = None, 0.
        self.runtime = Path(__file__).resolve().parent / '.runtime'

    def _preflight(self):
        """Check capture dependencies without importing or starting the camera."""
        for name in ('quest_zed.py', 'quest_zed_worker.py'):
            source = self.television / 'teleop' / name
            if not source.is_file():
                raise FileNotFoundError('ZED video capture file not found: ' + str(source))
        # An explicit bare command follows the same PATH lookup as Popen.
        executable = self.python if os.path.dirname(self.python) else shutil.which(self.python)
        if executable is None or not Path(executable).is_file():
            raise FileNotFoundError('ZED video Python interpreter not found: ' + self.python)
        return str(executable)

    def start(self):
        if self.process is not None and self.process.poll() is None:
            return self
        executable = self._preflight()
        self.runtime.mkdir(exist_ok=True)
        self.log = (self.runtime / 'zed_video.log').open('w')
        args = [executable, '-u', str(Path(__file__).resolve()), '--television', str(self.television),
                '--bind', self.bind, '--port', str(self.port), '--fps', str(self.fps), '--model', self.model,
                '--status', str(self.runtime / 'zed_video_status.json'), '--parent', str(os.getpid())]
        if self.serial is not None:
            args += ['--serial', str(self.serial)]
        if self.test_pattern:
            args += ['--test-pattern']
        self.control, child_control = socket.socketpair(socket.AF_UNIX, socket.SOCK_DGRAM)
        self.control.setblocking(False)
        args += ['--control-fd', str(child_control.fileno())]
        try:
            self.process = subprocess.Popen(args, stdout=self.log, stderr=self.log,
                                            pass_fds=(child_control.fileno(),),
                                            env=dict(os.environ, PYTHONNOUSERSITE="1"))
            child_control.close()
            self.set_active(False)
            deadline = time.monotonic() + 20
            while time.monotonic() < deadline:
                state = self.status()
                if state.get('healthy') and state.get('listening'):
                    return self
                if self.process.poll() is not None:
                    raise RuntimeError(state.get('error') or (self.runtime / 'zed_video.log').read_text()[-1500:])
                time.sleep(.1)
            raise TimeoutError('ZED video did not become ready; check .runtime/zed_video.log')
        except BaseException:
            child_control.close()
            self.stop()
            raise

    def set_active(self, active):
        """Nonblocking RUNNING heartbeat; no image work or disk I/O in control ticks."""
        now = time.monotonic()
        if self.control is None or (active == self.last_active and now - self.last_sent < 1/30):
            return
        try:
            self.control.send(CONTROL.pack(bool(active), now))
            self.last_active, self.last_sent = active, now
        except OSError:
            pass  # Video failure must not interrupt arm control. Missing heartbeat hides it.

    def status(self):
        try:
            state = json.loads((self.runtime / 'zed_video_status.json').read_text())
        except (OSError, ValueError):
            state = {}
        if self.process is None or state.get('pid') != self.process.pid:
            return {'healthy': False, 'error': 'Video process has not started'}
        if self.process.poll() is not None:
            state.update(healthy=False, listening=False)
        return state

    def stop(self):
        self.set_active(False)
        if self.process is not None and self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait(timeout=3)
        if self.log is not None:
            self.log.close()
            self.log = None
        if self.control is not None:
            self.control.close()
            self.control = None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--television', type=Path, required=True)
    parser.add_argument('--bind', default='0.0.0.0')
    parser.add_argument('--port', type=int, default=5006)
    parser.add_argument('--fps', type=int, choices=(10, 15, 30), default=30)
    parser.add_argument('--serial', type=int)
    parser.add_argument('--model', choices=('zed-x', 'zed-2i'), default='zed-x')
    parser.add_argument('--test-pattern', action='store_true')
    parser.add_argument('--status', type=Path, required=True)
    parser.add_argument('--parent', type=int)
    parser.add_argument('--control-fd', type=int)
    args = parser.parse_args()
    running = True
    def stop(*_):
        nonlocal running
        running = False
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    camera = client = server = None
    control = socket.socket(fileno=args.control_fd) if args.control_fd is not None else None
    if control is not None:
        control.setblocking(False)
    active, active_stamp = False, 0.
    def streaming():
        nonlocal active, active_stamp
        if control is not None:
            while True:
                try:
                    message = control.recv(CONTROL.size + 1)
                except BlockingIOError:
                    break
                if len(message) == CONTROL.size:
                    active, active_stamp = CONTROL.unpack(message)
        return active and 0 <= time.monotonic() - active_stamp < .3
    try:
        capture = load_capture(args.television)
        if not args.test_pattern:
            probe = capture.probe_camera(os.sys.executable, args.serial, model=args.model)
            if not probe['ready']:
                raise RuntimeError(args.model + ' not detected: ' + json.dumps(probe))
        server = socket.socket()
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind((args.bind, args.port))
        server.listen(1)
        server.settimeout(.2)
        camera = capture.StereoCamera(os.sys.executable, synthetic=args.test_pattern,
            serial=args.serial, fps=args.fps, model=args.model).start()
        print('TEST PATTERN' if args.test_pattern else args.model, 'stereo video on TCP', args.port, flush=True)
        next_status = 0.
        while running and (args.parent is None or os.getppid() == args.parent):
            sending = streaming()
            now = time.monotonic()
            if now >= next_status:
                write_status(args.status, **camera.status(), listening=True, port=args.port,
                             client_connected=client is not None, streaming=sending)
                next_status = now + .5
            if camera.proc.poll() is not None:
                raise RuntimeError(camera.status().get('error') or 'ZED capture stopped')
            if client is None:
                try:
                    client, _ = server.accept()
                    client.settimeout(.5)
                    client.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                except socket.timeout:
                    continue
            try:
                request_started = time.monotonic()
                request = read_exact(client, REQUEST.size)
                native, metric = request == b"QVR3", request == b"QVR2"
                if native:
                    previous, = REQUEST.unpack(read_exact(client, REQUEST.size))
                elif metric:
                    previous, _ = METRIC_REQUEST.unpack(read_exact(client, METRIC_REQUEST.size))
                else:
                    previous, = REQUEST.unpack(request)
                client.sendall(video_packet(camera, previous, active=streaming(), metric=metric, native=native))
                time.sleep(max(0., 1 / args.fps - (time.monotonic() - request_started)))  # Include I/O in the period.
            except (OSError, EOFError, ValueError):
                client.close()
                client = None
    except Exception as error:
        write_status(args.status, healthy=False, listening=False, error=str(error))
        raise
    finally:
        if client is not None:
            client.close()
        if server is not None:
            server.close()
        if control is not None:
            control.close()
        if camera is not None:
            camera.close()


if __name__ == '__main__':
    main()
