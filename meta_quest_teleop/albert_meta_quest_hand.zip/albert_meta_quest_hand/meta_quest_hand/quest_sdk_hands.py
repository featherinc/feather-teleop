"""RealHand L6/O6 through this branch's existing Teensy raw CAN transport.

Protocol source: FeatherOS commits 21823d981 and e54e69b9d, RealHand driver,
and saved Feather CAN replies from 2026-10-01. L6 sends standard frames on its
configured ID and can reply on that ID or ID + 8; discovery binds the observed
reply ID. O6 receives on its own ID. Queries have DLC 1 and writes DLC 7. No SDK import,
robot initialization, bus reconfiguration or CAN IO occurs on module import.

The branch has no native RealHand telemetry. A per-instance listener observes
the existing candump responses after the SDK records them. Firmware still
labels these replies as unhandled EZMotion frames in its global diagnostics;
they are recorded before that dispatch and do not fail normal command ACKs.
Candump omits the extended-frame flag, so attachment checks configured bus/ID
conflicts as well as filtering exact reply IDs, RX direction, DLC and register.
"""
from contextlib import nullcontext
from dataclasses import dataclass
import inspect
import math
from numbers import Integral
import struct
import threading
import time
from types import SimpleNamespace


_CAN_RECORD = struct.Struct('<BI8BQ')
_RESP_CANDUMP = 4
_RESP_SUCCESS = 0
_RESP_ERROR = 1
_INSTALL_LOCK = threading.Lock()
_MISSING = object()


def _handler_lock(handler, name):
    """Use the Teensy handler dict lock when this SDK build has one."""
    lock = getattr(handler, name, None)
    return lock if lock is not None else nullcontext()


@dataclass(frozen=True)
class HandCanConfig:
    name: str
    id: int
    version: str = 'L6'
    message_block_timeout: float = 0.3
    message_send_attempts: int = 2
    endpoint: int | None = None

    def __post_init__(self):
        version = getattr(self.version, 'name', self.version)
        if version not in ('L6', 'O6'):
            raise ValueError('Hand version must explicitly be L6 or O6')
        object.__setattr__(self, 'version', version)
        if not self.name or not isinstance(self.id, Integral) or isinstance(self.id, bool) or not 0 <= self.id <= 0x7F:
            raise ValueError('Hand name and CAN ID must be valid')
        if not math.isfinite(self.message_block_timeout) or not 0 < self.message_block_timeout <= 10:
            raise ValueError('Hand timeout must be between 0 and 10 seconds')
        if (not isinstance(self.message_send_attempts, Integral) or isinstance(self.message_send_attempts, bool)
                or not 1 <= self.message_send_attempts <= 10):
            raise ValueError('Hand send attempts must be between 1 and 10')
        if self.endpoint == 255:
            object.__setattr__(self, 'endpoint', None)  # SDK's unresolved-endpoint sentinel.
        if self.endpoint is not None and (not isinstance(self.endpoint, Integral)
                or isinstance(self.endpoint, bool) or not 0 <= self.endpoint < 8):
            raise ValueError('Hand endpoint must be a Teensy CAN bus index')


@dataclass(frozen=True)
class HandParameter:
    id: int
    name: str
    writable: bool = False


_PARAMS = tuple(HandParameter(code, name, writable) for code, name, writable in (
    (0x01, 'position', True), (0x02, 'torque_limit', True), (0x05, 'speed', True),
    (0x20, 'normal_force', False), (0x21, 'tangential_force', False),
    (0x22, 'tangential_dir', False), (0x23, 'approach', False),
    (0x33, 'temperature', False), (0x35, 'errors', False),
    (0x36, 'current', False), (0x64, 'version', False),
))
_BY_ID = {param.id: param for param in _PARAMS}
_PARAM_SET = SimpleNamespace(**{param.name: param for param in _PARAMS})


def _six_bytes(values):
    values = [values] * 6 if isinstance(values, Integral) else list(values)
    if len(values) != 6 or any(not isinstance(v, Integral) or isinstance(v, bool) or not 0 <= v <= 255 for v in values):
        raise ValueError('RealHand commands require six integer values from 0 to 255')
    return bytes(values)


def _reply_ids(config):
    return (config.id, config.id + 8) if config.version == 'L6' else (config.id,)


class TeensyHandTransport:
    """Observe one existing SDK handler; leave its logging and polling intact."""
    def __init__(self, comms):
        self.comms = comms
        self.handler = getattr(comms, '_teensy_handler', None)
        if (self.handler is None or not callable(getattr(self.handler, '_handle_message', None))
                or not isinstance(getattr(self.handler, '_sent_messages', None), dict)
                or not isinstance(getattr(self.handler, '_responses', None), dict)
                or not callable(getattr(comms, 'cansend', None))):
            raise RuntimeError('RealHands require this branch\'s Teensy CommsManager')
        try:
            inspect.signature(comms.cansend).bind(0, extended=False, can_id=0x28, data=b'\x01')
            inspect.signature(self.handler._handle_message).bind(0, _RESP_CANDUMP, b'')
        except (TypeError, ValueError) as exc:
            raise RuntimeError('RealHand adapter is incompatible with this SDK transport signature') from exc
        dms = getattr(getattr(comms, 'robot', None), 'data_monitor_service', None)
        writer = getattr(dms, 'candump_writer', None)
        if writer is None or not callable(getattr(writer, 'write', None)):
            raise RuntimeError('Enable SDK data_monitor_service_config.candump_enabled for RealHand feedback')
        frequency = getattr(getattr(comms, 'config', None), 'teensy_candump_update_frequency', None)
        if frequency is None or not math.isfinite(frequency) or frequency <= 0:
            raise RuntimeError('RealHand feedback requires a positive Teensy candump polling frequency')
        self._condition = threading.Condition(threading.RLock())
        self._send_lock = threading.RLock()
        self._hands = {}
        self._pending = {}
        self._error = None
        self._closed = False
        self._previous_attribute = self.handler.__dict__.get('_handle_message', _MISSING)
        self._original = self.handler._handle_message

        def receive(msg_id, opcode, payload):
            with _handler_lock(self.handler, '_sent_messages_lock'):
                known = msg_id in self.handler._sent_messages
            self._original(msg_id, opcode, payload)
            if known:
                self._receive(msg_id, opcode, payload)

        self._listener = receive
        with _INSTALL_LOCK:
            if getattr(comms, '_quest_hand_transport', None) is not None:
                raise RuntimeError('Close the existing Quest hand adapter before attaching again')
            comms._quest_hand_transport = self
            self.handler._handle_message = self._listener

    def register(self, hand):
        with self._condition:
            self._check()
            keys = [(bus, reply_id) for bus in hand._eligible_buses for reply_id in hand._reply_ids]
            if any(key in self._hands for key in keys):
                raise ValueError('Two hands cannot share a CAN reply ID on the same bus')
            self._hands.update({key: hand for key in keys})

    def bind(self, hand, bus, reply_id):
        with self._condition:
            self._check()
            for key, registered in tuple(self._hands.items()):
                if registered is hand and key != (bus, reply_id):
                    del self._hands[key]
            hand.bus = bus
            hand.reply_id = reply_id

    def _check(self):
        if self._closed:
            raise RuntimeError('Quest hand adapter is closed')
        if self._error is not None:
            raise RuntimeError('Quest hand CAN transport failed') from self._error
        dms = getattr(self.comms.robot, 'data_monitor_service', None)
        if getattr(dms, 'candump_writer', None) is None:
            raise RuntimeError('SDK candump feedback was disabled during hand control')
        # A very fast Teensy ACK can arrive before cansend returns its message ID.
        for msg_id, (sent_at, timeout) in tuple(self._pending.items()):
            with _handler_lock(self.handler, '_responses_lock'):
                response = self.handler._responses.pop(msg_id, None)
            if response is not None:
                del self._pending[msg_id]
                if response[0] != _RESP_SUCCESS:
                    self._error = RuntimeError(str(response[1]))
                    raise RuntimeError('Quest hand CAN send failed') from self._error
            elif time.monotonic() - sent_at > timeout:
                self._error = TimeoutError(f'No Teensy CAN ACK for hand message {msg_id}')
                raise RuntimeError('Quest hand CAN send timed out') from self._error

    def send(self, hand, data, bus=None):
        with self._send_lock, self._condition:
            self._check()
            if bus is None:
                bus = hand.bus
            if bus is None or (hand.bus is None and (data != b'\x01' or bus not in hand._eligible_buses)):
                raise RuntimeError('Discover the hand with a blocking position query before sending commands')
            msg_id = self.comms.cansend(bus, extended=False, can_id=hand.config.id, data=data)
            if isinstance(msg_id, Integral):
                self._pending[msg_id] = (time.monotonic(), hand.config.message_block_timeout)
            self._check()

    def _receive(self, msg_id, opcode, payload):
        with self._condition:
            if self._closed:
                return
            if msg_id in self._pending and opcode in (_RESP_SUCCESS, _RESP_ERROR):
                del self._pending[msg_id]
                with _handler_lock(self.handler, '_responses_lock'):
                    self.handler._responses.pop(msg_id, None)  # Consume only adapter-owned command ACKs.
                if opcode == _RESP_ERROR:
                    self._error = RuntimeError(payload.decode('utf-8', errors='replace'))
                    self._condition.notify_all()
            if opcode != _RESP_CANDUMP or not payload:
                return
            if len(payload) % _CAN_RECORD.size:
                self._error = ValueError('Malformed SDK candump response')
                self._condition.notify_all()
                return  # A hand parser must never throw on the SDK comms thread.
            for info, can_id, *rest in _CAN_RECORD.iter_unpack(payload):
                if info & 0x10:
                    continue  # TX echoes are never hand feedback.
                bus, dlc = info >> 5, info & 0x0F
                hand = self._hands.get((bus, can_id))
                if hand is None or dlc not in (7, 8):
                    continue
                data, stamp = bytes(rest[:8]), rest[8]
                if data[:5] == b'ERROR':
                    hand._error = RuntimeError(f'RealHand {hand.config.name} error: 0x{int.from_bytes(data[5:dlc], "big"):X}')
                elif data[0] in _BY_ID:
                    # Keep precisely six channels; DLC7/8 padding cannot shift them.
                    hand._sequence += 1
                    hand._feedback[(bus, can_id, data[0])] = (hand._sequence, stamp, data[1:7])
                self._condition.notify_all()

    def close(self):
        """Detach the listener and wake waiters; send no CAN or motion command."""
        with _INSTALL_LOCK, self._condition:
            if self._closed:
                return
            self._closed = True
            self._condition.notify_all()
            if self.handler.__dict__.get('_handle_message') is self._listener:
                if self._previous_attribute is _MISSING:
                    self.handler.__dict__.pop('_handle_message', None)
                else:
                    self.handler._handle_message = self._previous_attribute
            if getattr(self.comms, '_quest_hand_transport', None) is self:
                del self.comms._quest_hand_transport


class RealHandCan:
    """Selected hand; preserve the teleop's SDK-shaped position/speed/torque API."""
    PARAM_SET = _PARAM_SET

    def __init__(self, config, eligible_buses, transport):
        self.config = config
        self.bus = None
        self._eligible_buses = tuple(eligible_buses)
        self._reply_ids = _reply_ids(config)
        self.reply_id = config.id + (8 if config.version == 'L6' else 0)
        self._transport = transport
        self._query_lock = threading.RLock()
        self._feedback = {}
        self._sequence = 0
        self._error = None
        transport.register(self)

    def _check(self):
        self._transport._check()
        if self._error is not None:
            raise RuntimeError(f'RealHand {self.config.name} failed') from self._error

    def read_param(self, param, block=False):
        if not isinstance(param, HandParameter) or _BY_ID.get(param.id) != param:
            raise ValueError('Unknown RealHand parameter')
        with self._query_lock:
            if self.bus is None:
                if not block or param != self.PARAM_SET.position:
                    raise RuntimeError('Discover the hand with a blocking position query first')
                return self._discover()
            condition = self._transport._condition
            with condition:
                self._check()
                sequence, started_ns = self._sequence, time.monotonic_ns()
            for _ in range(self.config.message_send_attempts if block else 1):
                self._transport.send(self, bytes([param.id]))
                if not block:
                    return None
                deadline = time.monotonic() + self.config.message_block_timeout
                with condition:
                    while True:
                        self._check()
                        feedback = self._feedback.get((self.bus, self.reply_id, param.id))
                        if feedback and feedback[0] > sequence and feedback[1] >= started_ns:
                            # Match the old fixed-eight-byte SDK integer representation
                            # consumed by quest_hand.read_hand_position, with known padding.
                            return int.from_bytes(feedback[2] + b'\0', 'big')
                        remaining = deadline - time.monotonic()
                        if remaining <= 0:
                            break
                        condition.wait(min(remaining, 0.02))
            raise TimeoutError(f'No fresh RealHand {self.config.name} {param.name} feedback on bus {self.bus}, ID 0x{self.reply_id:X}')

    def _discover(self):
        condition = self._transport._condition
        with condition:
            self._check()
            sequence = self._sequence
        for _ in range(self.config.message_send_attempts):
            started = {}
            for bus in self._eligible_buses:
                started[bus] = time.monotonic_ns()
                self._transport.send(self, b'\x01', bus=bus)
            # Observe every queried endpoint through the full response interval;
            # taking the first reply could bind the wrong one of duplicate hands.
            deadline = time.monotonic() + self.config.message_block_timeout
            with condition:
                while True:
                    self._check()
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        break
                    condition.wait(min(remaining, 0.02))
                responders = {(bus, reply_id): item for bus in self._eligible_buses for reply_id in self._reply_ids
                              if (item := self._feedback.get((bus, reply_id, 0x01))) is not None
                              and item[0] > sequence and item[1] >= started[bus]}
                if len(responders) > 1:
                    buses = sorted({bus for bus, reply_id in responders})
                    aliases = [(bus, hex(reply_id)) for bus, reply_id in sorted(responders)]
                    raise RuntimeError(f'Multiple RealHand {self.config.name} responders on buses {buses}, reply IDs {aliases}')
                if responders:
                    (bus, reply_id), feedback = next(iter(responders.items()))
                    self._transport.bind(self, bus, reply_id)
                    return int.from_bytes(feedback[2] + b'\0', 'big')
        raise TimeoutError(f'No fresh RealHand {self.config.name} position feedback on candidate buses {self._eligible_buses}, reply IDs {tuple(hex(reply_id) for reply_id in self._reply_ids)}')

    def read_positions(self):
        value = self.read_param(self.PARAM_SET.position, block=True)
        return list(value.to_bytes(7, 'big')[:6])

    def write_param_all(self, param, values, block=False):
        if not isinstance(param, HandParameter) or _BY_ID.get(param.id) != param or not param.writable:
            raise ValueError('RealHand parameter is not writable')
        if block:
            # L6 firmware may not answer speed/torque queries or acknowledge writes.
            raise ValueError('Blocking hand writes are unsupported; query position separately')
        with self._transport._condition:
            self._check()
        self._transport.send(self, bytes([param.id]) + _six_bytes(values))

    def set_position(self, position, block=False):
        self.write_param_all(self.PARAM_SET.position, position, block=block)

    def set_speed(self, speed, block=False):
        self.write_param_all(self.PARAM_SET.speed, speed, block=block)

    def set_torque(self, torque, block=False):
        self.write_param_all(self.PARAM_SET.torque_limit, torque, block=block)

    def enable(self):
        pass  # These hands are always enabled; preserve the SDK's no-op behavior.

    def disable(self):
        pass


class QuestHands:
    def __init__(self, transport, hands):
        self._transport = transport
        self.left_hand = hands.get('left')
        self.right_hand = hands.get('right')

    def close(self):
        self._transport.close()


def _config(value):
    if isinstance(value, HandCanConfig):
        return value
    names = ('name', 'id', 'version', 'message_block_timeout', 'message_send_attempts', 'endpoint')
    fields = {name: value[name] for name in names if name in value} if isinstance(value, dict) else {
        name: getattr(value, name) for name in names if hasattr(value, name)}
    return HandCanConfig(**fields)


def attach_hands(robot, hand_configs, sides=('left', 'right'), *, use_arm_endpoints=False):
    """Attach selected hands without sending any CAN frame or guessing their bus.

    Call after normal robot initialization with manipulation_system_config=None.
    hand_configs may be a side-keyed mapping or an object with left_hand/right_hand.
    With use_arm_endpoints=True, each selected hand uses its same-side arm's
    resolved motor endpoint; all those motors must share one valid CAN endpoint.
    Fresh hand position feedback still verifies the hand before any write.
    Keep this returned object as the notebook's manipulation variable. close()
    before reattaching or aborting/replacing the robot.
    """
    sides = tuple(sides)
    if len(set(sides)) != len(sides) or set(sides) - {'left', 'right'}:
        raise ValueError('Hand sides must be left/right without duplicates')
    if not sides:
        return SimpleNamespace(left_hand=None, right_hand=None, close=lambda: None)
    comms = getattr(robot, 'comms_manager', None)
    num_buses = getattr(comms, 'num_can_endpoints', 0)
    if not isinstance(num_buses, Integral) or isinstance(num_buses, bool) or not 1 <= num_buses <= 8:
        raise RuntimeError('Initialize this branch\'s Teensy CommsManager before attaching hands')
    prepared = {}
    for side in sides:
        raw = hand_configs.get(side) if isinstance(hand_configs, dict) else getattr(hand_configs, side + '_hand', None)
        if raw is None:
            raise ValueError(f'Configure the selected {side} RealHand')
        config = _config(raw)
        reply_ids = _reply_ids(config)
        if use_arm_endpoints:
            arm = getattr(getattr(robot, 'arms_system', None), side + '_arm', None)
            motors = getattr(arm, 'actuators_by_name', None)
            if not isinstance(motors, dict) or not motors:
                raise RuntimeError(f'Initialized {side} arm motors are required to resolve the hand CAN endpoint')
            endpoints = [getattr(getattr(motor, 'config', None), 'endpoint', None)
                         for motor in motors.values()]
            if any(not isinstance(endpoint, Integral) or isinstance(endpoint, bool)
                   or not 0 <= endpoint < num_buses for endpoint in endpoints):
                raise RuntimeError(f'The {side} arm has an unresolved or invalid motor CAN endpoint')
            if len(set(endpoints)) != 1:
                raise RuntimeError(f'The {side} arm motors must share one resolved CAN endpoint')
            arm_endpoint = int(endpoints[0])
            if config.endpoint is not None and config.endpoint != arm_endpoint:
                raise ValueError(f'The {side} hand endpoint {config.endpoint} disagrees with its arm endpoint {arm_endpoint}')
            requested = (arm_endpoint,)
        else:
            requested = range(num_buses) if config.endpoint is None else (config.endpoint,)
        buses = []
        for bus in requested:
            if not 0 <= bus < num_buses:
                raise ValueError(f'The {side} hand endpoint is outside the Teensy CAN topology')
            conflicts = [motor.config.name for motor in getattr(robot, 'actuators_by_name', {}).values()
                         if motor.config.endpoint == bus and motor.config.id in reply_ids]
            if conflicts and config.endpoint is not None:
                raise ValueError(f'Hand CAN ID conflicts with {conflicts} on bus {bus}')
            if not conflicts:
                buses.append(int(bus))
        if not buses:
            raise ValueError(f'No safe CAN endpoint for the {side} hand: command/reply IDs conflict with configured actuators')
        prepared[side] = (config, tuple(buses))
    if len({config.id for config, buses in prepared.values()}) != len(prepared):
        raise ValueError('Selected hands must have distinct command CAN IDs for discovery')
    owners = {}
    for side, (config, buses) in prepared.items():
        for bus in buses:
            for reply_id in _reply_ids(config):
                key = (bus, reply_id)
                if key in owners:
                    raise ValueError(f'Selected hands {owners[key]} and {side} share CAN reply ID 0x{reply_id:X} on bus {bus}')
                owners[key] = side
    transport = TeensyHandTransport(comms)
    try:
        return QuestHands(transport, {side: RealHandCan(config, buses, transport)
                                    for side, (config, buses) in prepared.items()})
    except Exception:
        transport.close()
        raise
