"""Pure timing and arm-command safeguards for the Quest teleoperation sender.

This module has no hardware, network, or file dependencies. Positions and
velocities are in radians and radians/second; times use monotonic seconds.
"""

from __future__ import annotations

import math


def _finite(value, label):
    value = float(value)
    if not math.isfinite(value):
        raise ValueError(f"{label} must be finite")
    return value


class FixedRate:
    """Absolute-deadline scheduler that skips beats missed by a slow iteration."""

    def __init__(self, hz: float, now: float):
        hz = _finite(hz, "hz")
        if hz <= 0:
            raise ValueError("hz must be positive")
        self.period = 1.0 / hz
        self.deadline = _finite(now, "now")

    def ready(self, now: float) -> bool:
        return _finite(now, "now") >= self.deadline

    def advance(self, now: float) -> int:
        """Advance past *now* and return the number of skipped deadlines."""
        now = _finite(now, "now")
        if now < self.deadline:
            return 0
        beats = math.floor((now - self.deadline) / self.period) + 1
        self.deadline += beats * self.period
        # Roundoff should never make an already-consumed beat immediately due.
        if self.deadline <= now:
            self.deadline += self.period
            beats += 1
        return beats - 1

    def wait_delay(self, now: float, max_delay: float = .002) -> float:
        max_delay = _finite(max_delay, "max_delay")
        if max_delay < 0:
            raise ValueError("max_delay must be nonnegative")
        return min(max_delay, max(0.0, self.deadline - _finite(now, "now")))


class ArmCommandState:
    """Bound position steps and optional feedforward for one complete arm.

    ``sample_s`` is the timestamp of the source sample, not its age. Velocity
    feedforward is suppressed when source timestamps are repeated or regress.
    The caller must pass every joint in each candidate and measured hold.
    """

    def __init__(self, initial_positions: dict[str, float],
                 velocity_limits: dict[str, float],
                 acceleration_limits: dict[str, float],
                 bounds: dict[str, tuple[float, float]],
                 period: float = 1 / 30, failure_hold_s: float = .3,
                 feedforward: bool = True):
        if not initial_positions:
            raise ValueError("at least one joint is required")
        self.names = tuple(initial_positions)
        expected = set(self.names)
        for label, values in (("velocity_limits", velocity_limits),
                              ("acceleration_limits", acceleration_limits),
                              ("bounds", bounds)):
            if set(values) != expected:
                raise ValueError(f"{label} must contain exactly the position joints")
        self.velocity_limits = {k: _finite(velocity_limits[k], f"{k} velocity limit")
                                for k in self.names}
        self.acceleration_limits = {k: _finite(acceleration_limits[k], f"{k} acceleration limit")
                                    for k in self.names}
        if any(v <= 0 for v in self.velocity_limits.values()):
            raise ValueError("velocity limits must be positive")
        if any(a <= 0 for a in self.acceleration_limits.values()):
            raise ValueError("acceleration limits must be positive")
        self.bounds = {}
        for k in self.names:
            lo, hi = bounds[k]
            lo, hi = _finite(lo, f"{k} lower bound"), _finite(hi, f"{k} upper bound")
            if lo >= hi:
                raise ValueError(f"{k} bounds must have positive range")
            self.bounds[k] = (lo, hi)
        self.period = _finite(period, "period")
        self.failure_hold_s = _finite(failure_hold_s, "failure_hold_s")
        if self.period <= 0 or self.failure_hold_s <= 0:
            raise ValueError("period and failure_hold_s must be positive")
        self.feedforward = bool(feedforward)
        self._check_positions(initial_positions)
        self.reset(initial_positions)

    def _check_positions(self, positions: dict[str, float]) -> dict[str, float]:
        if set(positions) != set(self.names):
            raise ValueError("positions must contain exactly the configured joints")
        result = {}
        for k in self.names:
            value = _finite(positions[k], f"{k} position")
            lo, hi = self.bounds[k]
            if value < lo or value > hi:
                raise ValueError(f"{k} position is outside configured bounds")
            result[k] = value
        return result

    def reset(self, positions: dict[str, float], now: float | None = None) -> None:
        """Start a fresh arm session at verified joint positions."""
        self.positions = self._check_positions(positions)
        self.velocities = {k: 0.0 for k in self.names}
        self._last_update_s = None if now is None else _finite(now, "now")
        self._last_sample_s = None
        self._last_direction = {k: 0 for k in self.names}
        self._failure_start_s = None
        self._hold_requested = False
        self._awaiting_measured = False
        self._recover_next = False

    def measured_hold(self, positions: dict[str, float], now: float) -> None:
        """Rebase the held command on fresh hardware feedback after a long gap."""
        now = _finite(now, "now")
        self.positions = self._check_positions(positions)
        self.velocities = {k: 0.0 for k in self.names}
        self._last_update_s = now
        self._last_sample_s = None
        self._last_direction = {k: 0 for k in self.names}
        self._awaiting_measured = False
        self._recover_next = True

    def zero_velocity(self) -> None:
        """Disarm feedforward without moving the target or changing failure time."""
        self.velocities = {k: 0.0 for k in self.names}
        self._last_sample_s = None
        self._last_direction = {k: 0 for k in self.names}

    def _result(self, reason: str, failure_duration_s: float = 0.0,
                needs_measured_hold: bool = False, max_step_rad: float = 0.0) -> dict:
        return dict(positions=self.positions.copy(), velocities=self.velocities.copy(),
                    needs_measured_hold=needs_measured_hold, reason=reason,
                    failure_duration_s=failure_duration_s, max_step_rad=max_step_rad)

    def update(self, candidate: dict[str, float], valid: bool,
               now: float, sample_s: float) -> dict:
        now = _finite(now, "now")
        try:
            sample_s = _finite(sample_s, "sample_s")
        except (TypeError, ValueError):
            valid = False
            sample_s = None
        try:
            target = self._check_positions(candidate) if valid else None
        except (TypeError, ValueError, KeyError):
            target = None
        if target is None or self._awaiting_measured:
            if self._failure_start_s is None:
                self._failure_start_s = now
            elapsed = max(0.0, now - self._failure_start_s)
            self.zero_velocity()
            self._recover_next = True
            # Retry a pending rebase until feedback is fresh. A one-shot request
            # traps the arm forever if the first feedback sample is unavailable.
            request_hold = elapsed >= self.failure_hold_s and (
                not self._hold_requested or self._awaiting_measured)
            if request_hold:
                self._hold_requested = True
                self._awaiting_measured = True
            self._last_update_s = now
            return self._result("persistent_hold" if elapsed >= self.failure_hold_s else "invalid_hold",
                                failure_duration_s=elapsed,
                                needs_measured_hold=request_hold)

        recovering = self._recover_next or self._failure_start_s is not None
        self._recover_next = False
        self._failure_start_s = None
        self._hold_requested = False
        actual_dt = self.period if self._last_update_s is None else max(0.0, now - self._last_update_s)
        self._last_update_s = now
        step_dt = min(actual_dt, self.period * 1.5)
        old = self.positions
        fraction = 1.0
        for k in self.names:
            distance = target[k] - old[k]
            if distance == 0:
                continue
            lo, hi = self.bounds[k]
            margin = (hi - old[k]) if distance > 0 else (old[k] - lo)
            speed_cap = min(self.velocity_limits[k],
                            math.sqrt(2 * self.acceleration_limits[k] * margin),
                            margin / .15)
            fraction = min(fraction, speed_cap * step_dt / abs(distance))
        fraction = max(0.0, min(1.0, fraction))
        self.positions = {k: old[k] + fraction * (target[k] - old[k]) for k in self.names}
        max_step = max(abs(self.positions[k] - old[k]) for k in self.names)

        source_dt = None if self._last_sample_s is None else sample_s - self._last_sample_s
        if source_dt is None or source_dt > 0:
            self._last_sample_s = sample_s
        new_velocity = {}
        new_direction = {}
        for k in self.names:
            step = self.positions[k] - old[k]
            direction = 1 if step > 1e-12 else (-1 if step < -1e-12 else 0)
            new_direction[k] = direction
            sign_reversal = direction and self._last_direction[k] and direction != self._last_direction[k]
            if (not self.feedforward or recovering or source_dt is None or
                    source_dt <= 0 or direction == 0 or sign_reversal):
                velocity = 0.0
            else:
                desired = .5 * step / source_dt
                previous = self.velocities[k]
                alpha = source_dt / (.05 + source_dt)
                filtered = previous + alpha * (desired - previous)
                # Use local monotonic time for acceleration. The sender clock
                # may jump, stall, or resume with an arbitrarily large delta.
                max_change = self.acceleration_limits[k] * actual_dt
                velocity = max(previous - max_change,
                               min(previous + max_change, filtered))
                lo, hi = self.bounds[k]
                margin = (hi - self.positions[k]) if direction > 0 else (self.positions[k] - lo)
                terminal_cap = min(.5 * self.velocity_limits[k],
                                   math.sqrt(2 * self.acceleration_limits[k] * margin),
                                   margin / .15)
                velocity = direction * min(terminal_cap, max(0.0, direction * velocity))
            new_velocity[k] = velocity
        self.velocities = new_velocity
        self._last_direction = new_direction
        reason = "recovering" if recovering else ("continuity_limited" if fraction < 1 - 1e-12 else "following")
        return self._result(reason, max_step_rad=max_step)


def head_angles(quaternion_xyzw):
    """ROS FLU headset quaternion -> (pitch down, yaw left), ignoring roll."""
    if len(quaternion_xyzw) != 4:
        raise ValueError('Expected a headset quaternion in xyzw order')
    x, y, z, w = [_finite(v, 'head quaternion') for v in quaternion_xyzw]
    norm = math.sqrt(x*x + y*y + z*z + w*w)
    if abs(norm - 1.0) > .02:
        raise ValueError('Head quaternion is not unit length')
    x, y, z, w = x/norm, y/norm, z/norm, w/norm
    # First column of the rotation matrix: the headset's forward (+X) direction.
    fx, fy, fz = 1 - 2*(y*y + z*z), 2*(x*y + w*z), 2*(x*z - w*y)
    horizontal = math.hypot(fx, fy)
    if horizontal < .1:
        raise ValueError('Head direction too close to vertical to determine yaw')
    return math.atan2(-fz, horizontal), math.atan2(fy, fx)


class NeckTargets:
    """A-relative head pitch/yaw, bounded by existing SDK limits and command speed.

    Translation is unused. Subtract facing angles in a gravity-aligned frame so
    tilting/rolling the headset at A does not mix left/right with up/down.
    """

    def __init__(self, quaternion_xyzw, neutral, bounds, speed=1.0, hz=30.0):
        self.reference = head_angles(quaternion_xyzw)
        self.bounds = tuple(tuple(_finite(v, 'neck limit') for v in pair) for pair in bounds)
        if len(self.bounds) != 2 or any(len(pair) != 2 or pair[0] >= pair[1] for pair in self.bounds):
            raise ValueError('Expected pitch/yaw bounds')
        self.speed = _finite(speed, 'neck speed')
        hz = _finite(hz, 'neck Hz')
        if self.speed <= 0 or hz <= 0:
            raise ValueError('Neck speed and frequency must be positive')
        self.period = 1 / hz
        self.reset_position(neutral)
        self.neutral = self.position

    def reset_position(self, position):
        position = tuple(_finite(v, 'neck position') for v in position)
        if len(position) != 2 or any(not lo <= v <= hi for v, (lo, hi) in zip(position, self.bounds)):
            raise ValueError('Neck position outside SDK limits')
        self.position = position

    def step(self, quaternion_xyzw, dt):
        angles = head_angles(quaternion_xyzw)
        pitch = self.neutral[0] + (angles[0] - self.reference[0])
        yaw_delta = angles[1] - self.reference[1]
        # Head yaw is positive left; this neck motor is positive right.
        yaw = self.neutral[1] - math.atan2(math.sin(yaw_delta), math.cos(yaw_delta))
        step = self.speed * min(max(0.0, _finite(dt, 'neck dt')), 1.5*self.period)
        target = [max(lo, min(hi, v)) for v, (lo, hi) in zip((pitch, yaw), self.bounds)]
        self.position = tuple(old + max(-step, min(step, new-old))
                              for old, new in zip(self.position, target))
        return self.position
