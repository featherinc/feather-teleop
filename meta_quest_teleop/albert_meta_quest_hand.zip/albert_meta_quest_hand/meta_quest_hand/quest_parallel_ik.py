"""One persistent process per arm. No robot SDK or motor commands run here."""
from __future__ import annotations

import math
import multiprocessing as mp
from multiprocessing.connection import wait
import signal
import time


def _arm_worker(connection, config):
    # Ctrl+C belongs to the notebook; it closes both children in its finally block.
    signal.signal(signal.SIGINT, signal.SIG_IGN)
    try:
        from quest_television_ik import ArmModel
        arm = ArmModel(**config)
        connection.send(('ready', None, None))
        while True:
            request = connection.recv()
            if request is None:
                break
            token, job = request
            try:
                arm.set_sdk_joint_limits(*job['limits'])
                candidate = arm.solve(job['position'], job['rotation'], job['previous_q'])
                connection.send((token, candidate, None))
            except Exception as error:
                connection.send((token, None, f'{type(error).__name__}: {error}'))
    except (EOFError, BrokenPipeError):
        pass
    except Exception as error:
        try:
            connection.send(('error', None, f'{type(error).__name__}: {error}'))
        except (OSError, EOFError):
            pass
    finally:
        connection.close()


class ParallelArmIK:
    """Dispatch both arms before waiting, with one outstanding job per arm.

    A timed-out job is never reused. While it finishes, that arm holds and the
    other can continue. The next call discards its reply and uses the latest pose.
    The original TeleVision solver uses a database seed on every job.
    The 30 ms parent wait is separate from the solver's 60-iteration limit.
    """

    def __init__(self, configs, wait_ms=30.0, startup_timeout_s=30.0,
                 worker_target=_arm_worker):
        if not math.isfinite(wait_ms) or wait_ms <= 0:
            raise ValueError('wait_ms must be positive and finite')
        self.wait_ms = float(wait_ms)
        self.workers = {}
        self.serial = 0
        self.closed = False
        self.last_errors = {}
        context = mp.get_context('spawn')  # Never fork the notebook's SDK/CAN threads.
        try:
            for side, config in configs.items():
                parent, child = context.Pipe()
                process = context.Process(target=worker_target, args=(child, config),
                                          name=f'quest-ik-{side}', daemon=True)
                self.workers[side] = dict(pipe=parent, process=process, pending=None, dead=False)
                try:
                    process.start()
                finally:
                    child.close()
            deadline = time.monotonic() + startup_timeout_s
            for side, state in self.workers.items():
                remaining = max(0.0, deadline - time.monotonic())
                if not state['pipe'].poll(remaining):
                    raise TimeoutError(f'{side} IK worker did not start')
                token, _, error = state['pipe'].recv()
                if token != 'ready' or error:
                    raise RuntimeError(f'{side} IK worker failed to start: {error}')
        except BaseException:
            self.close()
            raise

    def _read(self, side):
        state = self.workers[side]
        try:
            response = state['pipe'].recv()
            state['pending'] = None
            return response
        except (EOFError, OSError) as error:
            state['dead'] = True
            self.last_errors[side] = str(error) or 'IK worker exited'
            return None, None, 'IK worker exited'

    def solve(self, jobs):
        """Return {side: (candidate or None, failure reason or None)}."""
        if self.closed:
            raise RuntimeError('Parallel IK is closed; start it before control')
        self.serial += 1
        token = self.serial
        results, waiting = {}, {}
        deadline = time.monotonic() + self.wait_ms / 1000
        for side, job in jobs.items():
            state = self.workers[side]
            # Any leftover reply belongs to a previous tick/reference: discard it.
            if not state['dead'] and state['pipe'].poll():
                self._read(side)
            if state['dead'] or not state['process'].is_alive():
                results[side] = (None, 'ik_worker_error')
            elif state['pending'] is not None:
                results[side] = (None, 'ik_worker_busy')
            else:
                try:
                    state['pipe'].send((token, job))
                    state['pending'] = token
                    waiting[state['pipe']] = side
                except (OSError, EOFError) as error:
                    state['dead'] = True
                    self.last_errors[side] = str(error)
                    results[side] = (None, 'ik_worker_error')
        while waiting:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            for connection in wait(list(waiting), timeout=remaining):
                side = waiting.pop(connection)
                received_token, candidate, error = self._read(side)
                if error or received_token != token:
                    self.last_errors[side] = error or 'Unexpected IK request token'
                    results[side] = (None, 'ik_worker_error')
                else:
                    results[side] = (candidate, None)
        for side in waiting.values():
            results[side] = (None, 'ik_worker_timeout')
        return results

    def close(self):
        """Bounded cleanup, including a worker stuck in a numerical call."""
        if self.closed:
            return
        self.closed = True
        for state in self.workers.values():
            if state['process'].pid is not None:
                try:
                    state['pipe'].send(None)
                except (OSError, EOFError):
                    pass
        deadline = time.monotonic() + 0.3
        for state in self.workers.values():
            process = state['process']
            if process.pid is not None:
                process.join(max(0.0, deadline - time.monotonic()))
                if process.is_alive():
                    process.terminate()
                    process.join(timeout=0.3)
            state['pipe'].close()
