"""Receive Quest UDP poses, inputs, and timing. No motor commands.

Read top to bottom: packet layout -> decode -> receive/record -> display -> A/B state.
"""
from __future__ import annotations

from collections import deque
import math
import socket
import struct
import sys
import threading
import time

from quest_async_log import AsyncCSVWriter

HEADER = struct.Struct("<4sBBHQId")  # magic/version/kind/length/session/seq/client seconds
TIMING = struct.Struct("<ddd")      # RTT, server-minus-client offset, sync age (seconds)
POSE = struct.Struct("<II7f")       # flags, Unity trackingState, xyz, xyzw
MAGIC, VERSION, POSE_SIZE = b"QPOS", 9, 160
ANCHOR = struct.Struct("<7f")
CALIBRATED_POSE_SIZE = 248
CONTROLS = struct.Struct("<I5f")  # availability bits, L trigger/grip, R trigger/grip, torso Y
CONTROL_NAMES = ("left_trigger", "left_grip", "right_trigger", "right_grip", "torso_y")
CONTROL_POSE_SIZE = CALIBRATED_POSE_SIZE + CONTROLS.size
ARM_SWITCH = struct.Struct("<III")  # start counter, stop/home counter (legacy b_press name), run request
SWITCH_POSE_SIZE = CONTROL_POSE_SIZE + ARM_SWITCH.size
BASE_CONTROLS = struct.Struct("<I2f")
BASE_POSE_SIZE = SWITCH_POSE_SIZE + BASE_CONTROLS.size
TURN_CONTROL = struct.Struct("<If")  # availability bit, right joystick X
TURN_POSE_SIZE = BASE_POSE_SIZE + TURN_CONTROL.size
RECENTER = struct.Struct("<I")  # tracking-origin epoch, repeated in every packet
RECENTER_POSE_SIZE = TURN_POSE_SIZE + RECENTER.size
HAND_SELECT = struct.Struct("<III")  # v9: availability bits L/R, left Y mode, right B mode (v8: X)
HAND_POSE_SIZE = RECENTER_POSE_SIZE + HAND_SELECT.size
CONTROL_NAMES += ("base_x", "base_y", "base_turn")
NAMES = ("head", "left", "right")


def parse_packet(data):
    if len(data) < HEADER.size:
        raise ValueError("short header")
    magic, version, kind, size, session, seq, sent = HEADER.unpack_from(data)
    if magic != MAGIC or version not in (1, 2, 3, 4, 5, 6, 7, 8, 9) or size != len(data):
        raise ValueError("bad magic/version/length")
    if not math.isfinite(sent) or sent < 0:
        raise ValueError("invalid sender timestamp")
    packet = dict(session=session, seq=seq, sent_s=sent, kind=kind, version=version)
    if kind == 2 and size == HEADER.size:
        return packet
    if kind != 1 or size != {1: POSE_SIZE, 2: CALIBRATED_POSE_SIZE, 3: CONTROL_POSE_SIZE, 4: SWITCH_POSE_SIZE, 5: BASE_POSE_SIZE, 6: TURN_POSE_SIZE, 7: RECENTER_POSE_SIZE, 8: HAND_POSE_SIZE, 9: HAND_POSE_SIZE}[version]:
        raise ValueError("unexpected kind/size")
    rtt, offset, age = TIMING.unpack_from(data, HEADER.size)
    if not all(math.isfinite(v) for v in (rtt, offset, age)):
        raise ValueError("non-finite clock data")
    if not (rtt == -1 or 0 <= rtt <= 2) or not (age == -1 or age >= 0):
        raise ValueError("invalid RTT/sync age")
    packet.update(rtt_s=rtt, offset_s=offset, sync_age_s=age, poses={})
    for i, name in enumerate(NAMES):
        flags, state, *values = POSE.unpack_from(data, HEADER.size + TIMING.size + i * POSE.size)
        if flags & ~63 or state & ~63:
            raise ValueError("unknown tracking flags")
        if not all(math.isfinite(v) for v in values):
            raise ValueError("non-finite pose")
        if any(abs(v) > 1000 for v in values[:3]):
            raise ValueError("position outside 1000 m sanity bound")
        connected, tracked = bool(flags & 1), bool(flags & 2)
        valid = connected and tracked and bool(flags & 16) and bool(flags & 32)
        pv = valid and bool(flags & 4) and bool(state & 1)
        rv = valid and bool(flags & 8) and bool(state & 2)
        norm = math.sqrt(sum(v * v for v in values[3:]))
        if rv and abs(norm - 1) > 0.02:
            raise ValueError("tracked quaternion is not unit length")
        packet["poses"][name] = dict(
            position_m=values[:3], quaternion_xyzw=values[3:], flags=flags,
            tracking_state=state, connected=connected, tracked=tracked,
            position_valid=bool(pv), rotation_valid=bool(rv), quaternion_norm=norm,
        )
    packet["calibration_id"] = 0
    packet["anchors"] = {}
    if version >= 2:
        packet["calibration_id"] = struct.unpack_from("<I", data, POSE_SIZE)[0]
        for i, name in enumerate(NAMES):
            values = ANCHOR.unpack_from(data, POSE_SIZE + 4 + i * ANCHOR.size)
            if not all(math.isfinite(v) for v in values) or any(abs(v) > 1000 for v in values[:3]):
                raise ValueError("invalid calibration anchor")
            if abs(math.sqrt(sum(v*v for v in values[3:])) - 1) > 0.02:
                raise ValueError("calibration quaternion is not unit length")
            packet["anchors"][name] = dict(position_m=list(values[:3]), quaternion_xyzw=list(values[3:]))
    packet["controls"] = dict.fromkeys(CONTROL_NAMES)
    if version >= 3:
        available, *values = CONTROLS.unpack_from(data, CALIBRATED_POSE_SIZE)
        if available & ~31:
            raise ValueError("unknown input availability bits")
        for i, (name, value) in enumerate(zip(CONTROL_NAMES, values)):
            if not math.isfinite(value) or not (-1 if name == "torso_y" else 0) <= value <= 1:
                raise ValueError("invalid analog input")
            packet["controls"][name] = value if available & (1 << i) else None
    packet["arm_switch"] = None
    if version >= 4:
        a, b, requested = ARM_SWITCH.unpack_from(data, CONTROL_POSE_SIZE)
        if requested not in (0, 1):
            raise ValueError("invalid arm run request")
        packet["arm_switch"] = dict(a_press=a, b_press=b, run_requested=bool(requested))
    if version >= 5:
        available, x, y = BASE_CONTROLS.unpack_from(data, SWITCH_POSE_SIZE)
        if available & ~3 or not all(math.isfinite(v) and -1 <= v <= 1 for v in (x, y)):
            raise ValueError("invalid base joystick input")
        for bit, name, value in [(1, "base_x", x), (2, "base_y", y)]:
            packet["controls"][name] = value if available & bit else None
    if version >= 6:
        available, turn = TURN_CONTROL.unpack_from(data, BASE_POSE_SIZE)
        if available & ~1 or not math.isfinite(turn) or not -1 <= turn <= 1:
            raise ValueError("invalid base rotation input")
        packet["controls"]["base_turn"] = turn if available & 1 else None
    packet["recenter_id"] = RECENTER.unpack_from(data, TURN_POSE_SIZE)[0] if version >= 7 else 0
    packet["hand_buttons"] = None
    if version >= 8:
        available, left, right = HAND_SELECT.unpack_from(data, RECENTER_POSE_SIZE)
        if available & ~(3 if version >= 9 else 1):
            raise ValueError("invalid hand-button availability")
        packet["hand_buttons"] = dict(available=bool(available), left_select_press=left, right_select_press=right)
        if version >= 9:
            packet["hand_buttons"].update(left_available=bool(available & 1), right_available=bool(available & 2))
    return packet


POSE_COLUMNS = ('flags', 'tracking_state', 'position_valid', 'rotation_valid',
                'x', 'y', 'z', 'qx', 'qy', 'qz', 'qw')
CSV_FIELDS = ['receive_monotonic_s', 'sent_s', 'offset_s', 'sync_age_s',
              'session', 'seq', 'source', 'gap_ms', 'rtt_ms', 'one_way_estimate_ms']
CSV_FIELDS += [f'{name}_{column}' for name in NAMES for column in POSE_COLUMNS]
CSV_FIELDS += list(CONTROL_NAMES) + ['a_press', 'b_press', 'run_requested', 'calibration_id', 'recenter_id']
CSV_FIELDS += ['left_select_press', 'right_select_press']
KERNEL_TIMING_FIELDS = ['kernel_receive_unix_ns', 'python_receive_unix_ns',
                        'kernel_gap_ms', 'kernel_to_python_ms',
                        'quest_to_kernel_estimate_ms', 'timestamp_status']
CSV_FIELDS += KERNEL_TIMING_FIELDS


def enable_kernel_timestamps(sock):
    """Linux timestamps at network-stack arrival, before Python drains the socket.

    Try the time64 ABI first (Linux asm-generic/socket.h); older kernels can
    fall back to the native-long ABI. Windows keeps the original receive path.
    """
    if not sys.platform.startswith('linux') or not hasattr(sock, 'recvmsg'):
        return None
    for option, layout in ((64, '=qq'), (getattr(socket, 'SO_TIMESTAMPNS', 35), '@ll')):
        try:
            sock.setsockopt(socket.SOL_SOCKET, option, 1)
            return option, struct.Struct(layout)
        except OSError:
            pass
    return None


def kernel_timestamp_ns(ancillary, flags, timestamp_option):
    """Missing/truncated ancillary data is unknown, never a zero-wait sample."""
    if timestamp_option is None or flags & getattr(socket, 'MSG_CTRUNC', 8):
        return None
    option, layout = timestamp_option
    for level, kind, data in ancillary:
        if level == socket.SOL_SOCKET and kind == option and len(data) >= layout.size:
            seconds, nanos = layout.unpack_from(data)
            if seconds > 0 and 0 <= nanos < 1_000_000_000:
                return seconds * 1_000_000_000 + nanos
    return None


def packet_row(packet, peer):
    row = {name: packet[name] for name in ('session', 'seq', 'gap_ms', 'rtt_ms', 'one_way_estimate_ms')}
    row.update(receive_monotonic_s=packet['receive_s'], sent_s=packet.get('sent_s'),
               offset_s=packet.get('offset_s'), sync_age_s=packet.get('sync_age_s'),
               source=f'{peer[0]}:{peer[1]}')
    for name, pose in packet['poses'].items():
        values = [pose[k] for k in POSE_COLUMNS[:4]] + pose['position_m'] + pose['quaternion_xyzw']
        row.update(zip([f'{name}_{k}' for k in POSE_COLUMNS], values))
    row.update(packet['controls'])
    row.update(packet.get('arm_switch') or {})
    buttons = packet.get('hand_buttons') or {}
    row.update({key: buttons.get(key) for key in ('left_select_press', 'right_select_press')})
    row.update(calibration_id=packet.get('calibration_id', 0), recenter_id=packet.get('recenter_id', 0))
    row.update({key: packet.get(key) for key in KERNEL_TIMING_FIELDS})
    return row


def distribution(values):
    values = sorted(values)
    if not values:
        return None
    return {"min": values[0], "mean": sum(values) / len(values),
            "p95": values[math.ceil(0.95 * len(values)) - 1], "max": values[-1]}


class PoseReceiver:
    """Background reception keeps notebook rendering out of the 30 Hz socket loop."""
    def __init__(self, host="10.42.0.1", port=5005):
        self.host, self.port = host, port
        self.sock = None
        self.thread = None
        self.stop_event = threading.Event()
        self.lock = threading.Lock()
        self.error = None
        self.bad_packets = self.foreign_packets = self.pings = 0
        self.last_rejection = None
        self.session = None
        self.peer = None
        self.retired = deque(maxlen=32)
        self.latest = None
        self.log_writer = None
        self.timestamp_option = None
        self.timestamp_status = 'not_started'
        self._wall_minus_mono_ns = None
        self._clock_unstable_until = 0.0
        self._reset_statistics()
        # phase 0 is a monitor; live notebooks explicitly publish READY/ACTIVE/HOMING/FROZEN.
        self.control_state = (0, None, 0, 0)

    def set_control_state(self, phase, state=None):
        """Acknowledge only input the main control loop has consumed, never pending A."""
        phases = dict(monitor=0, ready=1, active=2, homing=3, frozen=4)
        packet = (state or {}).get('latest') or {}
        switch = packet.get('arm_switch') or {}
        with self.lock:
            self.control_state = (phases[phase], packet.get('session'),
                                  switch.get('a_press', 0), switch.get('b_press', 0))

    def _control_reply(self, packet):
        # Called under lock after accepting a new pose. SDK calls never run here.
        if packet['version'] < 9:
            return None
        phase, session, start, stop = self.control_state
        if phase == 0:
            start, stop = packet['arm_switch']['a_press'], packet['arm_switch']['b_press']
        elif session != packet['session'] and phase not in (3, 4):
            return None  # Wait for the notebook to consume a newly opened app session.
        return (HEADER.pack(MAGIC, packet['version'], 4, 40, packet['session'], packet['seq'], packet['sent_s'])
                + struct.pack('<III', phase, start, stop))

    def _reset_statistics(self):
        self.first = self.highest = None
        self.unique = self.duplicates = self.reordered = self.too_late = 0
        self.forward_gaps = self.long_gaps = 0
        self.seen = set()
        self.seen_order = deque()
        self.arrivals = deque(maxlen=1800)
        self.gaps = deque(maxlen=1800)
        self.rtts = deque(maxlen=1800)
        self.latencies = deque(maxlen=1800)
        self.last_receive = None
        self.last_kernel_ns = None
        self.latest = None

    def start(self, log_path=None):
        if self.thread and self.thread.is_alive():
            raise RuntimeError("receiver already started")
        if self.thread is not None:
            raise RuntimeError("create a new receiver after stop()")
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 1024 * 1024)
            self.timestamp_option = enable_kernel_timestamps(self.sock)
            self.timestamp_status = 'enabled' if self.timestamp_option else 'unavailable'
            self.sock.bind((self.host, self.port))
            self.sock.settimeout(0.1)
            if log_path:
                self.log_writer = AsyncCSVWriter(log_path, CSV_FIELDS)
            self.thread = threading.Thread(target=self._run, name="quest-pose-udp", daemon=True)
            self.thread.start()
            return self
        except Exception:
            self.sock.close()
            self.sock = None
            if self.log_writer:
                self.log_writer.close()
            raise

    def _run(self):
        try:
            while not self.stop_event.is_set():
                try:
                    if self.timestamp_option:
                        data, ancillary, flags, peer = self.sock.recvmsg(2048, socket.CMSG_SPACE(32))
                    else:
                        data, peer = self.sock.recvfrom(2048)
                        ancillary, flags = [], 0
                except socket.timeout:
                    continue
                received = time.monotonic()
                received_wall_ns = time.time_ns()
                kernel_ns = kernel_timestamp_ns(ancillary, flags, self.timestamp_option)
                try:
                    packet = parse_packet(data)
                except (ValueError, struct.error) as exc:
                    with self.lock:
                        self.bad_packets += 1
                        self.last_rejection = str(exc)
                    continue
                if packet["kind"] == 2:
                    # NTP-style four-timestamp exchange; no wall-clock synchronization needed.
                    reply = HEADER.pack(MAGIC, packet["version"], 3, 44, packet["session"], packet["seq"], packet["sent_s"])
                    reply += struct.pack("<dd", received, time.monotonic())
                    self.sock.sendto(reply, peer)
                    with self.lock:
                        self.pings += 1
                    continue
                with self.lock:
                    self._accept(packet, peer, received, kernel_ns, received_wall_ns)
                    reply = self._control_reply(packet) if self.latest is packet else None
                if reply is not None:
                    try:
                        self.sock.sendto(reply, peer)
                    except OSError:
                        pass  # Status repeats with the next pose; a lost reply must not stop reception.
        except Exception as exc:
            if not self.stop_event.is_set():
                with self.lock:
                    self.error = repr(exc)

    def _accept(self, packet, peer, received, kernel_ns=None, received_wall_ns=None):
        session = packet["session"]
        if (peer, session) in self.retired:
            self.foreign_packets += 1
            return
        if self.session is not None and (peer != self.peer or session != self.session):
            if peer[0] != self.peer[0] and self.last_receive is not None and received - self.last_receive < 2:
                self.foreign_packets += 1
                return
            self.retired.append((self.peer, self.session))
            self._reset_statistics()
        self.session, self.peer = session, peer
        seq = packet["seq"]
        if self.highest is None:
            extended = seq
            self.first = seq
        else:
            delta = ((seq - (self.highest & 0xFFFFFFFF) + 2**31) % 2**32) - 2**31
            extended = self.highest + delta
            if extended < self.first or extended <= self.highest - 8192:
                self.too_late += 1
                return
        if extended in self.seen:
            self.duplicates += 1
            return
        self.unique += 1
        self.seen.add(extended)
        self.seen_order.append(extended)
        if len(self.seen_order) > 8192:
            self.seen.remove(self.seen_order.popleft())
        newest = self.highest is None or extended > self.highest
        if not newest:
            self.reordered += 1
        elif self.highest is not None:
            self.forward_gaps += max(0, extended - self.highest - 1)
        if newest:
            self.highest = extended
        gap = None if self.last_receive is None else (received - self.last_receive) * 1000
        if gap is not None:
            self.gaps.append(gap)
            self.long_gaps += gap > 50
        self.last_receive = received
        self.arrivals.append(received)
        synced = packet["rtt_s"] >= 0 and 0 <= packet["sync_age_s"] <= 15
        rtt = packet["rtt_s"] * 1000 if synced else None
        latency = (received - packet["sent_s"] - packet["offset_s"]) * 1000 if synced else None
        if synced:
            self.rtts.append(rtt)
            self.latencies.append(latency)
        packet.update(receive_s=received, gap_ms=gap, rtt_ms=rtt, one_way_estimate_ms=latency)
        self._add_kernel_timing(packet, received, kernel_ns, received_wall_ns)
        if newest:
            self.latest = packet
        if self.log_writer:
            self.log_writer.writerow(packet_row(packet, peer))

    def _add_kernel_timing(self, packet, received, kernel_ns, received_wall_ns):
        # Kernel timestamps use CLOCK_REALTIME; control freshness still uses
        # monotonic time. These new measurements are diagnostic only.
        status = 'missing' if self.timestamp_option else self.timestamp_status
        wait_ms = kernel_gap_ms = before_kernel_ms = None
        if received_wall_ns is not None:
            offset_ns = received_wall_ns - int(received * 1e9)
            if (self._wall_minus_mono_ns is not None
                    and abs(offset_ns - self._wall_minus_mono_ns) > 5_000_000):
                # Suppress derived values while queued packets may straddle a wall-clock step.
                self._clock_unstable_until = received + 1.0
            self._wall_minus_mono_ns = offset_ns
        if kernel_ns is not None and received_wall_ns is not None:
            if received < self._clock_unstable_until:
                status = 'clock_step'
            elif kernel_ns > received_wall_ns:
                status = 'invalid_clock'
            else:
                status = 'ok'
                wait_ms = (received_wall_ns - kernel_ns) / 1e6
                if self.last_kernel_ns is not None:
                    kernel_gap_ms = (kernel_ns - self.last_kernel_ns) / 1e6
                if packet['one_way_estimate_ms'] is not None:
                    before_kernel_ms = packet['one_way_estimate_ms'] - wait_ms
        self.last_kernel_ns = kernel_ns if status == 'ok' else None
        packet.update(kernel_receive_unix_ns=kernel_ns,
                      python_receive_unix_ns=received_wall_ns,
                      kernel_gap_ms=kernel_gap_ms, kernel_to_python_ms=wait_ms,
                      quest_to_kernel_estimate_ms=before_kernel_ms, timestamp_status=status)

    def _log_state(self):
        stats = self.log_writer.stats() if self.log_writer else None
        return dict(log_queued=stats['queued'] if stats else 0,
                    log_written=stats['written'] if stats else 0,
                    log_dropped=stats['dropped'] if stats else 0,
                    log_error=stats['error'] if stats else None,
                    kernel_timestamping=self.timestamp_status)

    def latest_snapshot(self):
        """Cheap control-loop view; no rate or percentile work under receive lock."""
        with self.lock:
            error, peer, session = self.error, self.peer, self.session
            last_receive, latest = self.last_receive, self.latest
        now = time.monotonic()
        age = None if last_receive is None else now - last_receive
        state = "error" if error else "waiting" if age is None else "stale" if age > 0.5 else "receiving"
        return dict(status=state, error=error, bind=f"{self.host}:{self.port}",
                    peer=peer, session=session, packet_age_s=age, latest=latest,
                    **self._log_state())

    def snapshot(self):
        with self.lock:
            copied = dict(error=self.error, peer=self.peer, session=self.session,
                          last_receive=self.last_receive, latest=self.latest,
                          first=self.first, highest=self.highest, unique=self.unique,
                          forward_gaps=self.forward_gaps, reordered=self.reordered,
                          duplicates=self.duplicates, too_late=self.too_late,
                          long_gaps=self.long_gaps, bad_packets=self.bad_packets,
                          last_rejection=self.last_rejection, foreign_packets=self.foreign_packets,
                          pings=self.pings, arrivals=tuple(self.arrivals),
                          gaps=tuple(self.gaps), rtts=tuple(self.rtts),
                          latencies=tuple(self.latencies))
        now = time.monotonic()
        recent = [t for t in copied['arrivals'] if t >= now - 5]
        hz = (len(recent) - 1) / (recent[-1] - recent[0]) if len(recent) > 1 and recent[-1] > recent[0] else 0
        expected = 0 if copied['first'] is None else copied['highest'] - copied['first'] + 1
        missing = expected - copied['unique']
        age = None if copied['last_receive'] is None else now - copied['last_receive']
        state = "error" if copied['error'] else "waiting" if age is None else "stale" if age > 0.5 else "receiving"
        return dict(status=state, error=copied['error'], bind=f"{self.host}:{self.port}",
                    peer=copied['peer'], session=copied['session'], packet_age_s=age,
                    unique_packets=copied['unique'], receive_hz=hz if state == "receiving" else 0,
                    expected_since_first=expected, unresolved_gaps=missing,
                    loss_percent=100 * missing / expected if expected else 0,
                    forward_gap_count=copied['forward_gaps'], reordered=copied['reordered'],
                    duplicates=copied['duplicates'], too_late=copied['too_late'],
                    gaps_over_50ms=copied['long_gaps'], malformed=copied['bad_packets'],
                    last_rejection=copied['last_rejection'], foreign=copied['foreign_packets'],
                    pings=copied['pings'], gap_ms=distribution(copied['gaps']),
                    rtt_ms=distribution(copied['rtts']),
                    one_way_estimate_ms=distribution(copied['latencies']),
                    latest=copied['latest'], **self._log_state())

    def stop(self):
        self.stop_event.set()
        if self.thread:
            self.thread.join(timeout=2)
        if self.sock:
            self.sock.close()
        if self.log_writer:
            self.log_writer.close()


def format_snapshot(snapshot):
    latest = snapshot["latest"]
    lines = [f"{snapshot['status'].upper()} | {snapshot['bind']} | peer={snapshot['peer']}",
             f"Hz={snapshot['receive_hz']:.2f} unique={snapshot['unique_packets']} seq={latest['seq'] if latest else '-'} "
             f"missing={snapshot['unresolved_gaps']} ({snapshot['loss_percent']:.2f}%) "
             f"duplicate={snapshot['duplicates']} reordered={snapshot['reordered']} malformed={snapshot['malformed']}"]
    for key in ("gap_ms", "rtt_ms", "one_way_estimate_ms"):
        stats = snapshot[key]
        lines.append(f"{key}: " + ("waiting for data/sync" if stats is None else
            f"mean={stats['mean']:.2f} p95={stats['p95']:.2f} max={stats['max']:.2f}"))
    if snapshot.get('log_dropped') or snapshot.get('log_error'):
        lines.append(f"CSV logging: written={snapshot['log_written']} "
                     f"dropped={snapshot['log_dropped']} error={snapshot['log_error'] or '-'}")
    if latest:
        lines.append(f"A calibration: {latest.get('calibration_id', 0)} (0 = press A to set home)")
        lines.append(format_controls(latest))
        if latest.get('arm_switch') is not None:
            switch = latest['arm_switch']
            lines.append(f"Arm request: {'ON' if switch['run_requested'] else 'OFF'} | A={switch['a_press']} B={switch['b_press']}")
        for name, pose in latest["poses"].items():
            p = ", ".join(f"{v:+.4f}" for v in pose["position_m"])
            q = ", ".join(f"{v:+.4f}" for v in pose["quaternion_xyzw"])
            lines.append(f"{name:5} p(m)=[{p}] q(xyzw)=[{q}] "
                         f"valid(P/R)={pose['position_valid']}/{pose['rotation_valid']} "
                         f"tracked={pose['tracked']} flags=0x{pose['flags']:02x} state=0x{pose['tracking_state']:02x}")
    if snapshot["error"]:
        lines.append("ERROR: " + snapshot["error"])
    lines.append("POSE TELEMETRY ONLY. One-way latency is an offset estimate, not ground truth.")
    return "\n".join(lines)


def format_controls(packet):
    controls = packet.get("controls", {})
    return "Inputs: " + " | ".join(
        f"{name}=" + ("unavailable" if controls.get(name) is None else f"{controls[name]:+.3f}")
        for name in CONTROL_NAMES)


class ArmRunGate:
    """Require a fresh A after startup, B, lost connection, or a new Quest session."""
    def __init__(self, timeout_s=0.3):
        self.timeout_s = timeout_s
        self.session = None
        self.a = self.b = 0
        self.recenter_id = 0
        self.running = False
        self.reason = 'Waiting for a fresh A'

    def disarm(self, reason):
        self.running = False
        self.reason = reason

    def update(self, snapshot, now=None):
        now = time.monotonic() if now is None else now
        packet = snapshot.get('latest')
        switch = packet.get('arm_switch') if packet else None
        fresh = (snapshot.get('status') == 'receiving' and packet is not None
                 and 0 <= now - packet.get('receive_s', -math.inf) <= self.timeout_s)
        if not fresh or switch is None or not packet['poses']['right']['connected']:
            self.session = None
            self.disarm('Quest unavailable or old app; run cancelled, waiting for a fresh A')
            return False
        a, b = switch['a_press'], switch['b_press']
        origin_changed = packet.get('recenter_id', 0) != self.recenter_id
        self.recenter_id = packet.get('recenter_id', 0)
        if packet['session'] != self.session:
            self.session, self.a, self.b = packet['session'], a, b
            self.disarm('New connection: press A to enable')
        elif b != self.b or not switch['run_requested']:
            self.a, self.b = a, b
            self.disarm('Stop request: home/disable requested, waiting for A')
        elif origin_changed and self.running:
            self.a = a
            self.disarm('Quest recentered during control: frozen; A to home, READY, then fresh A')
        elif a != self.a:
            self.a, self.b = a, b
            self.running = True
            self.reason = 'A: run requested'
        return self.running
