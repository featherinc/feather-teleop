# Math extracted from the user's TeleVision teleop.py. No robot/camera imports.
from __future__ import annotations
import numpy as np
import pinocchio as pin
from scipy.spatial import KDTree
from scipy.spatial.transform import Rotation
from typing import Tuple
SOURCE_PATH = '/home/feather/Workspace/featheros/TeleVision/teleop/teleop.py'
SOURCE_SHA256 = 'b5fa2ed2554490394e06884253fee15ad9fccbb8ccbce64bc271fe98a87240a3'
CORE_AST_SHA256 = 'ca1f41ea0f6848ddd58fc2aa6cd69a3969d34b748662cf598c6fdf16236364d0'
def get_arm_velocity_and_config_indices(model: pin.Model, joint_names: list[str]) -> tuple[np.ndarray, np.ndarray]:
    velocity_indices, config_indices = ([], [])
    for name in joint_names:
        jid = model.getJointId(name)
        if jid >= model.njoints:
            raise ValueError(f'Joint {name!r} not found in URDF')
        velocity_indices.extend(range(model.joints[jid].idx_v, model.joints[jid].idx_v + model.joints[jid].nv))
        config_indices.extend(range(model.joints[jid].idx_q, model.joints[jid].idx_q + model.joints[jid].nq))
    return (np.array(velocity_indices), np.array(config_indices))

def pose_to_feature_vector(ee_position, ee_rotation, *, position_weight: float=1.0, orientation_weight: float=1.0) -> np.ndarray:
    """Convert EE pose to a 6D vector for KDTree search: [x, y, z, rx, ry, rz]."""
    position = np.asarray(ee_position, dtype=float).reshape(3)
    rotation = np.asarray(ee_rotation, dtype=float).reshape(3, 3)
    rotvec = Rotation.from_matrix(rotation).as_rotvec()
    return np.concatenate([position_weight * position, orientation_weight * rotvec])

class IKDatabase:
    """KDTree over EE poses for warm-starting IK from nearby database entries."""

    def __init__(self, datapoints, *, position_weight: float=1.0, orientation_weight: float=1.0, mirror_direction: bool=False, mirror_axis: int=1, joint_mirror_signs: np.ndarray | None=None):
        if not datapoints:
            raise ValueError('datapoints must be non-empty')
        if mirror_direction:
            datapoints = self._mirror_datapoints(datapoints, mirror_axis, joint_mirror_signs)
        self.datapoints = datapoints
        self.position_weight = position_weight
        self.orientation_weight = orientation_weight
        self.mirror_direction = mirror_direction
        self.joint_positions = np.asarray([dp[0] for dp in datapoints], dtype=float)
        self.ee_positions = np.asarray([dp[1] for dp in datapoints], dtype=float)
        self.ee_rotations = np.asarray([dp[2] for dp in datapoints], dtype=float)
        features = np.array([pose_to_feature_vector(pos, rot, position_weight=position_weight, orientation_weight=orientation_weight) for pos, rot in zip(self.ee_positions, self.ee_rotations)])
        self._tree = KDTree(features)

    @staticmethod
    def _mirror_datapoints(datapoints, mirror_axis: int, joint_mirror_signs: np.ndarray | None):
        """Mirror datapoints from one arm to the other across a symmetry plane.

        For a humanoid, the left and right arms are mirror images across the sagittal plane (normal to
        the y-axis, hence the default mirror_axis=1). Each datapoint (joint_positions, ee_position,
        ee_rotation) is reflected so that data gathered from one arm can drive the other:

        - ee_position: reflected across the plane (M @ p), where M flips the mirror axis.
        - ee_rotation: transformed as M @ R @ M, which keeps it a proper (right-handed) rotation while
          producing the mirror-image orientation.
        - joint_positions: scaled element-wise by joint_mirror_signs (+1/-1 per joint). The correct
          signs are robot/URDF-specific (they depend on each joint's axis convention between the two
          arms). This robot's joints all flip, so when joint_mirror_signs is None every joint is
          negated (equivalent to all -1).
        """
        mirror_matrix = np.eye(3)
        mirror_matrix[mirror_axis, mirror_axis] = -1.0
        signs = None if joint_mirror_signs is None else np.asarray(joint_mirror_signs, dtype=float)
        mirrored = []
        for dp in datapoints:
            joint_positions = np.asarray(dp[0], dtype=float)
            ee_position = np.asarray(dp[1], dtype=float).reshape(3)
            ee_rotation = np.asarray(dp[2], dtype=float).reshape(3, 3)
            joint_positions = -joint_positions if signs is None else joint_positions * signs
            mirrored_position = mirror_matrix @ ee_position
            mirrored_rotation = mirror_matrix @ ee_rotation @ mirror_matrix
            mirrored.append((joint_positions, mirrored_position, mirrored_rotation))
        return mirrored

    def query(self, ee_position, ee_rotation, k: int=5) -> dict:
        k = min(k, len(self.datapoints))
        query_feat = pose_to_feature_vector(ee_position, ee_rotation, position_weight=self.position_weight, orientation_weight=self.orientation_weight)
        distances, indices = self._tree.query(query_feat, k=k)
        indices = np.atleast_1d(indices)
        distances = np.atleast_1d(distances)
        return {'indices': indices, 'distances': distances, 'joint_positions': self.joint_positions[indices], 'ee_positions': self.ee_positions[indices], 'ee_rotations': self.ee_rotations[indices]}

    def weighted_joint_seed(self, ee_position, ee_rotation, k: int) -> np.ndarray:
        """Distance-weighted average of k nearest joint configurations."""
        neighbors = self.query(ee_position, ee_rotation, k=k)
        distances = neighbors['distances']
        weights = 1.0 / (distances + 1e-09)
        weights /= weights.sum()
        return np.average(neighbors['joint_positions'], axis=0, weights=weights)

class TeleVisionIK:

    def _clip_q_to_limits(self, arm: ArmIKData, q: np.ndarray) -> np.ndarray:
        q = q.copy()
        q[arm.arm_q_ids] = np.clip(q[arm.arm_q_ids], arm.q_lower, arm.q_upper)
        return q

    def _compute_single_arm_ik(self, arm: ArmIKData, ik_db: IKDatabase, target_pos: np.ndarray, target_rot: np.ndarray) -> Tuple[np.ndarray, float, float, int]:
        """Iterative IK via damped-least-squares Jacobian updates."""
        q = arm.neutral_q.copy()
        q[arm.arm_q_ids] = ik_db.weighted_joint_seed(target_pos, target_rot, k=IK_N_KNN)
        q = self._clip_q_to_limits(arm, q)
        for i in range(IK_MAX_ITER):
            pin.forwardKinematics(arm.model, arm.data, q)
            pin.updateFramePlacements(arm.model, arm.data)
            pin.computeJointJacobians(arm.model, arm.data, q)
            oMf = arm.data.oMf[arm.ee_frame_id]
            err_pos = target_pos - oMf.translation
            err_rot = pin.log3(target_rot @ oMf.rotation.T)
            error = np.concatenate([err_pos, err_rot])
            err_pos_mm = np.linalg.norm(err_pos) * 1000.0
            J_arm = pin.getFrameJacobian(arm.model, arm.data, arm.ee_frame_id, pin.LOCAL_WORLD_ALIGNED)[:, arm.arm_v_ids]
            err_norm = np.linalg.norm(error)
            if err_norm < IK_TOLERANCE_NORM and err_pos_mm < IK_TOLERANCE_POS_MM:
                return (q[arm.arm_q_ids], err_norm, err_pos_mm, i)
            arm.dq.fill(0.0)
            arm.dq[arm.arm_v_ids] = J_arm.T @ np.linalg.solve(J_arm @ J_arm.T + IK_DAMPING_EYE, error) * IK_DT
            q = self._clip_q_to_limits(arm, pin.integrate(arm.model, q, arm.dq))
        return (q[arm.arm_q_ids], err_norm, err_pos_mm, i)
IK_N_KNN = 5
IK_MAX_ITER = 60
IK_TOLERANCE_NORM = 0.1
IK_TOLERANCE_POS_MM = 3.0
IK_DT = 0.2
IK_DAMPING_EYE = 1e-06 * np.eye(6)
IK_DB_POSITION_WEIGHT = 1.0
IK_DB_ORIENTATION_WEIGHT = 0.2
