"""Compatibility at the Quest notebook's SDK boundary; importing sends no commands.

The Teensy SDK reports Robstride feedback timestamps in monotonic seconds.
The prior CAN SDK exposed PARAM_SET and reported monotonic nanoseconds.
The current notebook uses native body velocities: translations in m/s and yaw
in rad/s. LegacyNavigation remains available to callers using wheel commands.
"""

from __future__ import annotations

import ast
import inspect
import math
from numbers import Real
from pathlib import Path
from types import MappingProxyType


def motor_position_param(motor):
    """Return the position-feedback code for a recognized SDK generation."""
    if hasattr(motor, 'PARAMS'):
        try:
            return motor.PARAMS.FB_POSITION
        except AttributeError as error:
            raise RuntimeError('Unsupported SDK motor: PARAMS.FB_POSITION is required') from error
    try:
        return motor.PARAM_SET.mech_pos
    except AttributeError as error:
        raise RuntimeError('Unsupported SDK motor: no recognized position-feedback API') from error


def motor_feedback_age_s(motor, now):
    """Feedback age in seconds; missing/non-finite timestamps are never fresh.

    Units follow the position API, rather than guessing from timestamp magnitude.
    Negative ages remain negative so callers reject future feedback explicitly.
    """
    now = _finite(now, 'monotonic time')
    param = motor_position_param(motor)
    stamp = motor.telemetry.get_latest_timestamp(param, default=None)
    if stamp is None:
        return math.inf
    try:
        stamp = float(stamp)
    except (TypeError, ValueError):
        return math.inf
    if not math.isfinite(stamp):
        return math.inf
    if hasattr(motor, 'PARAMS'):
        return now - stamp
    # Retain the legacy subtraction order. Scaling a fresh nanosecond stamp
    # to seconds first can round it just beyond now and reject valid feedback.
    return (now * 1e9 - stamp) * 1e-9


def _finite(value, label):
    value = float(value)
    if not math.isfinite(value):
        raise ValueError(f'{label} must be finite')
    return value


def _number(node):
    """Evaluate only numeric config syntax, without importing or executing it."""
    if isinstance(node, ast.Constant) and type(node.value) in (int, float):
        return _finite(node.value, 'rotation value')
    if isinstance(node, ast.Name) and node.id in ('pi', 'tau'):
        return getattr(math, node.id)
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
        return _number(node.operand) * (-1 if isinstance(node.op, ast.USub) else 1)
    if isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Add, ast.Sub, ast.Mult, ast.Div)):
        left, right = _number(node.left), _number(node.right)
        operations = {ast.Add: lambda: left + right, ast.Sub: lambda: left - right,
                      ast.Mult: lambda: left * right, ast.Div: lambda: left / right}
        return _finite(operations[type(node.op)](), 'rotation value')
    if (isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
            and node.func.id == 'deg2rad' and len(node.args) == 1 and not node.keywords):
        return math.radians(_number(node.args[0]))
    raise ValueError('Rotation maps must contain literal numbers, pi/tau, or deg2rad')


def _dictionary(node):
    if not isinstance(node, ast.Dict):
        raise ValueError('Rotation maps must be literal dictionaries')
    result = {}
    for key, value in zip(node.keys, node.values):
        if not isinstance(key, ast.Constant) or not isinstance(key.value, str) or key.value in result:
            raise ValueError('Rotation map keys must be unique literal motor names')
        result[key.value] = _number(value)
    return result


def read_navigation_rotation_maps(config_path):
    """Read the user's existing rotation maps without executing their config."""
    tree = ast.parse(Path(config_path).read_text())
    declarations = [node.value for node in tree.body if isinstance(node, ast.Assign)
                    and any(isinstance(target, ast.Name) and target.id == 'navigation_system_config'
                            for target in node.targets)]
    if len(declarations) != 1 or not isinstance(declarations[0], ast.Call):
        raise ValueError('Expected one navigation_system_config constructor')
    keywords = {kw.arg: kw.value for kw in declarations[0].keywords}
    try:
        return (_dictionary(keywords['rotate_in_place_angles']),
                _dictionary(keywords['rotate_in_place_directions']))
    except KeyError as error:
        raise ValueError('Preserved rotate_in_place_angles and directions are required') from error


class _NavigationConfig:
    def __init__(self, config, angles, directions):
        self._config = config
        self.rotate_in_place_angles = MappingProxyType(dict(angles))
        self.rotate_in_place_directions = MappingProxyType(dict(directions))

    def __getattr__(self, name):
        return getattr(self._config, name)


def _require_signature(method, label, *args, **kwargs):
    if not callable(method):
        raise RuntimeError(f'Unsupported SDK navigation: {label} is required')
    try:
        inspect.signature(method).bind(*args, **kwargs)
    except (TypeError, ValueError) as error:
        raise RuntimeError(f'Unsupported SDK navigation signature: {label}') from error


def validate_base_navigation(navigation, *, linear_speed, yaw_speed, deadzone,
                             strict_directions=True):
    """Check native base APIs and resolved geometry without sending commands.

    Body-speed settings and wheel-motor limits use different units. The native
    SDK converts and scales wheel speeds, so this check does not compare them.
    The public strict-directions getter must match the requested mode. Its
    setter is checked without calling it. Configuration is read without
    changing it or loading any SDK, URDF, transport or motor.
    """
    def number(value, label):
        if isinstance(value, bool) or not isinstance(value, Real):
            raise ValueError(f'{label} must be a finite number')
        try:
            return _finite(value, label)
        except (TypeError, ValueError, OverflowError) as error:
            raise ValueError(f'{label} must be a finite number') from error

    def sequence(value, size, label):
        try:
            valid = not isinstance(value, (str, bytes, dict)) and len(value) == size
        except TypeError:
            valid = False
        if not valid:
            raise ValueError(f'{label} must contain exactly {size} entries')
        return value

    if type(strict_directions) is not bool:
        raise ValueError('Base strict directions must be a bool')
    for value, label in ((linear_speed, 'Base linear speed'), (yaw_speed, 'Base yaw speed')):
        if number(value, label) <= 0:
            raise ValueError(f'{label} must be positive')
    if not 0 <= number(deadzone, 'Base deadzone') < 1:
        raise ValueError('Base deadzone must be within [0, 1)')

    _require_signature(getattr(navigation, 'set_velocity', None), 'set_velocity', 0.0, 0.0, 0.0)
    _require_signature(getattr(navigation, 'set_strict_directions', None),
                       'set_strict_directions', strict_directions)
    getter = getattr(navigation, 'get_strict_directions', None)
    _require_signature(getter, 'get_strict_directions')
    actual = getter()
    if type(actual) is not bool:
        raise RuntimeError('SDK navigation strict-directions getter must return a bool')
    if actual is not strict_directions:
        raise RuntimeError(f'SDK navigation strict directions must match the requested base mode ({strict_directions})')

    config = getattr(navigation, 'config', None)
    if number(getattr(config, 'wheel_radius', None), 'Navigation wheel radius') <= 0:
        raise ValueError('Navigation wheel radius must be positive and resolved before base control')
    positions = sequence(getattr(config, 'wheel_positions', None), 3, 'Navigation wheel positions')
    for index, position in enumerate(positions):
        sequence(position, 2, f'Wheel position {index}')
        for coordinate in position:
            number(coordinate, f'Wheel position {index} coordinate')

    drives = sequence(getattr(navigation, 'drive_motors', None), 3, 'Navigation drive motors')
    turns = sequence(getattr(navigation, 'turning_motors', None), 3, 'Navigation turning motors')
    for motors, label in ((drives, 'drive'), (turns, 'turning')):
        names = [getattr(getattr(motor, 'config', None), 'name', None) for motor in motors]
        if any(not isinstance(name, str) or not name for name in names) or len(set(names)) != 3:
            raise ValueError(f'Expected three uniquely named navigation {label} motors')
    for turn, drive in zip(turns, drives):
        limits = sequence(getattr(turn.config, 'angle_range', None), 2,
                          f'Steering range for {turn.config.name}')
        low, high = (number(value, f'Steering range for {turn.config.name}') for value in limits)
        if not low < high or low > -math.pi / 2 or high < math.pi / 2:
            raise ValueError(f'Steering range for {turn.config.name} must cover [-pi/2, pi/2]')
        if number(getattr(drive.config, 'max_velocity', None), f'Drive limit for {drive.config.name}') <= 0:
            raise ValueError(f'Drive limit for {drive.config.name} must be positive')


class LegacyNavigation:
    """Retain Quest's old wheel commands on the branch's navigation SDK.

    Complete legacy public APIs pass through unchanged. The Teensy integration
    uses its locked, limit-checked wheel-target helper, including strict steering
    gating. No body-speed conversion or replacement rotation geometry is used.
    """

    def __init__(self, navigation, *, rotate_in_place_angles=None,
                 rotate_in_place_directions=None, config_path=None):
        self._navigation = navigation
        self._legacy = all(callable(getattr(navigation, name, None)) for name in
                           ('set_speed', 'orient_and_move', 'rotate_in_place'))
        if self._legacy:
            _require_signature(navigation.set_speed, 'set_speed', 0.0)
            _require_signature(navigation.orient_and_move, 'orient_and_move', 0.0, 0.0)
            _require_signature(navigation.rotate_in_place, 'rotate_in_place', 0.0)
            self.config = navigation.config
            return

        helper = getattr(navigation, '_set_new_angles_and_speeds', None)
        _require_signature(helper, '_set_new_angles_and_speeds', angles={}, velocities={})
        if getattr(navigation, '_strict_directions', None) is not True:
            raise RuntimeError('SDK navigation must use strict steering directions for legacy Quest control')
        try:
            turning = {motor.config.name: motor for motor in navigation.turning_motors}
            drives = {motor.config.name: motor for motor in navigation.drive_motors}
            current_angles = navigation._target_angles
        except AttributeError as error:
            raise RuntimeError('Unsupported SDK navigation wheel-target state') from error
        if len(turning) != 3 or len(drives) != 3 or set(current_angles) != set(turning):
            raise RuntimeError('Expected three uniquely named steering and drive motors')

        if config_path is not None:
            saved_angles, saved_directions = read_navigation_rotation_maps(config_path)
        else:
            saved_angles = getattr(navigation.config, 'rotate_in_place_angles', None)
            saved_directions = getattr(navigation.config, 'rotate_in_place_directions', None)
        angles = saved_angles if rotate_in_place_angles is None else rotate_in_place_angles
        directions = saved_directions if rotate_in_place_directions is None else rotate_in_place_directions
        if angles is None or directions is None:
            raise ValueError('Supply the preserved user rotation maps or their config_path')
        if set(angles) != set(turning) or set(directions) != set(drives):
            raise ValueError('Rotation maps must match the three configured steering and drive names')
        angles = {name: _finite(value, 'rotation angle') for name, value in angles.items()}
        for name, value in angles.items():
            low, high = turning[name].config.angle_range
            if not low <= value <= high:
                raise ValueError(f'Rotation angle exceeds SDK limits: {name}')
        if any(type(value) is bool or value not in (-1, 1) for value in directions.values()):
            raise ValueError('Rotation drive directions must be +1 or -1')
        self.config = _NavigationConfig(navigation.config, angles, directions)

    def __getattr__(self, name):
        return getattr(self._navigation, name)

    def _dispatch(self, angles, velocities):
        # The old SDK kept the existing heading for opposite +/-90-degree
        # commands and reversed drive speed instead of sweeping the steering.
        current = dict(self._navigation._target_angles)
        close = lambda values, target: all(abs(value - target) < .003 for value in values.values())
        if ((close(angles, math.pi / 2) and close(current, -math.pi / 2))
                or (close(angles, -math.pi / 2) and close(current, math.pi / 2))):
            angles, velocities = current, {name: -value for name, value in velocities.items()}
        self._navigation._set_new_angles_and_speeds(angles=angles, velocities=velocities)

    def orient_and_move(self, angle, motor_velocity):
        if self._legacy:
            return self._navigation.orient_and_move(angle, motor_velocity)
        angle, speed = _finite(angle, 'steering angle'), _finite(motor_velocity, 'wheel speed')
        if not -math.pi <= angle <= math.pi:
            raise ValueError('Steering angle must be within [-pi, pi]')
        self._dispatch({motor.config.name: angle for motor in self.turning_motors},
                       {motor.config.name: speed for motor in self.drive_motors})

    def rotate_in_place(self, motor_velocity):
        if self._legacy:
            return self._navigation.rotate_in_place(motor_velocity)
        speed = _finite(motor_velocity, 'wheel speed')
        self._dispatch(dict(self.config.rotate_in_place_angles),
                       {motor.config.name: speed * self.config.rotate_in_place_directions[motor.config.name]
                        for motor in self.drive_motors})

    def set_speed(self, motor_velocity):
        if self._legacy:
            return self._navigation.set_speed(motor_velocity)
        speed = _finite(motor_velocity, 'wheel speed')
        self._dispatch(dict(self._navigation._target_angles),
                       {motor.config.name: speed for motor in self.drive_motors})
