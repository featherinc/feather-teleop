"""Quest front trigger -> absolute RealHand positions. No SDK initialization."""
import math


HAND_MODES = ('whole hand', 'pinch')


def read_hand_position(hand):
    """Read six position bytes through FeatherSDK without moving the hand."""
    if callable(getattr(hand, 'read_positions', None)):
        values = list(hand.read_positions())
        if len(values) != 6 or any(type(v) is not int or not 0 <= v <= 255 for v in values):
            raise RuntimeError('No valid RealHand position feedback')
        return values
    value = hand.read_param(hand.PARAM_SET.position, block=True)
    if value is None or not 0 <= int(value) < 1 << 56:
        raise RuntimeError('No valid RealHand position feedback')
    # Six big-endian position bytes followed by one CAN padding byte.
    return list(int(value).to_bytes(7, 'big')[:6])


class HandTargets:
    """Independent hand modes and trigger positions, called by the 30 Hz worker."""
    def __init__(self, positions, release_threshold=0.1,
                 pinch_open_position=(255, 25, 255, 255, 255, 255),
                 pinch_closed_position=(100, 25, 125, 255, 255, 255)):
        if not math.isfinite(release_threshold) or not 0 <= release_threshold < 1:
            raise ValueError('Hand release threshold must be between 0 and 1')
        if set(positions) - {'left', 'right'}:
            raise ValueError('Hand sides must be left/right')
        for values in (*positions.values(), pinch_open_position, pinch_closed_position):
            if len(values) != 6 or not all(math.isfinite(v) and 0 <= v <= 255 for v in values):
                raise ValueError('Hand positions must contain six values from 0 to 255')
        self.targets = {side: list(map(round, values)) for side, values in positions.items()}
        self.sent = {side: values[:] for side, values in self.targets.items()}
        self.selection = {side: 0 for side in positions}
        self.release_required = {side: True for side in positions}
        self.release_threshold = release_threshold
        self.pinch_open_position = tuple(pinch_open_position)
        self.pinch_closed_position = tuple(pinch_closed_position)
        self.session = None

    def hold(self):
        # Stop/stale input holds the last request; it does not count as a release.
        for side in self.targets:
            self.release_required[side] = True
            self.targets[side] = self.sent[side][:]

    def mark_sent(self, side, position):
        self.sent[side] = position[:]

    def status(self):
        return {f'{side}_hand_selection': HAND_MODES[index] for side, index in self.selection.items()}

    def step(self, packet, running):
        """Front trigger interpolates between open and closed targets for each mode.

        Whole hand uses SDK 255 -> 0; pinch uses the configured six-joint poses.

        Y selects left, B selects right: even counter = whole hand, odd = pinch.
        A toggle, tracking origin, and freshness are checked by the notebook gate.
        Release the front trigger after start/recovery or a mode switch to re-arm.
        The side grip is unused. SDK set_speed() controls actual motor travel.
        """
        buttons = packet.get('hand_buttons') if packet else None
        if not buttons or packet.get('version', 0) < 9:
            self.hold()
            return {}
        if packet['session'] != self.session:
            self.session = packet['session']
            self.hold()
        commands = {}
        for side in self.targets:
            selected = buttons[side + '_select_press'] % 2
            if selected != self.selection[side]:
                self.selection[side] = selected
                self.release_required[side] = True
            trigger = packet.get('controls', {}).get(side + '_trigger')
            pose = packet.get('poses', {}).get(side, {})
            tracked = all(pose.get(k) for k in ('connected', 'tracked', 'position_valid', 'rotation_valid'))
            if (not running or not tracked or not buttons.get(side + '_available')
                    or trigger is None or not math.isfinite(trigger) or not 0 <= trigger <= 1):
                self.release_required[side] = True
                self.targets[side] = self.sent[side][:]
                continue
            if trigger <= self.release_threshold:
                self.release_required[side] = False
            target = self.sent[side][:]
            if not self.release_required[side]:
                close_position = round(255. * (1. - trigger))
                if selected == 0:
                    target = [close_position] * 6
                else:
                    target = [round(opened + trigger * (closed - opened))
                              for opened, closed in zip(self.pinch_open_position, self.pinch_closed_position)]
            elif selected == 1:
                # While waiting for trigger release, open the other three fingers.
                target[3:] = list(self.pinch_open_position[3:])
            self.targets[side] = target
            if target != self.sent[side]:
                commands[side] = target[:]
        return commands
