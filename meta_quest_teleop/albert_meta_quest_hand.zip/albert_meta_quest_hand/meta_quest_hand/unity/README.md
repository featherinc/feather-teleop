# Same Quest app for hands and grippers

`Record_CSV_BLE_NEW.cs` adds left-controller Y/X press counters to the existing sender.
It keeps the existing controller poses, inputs, A/B and recenter logic, 30 Hz target,
and Android low-latency Wi-Fi request.

The pose packet is QPOS **v8, 320 bytes**. Pings remain 28 bytes. Updated receivers in
`quest_teleoperation`, `quest_teleoperation_improved`, and `meta_quest_hand` accept it;
they also accept v1-v7. Original/improved gripper controls ignore the selection counters.

Build with Unity **6000.3.6f1**. Replace the existing same-class script, keeping its
`.meta` file and scene reference. Do not import a second copy of the class.
The app remains **Quest AGX Pose**, package **com.FeatherRobotic.QuestPoseTest**.
The `QuestAGXPoseHands.apk` build updates that same pose app and does not replace the BLE app.

Stop live teleoperation before updating the APK. After deployment, restart/reload the
receiving notebook so the new parser is loaded. A still starts from READY.
