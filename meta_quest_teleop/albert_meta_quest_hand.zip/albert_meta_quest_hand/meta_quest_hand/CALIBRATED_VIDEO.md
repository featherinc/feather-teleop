# Native ZED stereo video

Run notebook section 2a again after an update. The accepted A press starts video
while RUNNING; B, stale input, and stopping control restore passthrough.
Right-thumbstick click manually switches between stereo and 2D.

The camera supplies its normal rectified left and right color images. ZED depth
mode is NONE, runtime depth and fill mode are off, and the custom depth renderer
is removed. Only normal image sizing, RGB conversion, JPEG encoding and display
projection remain. There is no depth-dependent switching or screen resizing.

Camera intrinsics set the fixed field of view. The native camera baseline is
preserved: no attempt is made to turn it into the viewer's eye spacing, so stereo
depth may appear exaggerated. This is a head-following camera view.

The same APK works with both teleoperation folders. TCP protocol v3 carries the
original stereo pair and intrinsics; older APKs receive 2D. Pose/control UDP and
the camera RUNNING heartbeat remain separate from image processing.
