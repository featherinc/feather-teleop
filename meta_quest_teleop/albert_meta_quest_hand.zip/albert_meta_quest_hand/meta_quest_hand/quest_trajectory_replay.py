"""Read recorded IK and SDK configuration. Motor commands are visible in the replay notebook."""
from __future__ import annotations

import copy
import ast
import csv
import json
import math
from pathlib import Path

def read_motor_specs(arm_config_path, sides=('left', 'right')):
    """Read this project's literal motor declarations without importing the SDK."""
    if not sides or len(set(sides)) != len(sides) or set(sides) - {'left', 'right'}:
        raise ValueError('Select left, right, or both arms')
    tree = ast.parse(Path(arm_config_path).read_text())
    helper = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == '_arm_motor_config')
    defaults = {arg.arg: value for arg, value in zip(helper.args.args[-len(helper.args.defaults):], helper.args.defaults)}
    specs = {side: {} for side in sides}
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call) or not isinstance(node.func, ast.Name) or node.func.id != '_arm_motor_config':
            continue
        kw = {item.arg: item.value for item in node.keywords}
        name = ast.literal_eval(kw['name'])
        side = next((side for side in sides if name.endswith('_'+side)), None)
        if side is None:
            continue
        joint = ast.literal_eval(kw['urdf_joint_name'])
        angle_range = kw['angle_range']
        if isinstance(angle_range, ast.Call) and isinstance(angle_range.func, ast.Name) and angle_range.func.id == 'NumericRange':
            bounds = angle_range.args
        elif isinstance(angle_range, (ast.Tuple, ast.List)):
            bounds = angle_range.elts
        else:
            raise ValueError('Expected literal NumericRange or tuple angle bounds in arm config')
        if len(bounds) != 2:
            raise ValueError('Expected two arm angle bounds')
        limits = []
        for value in bounds:
            if not isinstance(value, ast.Call) or not isinstance(value.func, ast.Name) or value.func.id != 'deg2rad':
                raise ValueError('Expected literal deg2rad bounds in arm config')
            limits.append(math.radians(ast.literal_eval(value.args[0])))
        lower, upper = limits
        if not math.isfinite(lower) or not math.isfinite(upper) or lower >= upper:
            raise ValueError('Arm angle bounds must be finite and increasing')
        if joint in specs[side]:
            raise ValueError('Duplicate URDF joint in arm configuration')
        specs[side][joint] = dict(name=name, lower=lower, upper=upper,
            velocity=float(ast.literal_eval(kw.get('max_velocity', defaults['max_velocity']))),
            acceleration=float(ast.literal_eval(kw.get('max_acceleration', defaults['max_acceleration']))))
    if any(len(motors) != 7 for motors in specs.values()):
        raise ValueError('Expected seven motor declarations per selected arm')
    return specs


def load_replay_config(config_path, urdf_path, *, include_torso=False, include_navigation=False, include_neck=False,
                       hand_sides=(), sdk_generation='native', comms_config_path=None):
    """Select native branch configs without editing files or starting hardware.

    Older SDK installations can explicitly select ``sdk_generation='legacy'``.
    Native L6 hand configs are read separately by ``read_hand_configs`` because
    this branch's unfinished RealHand class cannot construct the existing L6s.
    Native transport comes from the installed system config unless an explicit
    ``comms_config_path`` is supplied for offline fixtures or portability.
    """
    if sdk_generation == 'native':
        from quest_sdk_config import load_branch_config
        options = dict(include_torso=include_torso, include_navigation=include_navigation,
                       include_neck=include_neck, hand_sides=hand_sides)
        if comms_config_path is not None:
            options['comms_config_path'] = comms_config_path
        return load_branch_config(config_path, urdf_path, **options)
    if sdk_generation != 'legacy':
        raise ValueError("sdk_generation must be 'native' or 'legacy'")
    if comms_config_path is not None:
        raise ValueError('comms_config_path is only supported with the native SDK loader')
    return _load_legacy_replay_config(config_path, urdf_path, include_torso=include_torso,
                                     include_navigation=include_navigation, include_neck=include_neck,
                                     hand_sides=hand_sides)


def _load_legacy_replay_config(config_path, urdf_path, *, include_torso=False,
                               include_navigation=False, include_neck=False, hand_sides=()):
    """Retain the older SDK loader and subsystem selection for explicit callers."""
    from feathersdk.configs import load_configs

    config = load_configs(Path(config_path).resolve(strict=True))
    if include_torso and config.torso_system_config is None:
        raise ValueError('The SDK config has no torso system')
    if include_navigation and config.navigation_system_config is None:
        raise ValueError('The SDK config has no navigation system')
    if set(hand_sides) - {'left', 'right'}:
        raise ValueError('Hand sides must be left/right')
    manipulation = None
    if hand_sides:
        manipulation = config.manipulation_system_config
        if manipulation is None or any(getattr(manipulation, side + '_hand', None) is None for side in hand_sides):
            raise ValueError('Configure the selected RealHands in configs/systems/manipulation_system_conf.py')
        manipulation = manipulation.model_copy(update={side + '_hand': getattr(manipulation, side + '_hand')
            if side in hand_sides else None for side in ('left', 'right')}, deep=True)
    if include_neck and config.neck_system_config is None:
        raise ValueError('The SDK config has no neck system')
    return config.model_copy(update={
        'urdf_path': Path(urdf_path).resolve(strict=True),
        'set_signal_handlers': False,
        'torso_system_config': config.torso_system_config if include_torso else None,
        'neck_system_config': config.neck_system_config if include_neck else None,
        'navigation_system_config': config.navigation_system_config if include_navigation else None,
        'manipulation_system_config': manipulation,
        'battery_service_config': None,
    }, deep=True)


def load_trajectory(folder, specs):
    """Map CSV joint columns using calibration metadata; hold failed/out-of-limit samples."""
    folder = Path(folder)
    calibrations = json.loads((folder / 'calibration.json').read_text())
    if len(calibrations) != 1:
        raise ValueError('Replay requires one A calibration; split recordings containing recalibration')
    calibration = calibrations[0]
    names, current = {}, {}
    for side, motors in specs.items():
        home = calibration['homes'][side]
        names[side] = home['joint_names']
        if len(names[side]) != 7 or set(names[side]) != set(motors):
            raise ValueError(f'{side}: recorded URDF joints do not match the SDK config')
        current[side] = {motors[j]['name']: float(q)
                         for j, q in zip(names[side], home['joints_rad'])}
        if len(current[side]) != 7 or not all(math.isfinite(q) for q in current[side].values()):
            raise ValueError(f'{side}: invalid recorded home')
        if any(not m['lower'] <= current[side][m['name']] <= m['upper'] for m in motors.values()):
            raise ValueError(f'{side}: recorded home exceeds SDK limits')
    grouped = {}
    counts = {side: dict(accepted=0, ik_or_tracking_hold=0, limit_hold=0, missing_hold=0)
              for side in specs}
    with (folder / 'comparison.csv').open(newline='') as stream:
        last_time = -math.inf
        for row in csv.DictReader(stream):
            if row['side'] not in specs:
                continue
            t = float(row['elapsed_s'])
            if not math.isfinite(t) or t < 0 or t < last_time:
                raise ValueError('CSV timestamps must be finite, nonnegative, and ordered')
            last_time = t
            if int(row['calibration_id']) != calibration['calibration_id']:
                raise ValueError('CSV and calibration.json calibration IDs differ')
            rows = grouped.setdefault(t, {})
            if row['side'] in rows:
                raise ValueError('Duplicate arm sample at the same timestamp')
            rows[row['side']] = row
    if not grouped:
        raise ValueError('No samples for the selected arms')
    frames = []
    t0 = next(iter(grouped))
    for t, rows in grouped.items():
        reasons = {}
        for side, motors in specs.items():
            row = rows.get(side)
            reason = 'missing_hold'
            if row:
                reason = 'ik_or_tracking_hold'
                if row['converged'].lower() == 'true' and row['tracking_valid'].lower() == 'true':
                    q = [float(row[f'joint_{i+1}_rad']) for i in range(7)]
                    if not all(math.isfinite(v) for v in q):
                        raise ValueError('Non-finite converged IK sample')
                    reason = 'limit_hold'
                    if all(motors[j]['lower'] <= v <= motors[j]['upper'] for j, v in zip(names[side], q)):
                        current[side] = {motors[j]['name']: v for j, v in zip(names[side], q)}
                        reason = 'accepted'
            reasons[side] = reason
            counts[side][reason] += 1
        frames.append(dict(time_s=t-t0, positions=copy.deepcopy(current), reasons=reasons))
    if any(c['accepted'] == 0 for c in counts.values()):
        raise ValueError('A selected arm has no valid in-limit IK targets')
    max_step = max(abs(frame['positions'][side][name]-previous['positions'][side][name])
        for previous, frame in zip(frames, frames[1:]) for side in specs
        for name in frame['positions'][side]) if len(frames) > 1 else 0.0
    return dict(frames=frames, specs=specs, source=str(folder.resolve()),
                summary=dict(samples=len(frames), duration_s=frames[-1]['time_s'],
                             arms=counts, max_target_step_rad=max_step))
