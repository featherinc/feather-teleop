# Meta Quest RealHand teleoperation

Open **meta_quest_hand.ipynb** on the AGX. This is a separate copy of improved teleop,
with concurrent arm IK, torso, base, A/B, recenter handling, and the existing timing logs.
It uses L6 RealHands through the existing FeatherSDK Teensy CAN transport. SDK and URDF files are unchanged.

## Controls

| Input | Action |
| --- | --- |
| Left controller Y | Switch left hand between whole hand and pinch |
| Right controller B | Switch right hand between whole hand and pinch |
| Each controller's front trigger | Set its hand's closure: 0 open, 0.5 half closed, 1 closed |
| Left / right side grip | Torso down / up; equal squeeze or release stops |
| Right A | Start from READY; press again to home/disable arms |
| Left joystick | Base translation in m/s |
| Right joystick X / Y | Base yaw in rad/s / unused |

Base control uses the initialized `robot.navigation_system` directly through
`nav.set_velocity(vx, vy, omega)`. Translation is in m/s and yaw is in rad/s:
positive X is forward, positive Y is left, and positive yaw is counterclockwise.
`BASE_LINEAR_SPEED=0.2` sets maximum joystick translation speed;
`BASE_YAW_SPEED=1.0` sets maximum requested joystick yaw speed. The SDK applies
its configured velocity and acceleration limits.

Left-stick forward requests positive `vx`; left-stick right requests negative
`vy`. Right-stick right requests negative `omega` (clockwise). Rotation keeps
priority over translation. `BASE_DEADZONE=0.1`, radial gain and diagonal
normalization remain. Mode changes, A transitions, stale input, session/recenter
holds and cleanup request `nav.set_velocity(0, 0, 0)`.

`BASE_STRICT_DIRECTIONS=False` enables continuous steering through the native
`set_strict_directions()` API. Initialization requests zero velocity before
applying this setting. The base worker refreshes valid velocity commands at
30 Hz even while the sticks remain unchanged, so the SDK recomputes drive speed
as the wheels turn. Each wheel's drive speed is attenuated by
`max(0, cos(steering_error))`; a large heading change can still briefly produce
near-zero drive at 90 degrees. Continuous mode has no fixed one-second pause
or wait for every steering motor to align. Velocity caps remain 0.2 m/s and
1.0 rad/s.

Set `BASE_STRICT_DIRECTIONS=True` to use the SDK's wait for all steering motors
to reach their targets; command refresh remains active. Stop the live cell
before rerunning base initialization to apply a changed setting.

Whole-hand mode controls all six channels. Pinch interpolates both hands from
`[255,25,255,255,255,255]` at trigger 0 to `[85,25,150,255,255,255]` at trigger 1.
Half squeeze requests `[170,25,202,255,255,255]`. Thumb sideways stays at 25, and
middle/ring/pinky stay open. The endpoints are visible as `PINCH_OPEN_POSITION`
and `PINCH_CLOSED_POSITION` in notebook section 1. Left/right modes are independent and
spoken by the Quest. Release the front trigger once after start/recovery or a
mode change to arm control. Side grips control only the torso; front triggers keep their hand behavior.
Torso speed is `TORSO_SPEED * (right_grip - left_grip)` outside the existing `DEADZONE`.
Full right grip raises at 100 mm/s; full left lowers at 100 mm/s. Equal squeeze, release,
missing grip input, A-stop, stale packets, and recenter stop torso motion through the existing
SDK `update_velocity(0)` hold. Its 50–600 mm limits and 30 Hz worker remain active.
The old right-joystick Y value remains in UDP/logs for compatibility but no longer controls the torso.

## Run

1. Stop the other teleop notebook. Use a fresh kernel when switching folders.
2. Install the updated **Quest AGX Pose** APK, connect to JetsonCamNet, and open it.
   The same app works with this folder and the compatibility-updated original/improved
   gripper folders. Run one receiver at a time; all use 10.42.0.1:5005.
3. Review section 1, including base translation in m/s and yaw in rad/s. Check `RUN_HARDWARE` before running cells that command the robot. Individual left/right hand switches exclude unused hands before SDK initialization.
4. Run the numbered setup cells. Section 3 initializes the selected SDK systems;
   torso initialization can run the SDK's existing calibration. Section 3a first reads hand
   positions to discover their CAN buses, then sets torque/speed without opening or closing the hands.
5. Start section 7, wait for READY, hold your neutral controller pose, and press A.

Existing configs specify L6 hands at **left 0x28**, **right 0x27**. L6 replies may
use the same ID or ID + 8: **0x28/0x30** for left and **0x27/0x2f** for right.
Discovery binds the observed reply ID. The adapter performs no hand calibration sweep.

SDK channel order: `[thumb_flexion, thumb_abduction, index, middle, ring, pinky]`.
SDK position **255 means open**, **0 means closed**. Front-trigger closure is
linear: whole hand uses `round(255 * (1 - trigger))`; pinch uses
`round(open + trigger * (closed - open))` for each joint. Holding a partial squeeze
holds that target; releasing opens the hand. The worker runs at 30 Hz and sends
changed targets through `set_position()`. `HAND_SPEED` controls physical motor
travel via SDK `set_speed()`; the former `HAND_POSITION_RATE` integration is
removed. `HAND_TORQUE` and `HAND_SPEED` are SDK values from 0 to 255, not Nm/rad/s.

`HAND_RELEASE_THRESHOLD` is used only to arm control after start/recovery/mode
changes; it does not rescale the trigger's position mapping. Stopping, stale
input, lost tracking, or recenter holds the last submitted targets. Missing
input does not open the hand. No RealHand SDK disable behavior is changed.

## Files

- `meta_quest_hand.ipynb`: main notebook, with visible `set_torque`, `set_speed`, and `set_position` calls.
- `quest_hand.py`: whole-hand/pinch modes, front-trigger position mapping, stop holds, and SDK feedback unpacking.
- `quest_pose_receiver.py`: QPOS v9 plus older packet parsing; hand modes use the current Y/B counters.
- Other Python helpers: original TeleVision IK plus existing improved control/logging, plus configuration selection for hands.
- `unity/Record_CSV_BLE_NEW.cs`: compatible sender source; same Quest AGX Pose app/package.

The existing input and timing CSVs also record selection counters and selected channels/targets.
`LOG_MOTION_DETAILS=True` still adds full arm comparison/feedback CSVs. No extra live log files
are added for hands. This trigger change uses the existing Quest APK and UDP fields. Tests use robot doubles and loopback UDP; no physical hand run is implied.

Run offline checks in the existing Pinocchio environment:

```bash
PYTHONPATH=.:tests /home/feather/Workspace/featheros/TeleVision/.env-quest/bin/python -m unittest \
  test_hand_control test_hand_protocol test_hand_config test_improved_ik test_improved_control \
  test_improved_receiver test_improved_notebook test_quest_recenter test_parallel_ik test_quest_notebook
```

## Teensy SDK branch compatibility (2026-10-01)

This folder supports `albert_teensy/9/30/26` at `1a625ba97efc916a2deb659582b3e471d0bc0e2d`.
Use `/home/feather/archiconda3/envs/feathersdk_v1/bin/python`; system Python imports an older
installed SDK. Restart the notebook kernel before using the migrated setup.

`quest_sdk_config.py` builds native branch config types from the existing Albert declarations
without rewriting them. It retains motor IDs, calibration, ranges, directions, gains and motion
limits. Gains are checked against each motor model's actual CAN encoding limits; KP 300 remains
300. Hands attach separately because the branch's native RealHand class is unfinished.

`quest_sdk_hands.py` keeps L6 explicitly. Historical FeatherOS L6 driver commits `21823d981`
and `e54e69b9d` support replies on the configured ID and ID + 8. Saved CAN data on this Feather
shows left-hand position queries on ID `0x28` answered on `0x28` with DLC 7. The adapter accepts
those two exact L6 reply IDs during discovery, then binds the single observed bus/reply ID.
O6 remains explicit and accepts only its configured reply ID. Standard one-byte register queries
and register plus six-byte writes remain unchanged. Discovery uses position queries only and
rejects missing or ambiguous responders, including both reply IDs on one bus, and configured
CAN ID conflicts before permitting writes. Feedback comes
from the existing Teensy candump stream, with exact bus/ID/register/DLC/direction and timestamp
checks. Existing logging and other SDK responses are retained. The firmware still records L6
replies as unhandled EZMotion diagnostics; offline checks cannot establish physical reliability.

`quest_sdk_compat.py` selects native `PARAMS.FB_POSITION` and monotonic seconds for arm/neck
feedback. The notebook calls the native base velocity API directly. SDK navigation uses its
wheel radii and positions, steering folding, drive reversal, motor directions and native
steering/drive motor velocity and acceleration limits. `LegacyNavigation` remains available for existing
external callers; retired rotation fields are omitted from native configuration. Torso commands remain
mm/s; neck commands remain radians. A/B, tracking/recenter holds, IK and hand trigger/pinch
behavior retain the current notebook values.

One branch behavior differs: native arm homing hardcodes a 0.05 rad tolerance, replacing the
retired local 0.2 rad setting, so homing may wait longer. Retired compliance fields are inactive
in these local configs. Obsolete transport tuning fields have no corresponding native feature.

Offline verification must use the guarded runners, rather than executing the notebook. SDK
initialization can calibrate/move actuators and build/flash firmware; `RUN_HARDWARE=False` also
does not disable the separate camera-start cell.

From this folder:

```bash
PY=/home/feather/archiconda3/envs/feathersdk_v1/bin/python
REPO=/home/feather/Workspace/featheros
$PY -B tests/run_offline.py . --tests --report /tmp/quest-offline.json
$PY -B tests/check_sdk_contract.py . --sdk-src "$REPO/feathersdk/src" \
  --config-loader quest_sdk_config:load_branch_config \
  --hand-config-loader quest_sdk_config:read_hand_configs --standalone-hands \
  --hand-type quest_sdk_hands:RealHandCan \
  --report /tmp/quest-sdk-contract.json
$PY -B tests/run_native_config_tests.py . --sdk-src "$REPO/feathersdk/src" \
  --report /tmp/quest-native-config.json
```

The suite's native model tests are gated; use the guarded native runner for their config-only
checks. These checks construct no robot or transport, send no CAN frames, and start no camera.

## Original TeleVision IK restoration (2026-09-28)

Both arms use the solver extracted from `/home/feather/Workspace/featheros/TeleVision/teleop/teleop.py`. Each solve queries five database neighbors and performs up to 60 iterations, with damping 1e-6, step 0.2, position tolerance 3 mm and combined residual tolerance 0.1. There is no 12 ms solver cutoff. The database is still built from this robot's URDF. Final FK verification and SDK/URDF joint bounds remain. Concurrent workers retain the 30 ms reply limit and stale-result rejection. A/B offsets, recenter rules, motion limits, invalid-IK holds, and hand/gripper/torso/base controls are unchanged.

Stop the live cell and restart the notebook kernel before running setup again. No Unity/APK change is required for this solver restoration.

## ZED X video

Section 2a prepares the camera with `quest_video.py`; section 9 stops it. Video appears only after A is accepted and control reaches RUNNING. READY, settling, B/homing and stopped/stale control show the existing passthrough view. The camera stays ready in the background; no image payload is sent while paused. A local nonblocking RUNNING heartbeat expires after 300 ms; it uses no disk writes in control ticks. This camera-only process reuses `TeleVision/teleop/quest_zed.py` and its capture worker in `TeleVision/.env-quest`. No robot SDK is imported by the video process. The AGX uses the ZED Link Duo driver matched to its RT kernel/L4T version and ZED SDK 5.3.1 for L4T 36.4. The Duo is powered by the AGX developer kit. Power off and unplug the AGX before installing/reseating the card or camera cable; detection alone does not confirm valid image capture.

Install the Quest AGX Pose APK with `QuestZedVideo.cs`. The app uses the same AGX address as pose UDP, with TCP port 5006 for stereo JPEGs (640x360 per eye, up to 30 fps). It requests the latest stereo pair, keeps only the newest pending frame, and hides video older than 500 ms. Network/decode costs can reduce display rate; this is not a measured 30 fps guarantee. Pose packets, A/B, recenter, voice selection and hand/gripper controls are unchanged. Video loss does not itself change robot control state; use B to stop/home if visibility is lost.

No video recording is enabled. One status JSON and one overwritten diagnostic log live under `.runtime/`. Only run one camera stream across the two folders. The camera process also exits if its notebook kernel dies.

## Headset → neck

`CONTROL_NECK=True` includes the existing FeatherSDK neck system; `False` excludes it before initialization.
No Quest APK update is needed. A accepted from READY records head direction and current measured neck pose
(`NECK_NEUTRAL=None`). Head turns change yaw and looking up/down changes pitch; roll and translation are ignored.
`neck.go_to(pitch=..., yaw=..., block=False)` runs at a 30 Hz target independently of arm IK.
`NECK_SPEED=1.0` rad/s bounds commanded steps and SDK speed; the existing SDK angle/acceleration limits remain.
B/lost head tracking/stale input/recenter hold the neck, retaining torque; only the arms home/disable on B.
SDK neck initialization can calibrate, enable, and move toward zero before A. Pitch zero is its bottom pose.
Optionally position the neck with the SDK before section 7. References are recorded in calibration.json.
Restart the notebook kernel and rerun setup after installing this update. Physical direction/response is not yet tested.

## ZED 2i video

Section 2a now selects USB ZED 2i serial **35928961** (`model='zed-2i'`).
It uses the existing Quest AGX Pose APK and TCP 5006 protocol: 640 x 360 JPEGs per eye,
latest frame only, with the existing A/RUNNING and B/passthrough behavior. Raw camera
capture is HD720 at 30 FPS with depth disabled. ZED X remains selectable explicitly.
Use one camera process/notebook at a time. No robot commands run in the video process.

Current hotspot-only setup (2026-09-29):
- Built-in `wlP1p1s0` hosts **JetsonCamNet**, **5 GHz channel 48**, address **10.42.0.1**.
- Connect both PC and Quest to JetsonCamNet. SSH with `ssh feather@10.42.0.1`; the Quest app receiver address stays `10.42.0.1`.
- The USB Wi-Fi adapter is intentionally disconnected. `Feather-IOS-USB` autoconnect is disabled; `10.1.10.62` is no longer in use.
- This hotspot currently has no internet uplink. Stay connected if Windows or Quest reports no internet.
- The hotspot profile still autoconnects. To start it manually on the AGX, run `sudo nmcli connection up JetsonCamNet-5GHz`.

## Capture dependencies on the Teensy branch (2026-10-01)

The video server requires both `TeleVision/teleop/quest_zed.py` and
`TeleVision/teleop/quest_zed_worker.py`, plus `TeleVision/.env-quest/bin/python`.
The two sources omitted by this branch were restored for the current native stereo API.
They publish the original rectified left/right pair and calibration together, with depth,
depth filling and viewer-IPD reprojection disabled. Capture and JPEG processing remain in
the separate camera processes; robot SDK imports are excluded.

`VideoStream.start()` now checks these files and the selected interpreter before creating
logs, sockets or processes. If switching notebook kernels, stop the old notebook's video
cell first: only one server can use TCP 5006. Reload `quest_video` with the video cell stopped
or restart the kernel to use the new parent-side check, then rerun section 2a. The capture
worker and protocol were verified offline with fake cameras; no physical capture run is implied.

## USB-CAN transport and emulator rebuilds (2026-10-01)

Native config loading uses `/feathersys/configs/infra/comms_manager_conf.py` for
communications while retaining Albert's actuator declarations, gains and mappings.
The installed transport selects `use_emulated_teensy=True`; native validation sets
its address to localhost. An explicit `comms_config_path` can select another existing
transport declaration. Missing files fail before native SDK imports.

USB-CAN setup does not require a physical Teensy. The emulator is a host CAN bridge,
so it still needs an `emulated_teensy` executable built for this SDK. Startup checks
its embedded hash against the branch's C/H/INO sources; a missing or mismatched binary
triggers `make emulated` (180-second default timeout). Python/config edits do not
invalidate that hash. A matching binary avoids rebuilding. Do not bypass the hash
check or select physical Teensy mode to skip the host build.

The inspected branch cache had no emulator binary. The older TeleVision vendor
binary has a different source hash and cannot be reused for this branch. No compiler,
emulator, firmware upload or robot initialization was run during these offline checks.

## Current motor models (2026-10-01)

Albert's older declarations were corrected to match the current system hardware:
drive center/right/left (0x73-0x75) and wrist roll right/left (0x15/0x25) are RS02.
The other 17 Robstride models already matched. Wrist-roll torque remains 4 Nm,
speed remains 3 rad/s, KP 40 and KD 3. Base tuning, IDs, directions, limits and URDF
joint mappings remain. The SDK's firmware/model check stays active;
the correction selects the actual motor's CAN encoder, without a firmware flash.

The notebook uses the standard `initialize_feather_system(config)` entry point.
Calling it without a config loads all of `/feathersys/configs/robot_conf.py`, including
its own URDF selection, different arm tuning, enabled odometry and no hands. Explicit
config loading preserves this teleoperation's tuning, subsystem selection and L6
adapter while using the installed communications declaration. After a failed SDK
initialization, restart the kernel before retrying to clear SDK logger/process state.

## Base wheel geometry references (2026-10-01)

The selected Albert URDF folder is correct. Its drive joints BpC/BpR/BpL have
child links `wheel_link_center_1`, `wheel_link_right_1`, and `wheel_link_left_1`.
The corresponding motor `urdf_link_name` declarations now use these names;
the older `drive_wheel_*` names do not exist in this URDF or its geometry cache.
The SDK uses each motor's link name as the cache lookup key. The URDF, wheel
meshes, cache, radii, geometry units and motor tuning are unchanged.

Offline checks validate all selected motor joint/link references against the
actual URDF and exercise the SDK's wheel geometry resolver without constructing
hardware. The existing cache was also compared to geometry recalculated from
the actual meshes using this branch's extractor. Restart the kernel after a
failed initialization so the corrected declarations are loaded afresh.

## Hand discovery buses (2026-10-01)

The notebook passes `use_arm_endpoints=True` to `attach_hands`. Each hand's
position-only L6 discovery uses the endpoint already discovered by the SDK for
its same-side arm motors. No CAN index is hardcoded. Missing, unresolved or
inconsistent arm endpoints fail before attachment instead of probing other buses.
An explicit hand endpoint must agree with the arm endpoint.

Previously discovery probed every emulator endpoint, including unused onboard
interfaces, and could encounter `can_write` / `No buffer space available` before
querying the actual hand bus. No CAN interface settings or queue sizes were changed.
Each hand still binds only after fresh position feedback on its L6
observed reply ID (left 0x28/0x30, right 0x27/0x2F); there is no assumed side-to-bus mapping. Multiple
responders, conflicts and transport errors remain fatal. Torque, speed and
position writes still require successful discovery. Omitting the option retains
the adapter's original all-endpoint selection for other installations.

Restart the kernel after updating modules, then use the existing notebook setup
sequence. The notebook's outputs, settings and control behavior are preserved
apart from following the discovered arm endpoints; no hardware cells were run by the agent.
