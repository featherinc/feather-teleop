from feathersdk.robot.services.battery_service import BatteryServiceConfig, PicoConfig, ADS1115Config
from feathersdk.utils import Version


# Configs for different ADC controllers
pico_config = PicoConfig(gpio_pin=26)
ads1115_config = ADS1115Config(i2c_bus=1, i2c_addr=0x48, config_reg=0x01, conv_reg=0x00)


v0_4_0_battery_service_config = BatteryServiceConfig(
    rated_voltage=48.0,
    capacity_amp_hours=50.0,
    num_batteries=2,
    min_voltage=49.0,
    max_voltage=56.0,
    estop_voltage_threshold=45.0,
    adc_config=pico_config,
)

def create_battery_service_config(version: Version) -> BatteryServiceConfig:
    if version <= Version("0.4.0"):
        return v0_4_0_battery_service_config
    else:
        raise ValueError(f"Unsupported system version: {version}")
