from feathersdk.utils import Path, Version, set_root_feather_path
from feathersdk.robot.robot import FeatherRobotConfig
from feathersdk.configs import export_config

from .infra.logging_conf import logging_config
from .infra.comms_manager_conf import comms_manager_config
from .infra.data_monitor_service_conf import data_monitor_service_config

from .services.battery_service_conf import create_battery_service_config

from .systems.neck_system_conf import neck_system_config
from .systems.navigation_system_conf import navigation_system_config
from .systems.torso_system_conf import torso_system_config
from .systems.arms_system_conf import arms_system_config
from .systems.manipulation_system_conf import manipulation_system_config


FEATHER_VERSION = Version("0.5.1")
"""The version of the Feather system. Should not be changed unless you've modified the physical system hardware!"""

set_root_feather_path(Path("/feathersys"))
"""The main directory to use for the system. Best to leave this as `/feathersys` unless you know what you're doing."""


robot_config = FeatherRobotConfig(
    version=FEATHER_VERSION,
    urdf_path=Path(
        "/home/feather/Workspace/featheros/showcase/team/albert/"
        "URDF_C_Arm_03_description-20260625T192804Z-3-001/"
        "URDF_C_Arm_03_description/urdf/URDF_C_Arm_03.urdf"
    ),
    set_atexit_handler=True,
    set_signal_handlers=True,
    enable_cans_during_find=False,
    logging_config=logging_config,
    comms_manager_config=comms_manager_config,
    data_monitor_service_config=data_monitor_service_config,
    battery_service_config=None,
    neck_system_config=neck_system_config,
    torso_system_config=torso_system_config,
    navigation_system_config=navigation_system_config,
    arms_system_config=arms_system_config,
    manipulation_system_config= manipulation_system_config
)

# Export the final config here for use in the robot
export_config(robot_config)
