from feathersdk.comms import CommsManagerConfig


comms_manager_config = CommsManagerConfig(
    max_can_rate=3500.0,
    can_leniency=100.0,
    max_ip_rate=10000.0,
    ip_leniency=100.0,
    result_operating_frequency=500.0,
    await_thread_start_timeout=1.0,
    processing_toggle_timeout=0.5,
    show_all_sdo_errors=False,
)
