from feathersdk.robot.services import DataMonitorServiceConfig

data_monitor_service_config = DataMonitorServiceConfig(
    can_monitor_enabled=True,
)
