from feathersdk.logging import LoggingConfig, INFO, DISABLE_TAGS, DEBUG
from feathersdk.utils.math import GB


logging_config = LoggingConfig(
    file_level=DEBUG,
    console_level=INFO,
    debug_tags=DISABLE_TAGS,
    max_rate=1000.0,
    leniency=10.0,
    disable_file_logging=False,
    disable_console_logging=False,
    log_parent_dir="/feathersys/logs",
    console_out="stdout",
    custom_levels={},
    overload_log_cooldown=4.0,
    logging_file_size_check_every=30.0,
    max_log_file_size=1 * GB,
    log_message_multiline=True,
    logging_buffer_size=10_000,
    logging_buffer_flush_interval=1.0,
    max_log_directory_size=100 * GB,
    log_init_info=True,
)
