from feathersdk.robot.actuator_systems import ArmsSystemConfig, Robstride7MArmConfig
from feathersdk.robot.actuators.robstride import RobstrideMotorConfig, RobstrideVersion, RobstrideCalibrationConfig
from feathersdk.utils import NumericRange, deg2rad
from feathersdk.robot.actuators import SafeStopPolicy



def _arm_motor_config(
    id: int, 
    name: str, 
    version: RobstrideVersion, 
    angle_range: NumericRange, 
    comp_torque: float, 
    calibrate_torque: float,
    requires_calibration: bool = True,
    max_velocity: float = 5.0,
    max_acceleration: float = 30.0,
    max_jerk: float = 100.0,
    direction: int = 1,
    gravity_multiplier: float = 1.0,
    default_op_kp: float = 8.0,
    default_op_kd: float = 2.0,
    urdf_joint_name: str = '',
    loc_kp: float = 8.0,
    spd_kp: float = 6.0,
    max_torque: float | None = None,
) -> RobstrideMotorConfig:
    return RobstrideMotorConfig(
        id=id,
        name=name,
        urdf_joint_name=urdf_joint_name,
        requires_calibration=requires_calibration,
        version=version,
        direction=direction,
        max_angle_dx=0.7,
        max_torque=max_torque if max_torque is not None else {
            RobstrideVersion.RS04: 40.0, RobstrideVersion.RS03: 20.0,
            RobstrideVersion.RS02: 6.0, RobstrideVersion.RS00: 4.0}[version],
        max_velocity=max_velocity,
        max_acceleration=max_acceleration,
        max_jerk=max_jerk,
        angle_range=angle_range,
        calibration_config=RobstrideCalibrationConfig(
            speed=0.4,
            torque_threshold=calibrate_torque,
            fast_find_speed_mult=1.0,
            freeze_on_failed_calibration=True,
            allow_load_calibration=True,
            abs_range_tolerance=deg2rad(3),
        ),
        calibration_timeout=40.0,
        compliance_mode_torque_threshold=comp_torque,
        compliance_mode_update_dx=0.001,
        compliance_mode_max_velocity=2.0,
        compliance_mode_max_acceleration=10.0,
        gravity_multiplier=gravity_multiplier,
        default_op_kp=default_op_kp,
        default_op_kd=default_op_kd,
        loc_kp=loc_kp,
        spd_kp=spd_kp,
    )


arms_system_config = ArmsSystemConfig(
    left_arm=Robstride7MArmConfig(
        home_position_tolerance=0.2,
        module_name="left_arm",
        side="left",
        safe_stop_policy=SafeStopPolicy.DO_NOTHING,
        on_abort_action="disable",
        shoulder_pitch_motor=_arm_motor_config(
            id=0x20, 
            name="shoulder_pitch_left",
            urdf_joint_name="SpL",
            default_op_kp=300.0,  # was 1000.0
            default_op_kd=15.0,  # was 15.0
            version=RobstrideVersion.RS04, 
            angle_range=NumericRange(deg2rad(-59.67665303), deg2rad(180.323347)),  # previous: NumericRange(deg2rad(-60), deg2rad(180))
            comp_torque=10.0,
            calibrate_torque=30.0,
            max_velocity=3,
            gravity_multiplier=0.8867,
        ),
        shoulder_roll_motor=_arm_motor_config(
            id=0x21, 
            name="shoulder_roll_left",
            urdf_joint_name="SrL",
            default_op_kp=300.0,  # was 1000.0
            default_op_kd=15.0,  # was 15.0
            version=RobstrideVersion.RS04, 
            angle_range=NumericRange(deg2rad(-18), deg2rad(198)),  # previous: NumericRange(deg2rad(-19), deg2rad(194.5))
            comp_torque=10.0,
            calibrate_torque=25.0,
            max_velocity=3,
            gravity_multiplier=0.9051,
        ),
        shoulder_yaw_motor=_arm_motor_config(
            id=0x22, 
            name="shoulder_yaw_left",
            urdf_joint_name="SwL",
            default_op_kp=100.0,  # was 500.0
            default_op_kd=10.0,  # was 10.0
            version=RobstrideVersion.RS03, 
            angle_range=NumericRange(deg2rad(-112), deg2rad(112)),  # previous: NumericRange(deg2rad(-113), deg2rad(113))
            comp_torque=2.0,
            calibrate_torque=10.0,
            max_velocity=3,
            gravity_multiplier=0.9481,
        ),
        elbow_motor=_arm_motor_config(
            id=0x23, 
            name="elbow_left",
            urdf_joint_name="EpL",
            default_op_kp=75.0,  # was 300.0
            default_op_kd=15.0,  # was 15.0
            version=RobstrideVersion.RS03, 
            angle_range=NumericRange(deg2rad(-162.8989), deg2rad(27.101)),  # previous: NumericRange(deg2rad(-157), deg2rad(31))
            comp_torque=5.0,
            calibrate_torque=15.0,
            max_velocity=3,
            gravity_multiplier=0.8676,
        ),
        wrist_yaw_motor=_arm_motor_config(
            id=0x24, 
            name="wrist_yaw_left",
            urdf_joint_name="WwL",
            default_op_kp=40.0,  # was 80.0
            default_op_kd=3.0,  # was 3.0
            version=RobstrideVersion.RS02, 
            angle_range=NumericRange(deg2rad(-139.9418), deg2rad(140.05804)),  # previous: NumericRange(deg2rad(-139), deg2rad(139))
            comp_torque=2.0,
            calibrate_torque=5.0,
            max_velocity=3,
            gravity_multiplier=0.9,
        ),
        wrist_roll_motor=_arm_motor_config(
            id=0x25, 
            name="wrist_roll_left",
            urdf_joint_name="WrL",
            default_op_kp=40.0,  # was 80.0
            default_op_kd=3.0,  # was 3.0
            version=RobstrideVersion.RS02,
            max_torque=4.0,
            angle_range=NumericRange(deg2rad(-55.05527566), deg2rad(54.95013455)),  # previous: NumericRange(deg2rad(-50.8), deg2rad(58))
            comp_torque=1.5,
            calibrate_torque=5.0,
            max_velocity=3,
            gravity_multiplier=1.0,
        ),
        wrist_pitch_motor=_arm_motor_config(
            id=0x26, 
            name="wrist_pitch_left",
            urdf_joint_name="WpL",
            default_op_kp=40.0,  # was 80.0
            default_op_kd=3.0,  # was 3.0
            version=RobstrideVersion.RS00, 
            angle_range=NumericRange(deg2rad(-60), deg2rad(100)),  # previous: NumericRange(deg2rad(-65), deg2rad(97.5))
            comp_torque=2.0,
            calibrate_torque=5.0,
            max_velocity=3,
            gravity_multiplier=1.0,
        ),
    ),
    right_arm=Robstride7MArmConfig(
        home_position_tolerance=0.2,
        module_name="right_arm",
        side="right",
        safe_stop_policy=SafeStopPolicy.DO_NOTHING,
        on_abort_action="disable",
        shoulder_pitch_motor=_arm_motor_config(
            id=0x10, 
            name="shoulder_pitch_right",
            urdf_joint_name="SpR",
            default_op_kp=300.0,
            default_op_kd=15.0,
            version=RobstrideVersion.RS04, 
            angle_range=NumericRange(deg2rad(-180.323347), deg2rad(59.67665303)),  # previous: NumericRange(deg2rad(-180), deg2rad(60))
            comp_torque=10.0,
            calibrate_torque=35.0,
            max_velocity=3,
            gravity_multiplier=0.8867,
        ),
        shoulder_roll_motor=_arm_motor_config(
            id=0x11, 
            name="shoulder_roll_right",
            urdf_joint_name="SrR",
            default_op_kp=300.0,
            default_op_kd=15.0,
            version=RobstrideVersion.RS04, 
            angle_range=NumericRange(deg2rad(-198), deg2rad(18)),  # previous: NumericRange(deg2rad(-197.5), deg2rad(16))
            comp_torque=10.0,
            calibrate_torque=30.0,
            max_velocity=3,
            gravity_multiplier=0.9051,
        ),
        shoulder_yaw_motor=_arm_motor_config(
            id=0x12, 
            name="shoulder_yaw_right",
            urdf_joint_name="SwR",
            default_op_kp=100.0,
            default_op_kd=10.0,
            version=RobstrideVersion.RS03, 
            angle_range=NumericRange(deg2rad(-112), deg2rad(112)),  # previous: NumericRange(deg2rad(-113), deg2rad(113))
            comp_torque=2.0,
            calibrate_torque=10.0,
            max_velocity=3,
            gravity_multiplier=0.9481,
        ),
        elbow_motor=_arm_motor_config(
            id=0x13,
            name="elbow_right",
            urdf_joint_name="EpR",
            default_op_kp=75.0,
            default_op_kd=15.0, 
            version=RobstrideVersion.RS03, 
            angle_range=NumericRange(deg2rad(-27.101), deg2rad(162.8989)),  # previous: NumericRange(deg2rad(-31), deg2rad(157))
            comp_torque=5.0,
            calibrate_torque=15.0,
            max_velocity=3,
            gravity_multiplier=0.8676,
        ),
        wrist_yaw_motor=_arm_motor_config(
            id=0x14, 
            name="wrist_yaw_right",
            urdf_joint_name="WwR",
            default_op_kp=40.0,
            default_op_kd=3.0,
            version=RobstrideVersion.RS02, 
            angle_range=NumericRange(deg2rad(-139.9418), deg2rad(140.05804)),  # previous: NumericRange(deg2rad(-139), deg2rad(139))
            comp_torque=2.0,
            calibrate_torque=5.0,
            max_velocity=3,
            gravity_multiplier=0.9,
        ),
        wrist_roll_motor=_arm_motor_config(
            id=0x15, 
            name="wrist_roll_right",
            urdf_joint_name="WrR",
            default_op_kp=40.0,
            default_op_kd=3.0,
            version=RobstrideVersion.RS02,
            max_torque=4.0,
            angle_range=NumericRange(deg2rad(-55.05527566), deg2rad(54.95013455)),  # previous: NumericRange(deg2rad(-58), deg2rad(50.8))
            comp_torque=1.5,
            calibrate_torque=5.0,
            max_velocity=3,
            gravity_multiplier=1.0,
        ),
        wrist_pitch_motor=_arm_motor_config(
            id=0x16, 
            name="wrist_pitch_right",
            urdf_joint_name="WpR",
            default_op_kp=40.0,
            default_op_kd=3.0, 
            version=RobstrideVersion.RS00, 
            angle_range=NumericRange(deg2rad(-60), deg2rad(100)),  # previous: NumericRange(deg2rad(-65), deg2rad(96.6))
            comp_torque=2.0,
            calibrate_torque=5.0,
            max_velocity=3,
            gravity_multiplier=1.0,
        ),
    ),
)
