from feathersdk.robot.actuator_systems import TorsoSystemConfig
from feathersdk.robot.actuators.ezmotion import EZMotionMotorConfig, EC_PER_ROT


torso_system_config = TorsoSystemConfig(
    lift_motor=EZMotionMotorConfig(
        name="lift_motor", 
        id=0x09, 
        requires_calibration=True,
        target_velocity=EC_PER_ROT * 6,
        target_acceleration=EC_PER_ROT * 50,
        target_deceleration=EC_PER_ROT * 50,
        shares_endpoint_with=["neck_yaw", "turning_center"],
    ),
    max_height_mm=600,
    min_height_mm=50,
    direction=-1,
)
