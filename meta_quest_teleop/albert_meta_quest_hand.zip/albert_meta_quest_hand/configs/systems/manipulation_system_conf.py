from feathersdk.robot.actuator_systems.manipulation_system import RealHandManipulationSystemConfig
from feathersdk.robot.actuators.realhand import RealHandConfig, RealHandVersion


manipulation_system_config = RealHandManipulationSystemConfig(
    left_hand=RealHandConfig(
        id=0x28,
        name="left_hand",
        version=RealHandVersion.L6,
    ),
    right_hand=RealHandConfig(
        id=0x27,
        name="right_hand",
        version=RealHandVersion.L6,
    ),
)
