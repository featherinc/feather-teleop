from feathersdk.robot.actuator_systems import NavigationSystemConfig, SafeStopPolicy
from feathersdk.robot.actuators.robstride import RobstrideVersion, RobstrideMotorConfig
from feathersdk.robot.actuators.robstride.calibrate import RobstrideCalibrationConfig
from feathersdk.utils.feathertypes import Literal
from feathersdk.utils import NumericRange, pi, tau, deg2rad


def _base_motor_config(
    id: int,
    name: str,
    direction: Literal[1, -1],
    is_turning: bool,
    urdf_joint_name: str = '',
    urdf_link_name: str = '',
) -> RobstrideMotorConfig:
    return RobstrideMotorConfig(
        id=id,
        name=name,
        urdf_joint_name=urdf_joint_name,
        urdf_link_name=urdf_link_name,
        requires_calibration=is_turning,
        version=RobstrideVersion.RS02,
        direction=direction,
        max_angle_dx=0.1,
        max_torque=5.5,
        max_velocity=10.47,
        max_acceleration=100.0 if is_turning else 30.0,
        angle_range=NumericRange(-deg2rad(100), deg2rad(100)) if is_turning else NumericRange(-tau, tau),
        calibration_config=RobstrideCalibrationConfig(
            speed=0.5,
            torque_threshold=5,
            fast_find_speed_mult=2.0,
            allow_load_calibration=True,
        ),
        calibration_timeout=40.0,
        compliance_mode_torque_threshold=1.5,
        compliance_mode_update_dx=0.001,
        compliance_mode_max_velocity=1.0,
        compliance_mode_max_acceleration=10.0,
    )


navigation_system_config = NavigationSystemConfig(
    safe_stop_policy=SafeStopPolicy.CANNOT_ENTER_SAFE_STOP,
    turning_center_motor=_base_motor_config(0x70, "turning_center", -1, True, urdf_joint_name="BwC"),
    turning_right_motor=_base_motor_config(0x71, "turning_right", -1, True, urdf_joint_name="BwR"),
    turning_left_motor=_base_motor_config(0x72, "turning_left", -1, True, urdf_joint_name="BwL"),
    drive_center_motor=_base_motor_config(
        0x73, "drive_center", 1, False, urdf_joint_name="BpC", urdf_link_name="wheel_link_center_1"
    ),
    drive_right_motor=_base_motor_config(
        0x74, "drive_right", 1, False, urdf_joint_name="BpR", urdf_link_name="wheel_link_right_1"
    ),
    drive_left_motor=_base_motor_config(
        0x75, "drive_left", -1, False, urdf_joint_name="BpL", urdf_link_name="wheel_link_left_1"
    ),
    rotation_tolerance=0.04,
    rotate_in_place_angles={"turning_center": -pi / 2, "turning_right": -pi / 4, "turning_left": pi / 4},
    rotate_in_place_directions={"drive_center": -1, "drive_right": 1, "drive_left": -1},
    multithreaded_calibration=True,
)
