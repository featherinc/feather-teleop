from feathersdk.utils import NumericRange, pi
from feathersdk.robot.actuators.robstride.calibrate import RobstrideCalibrationConfig
from feathersdk.robot.actuator_systems import NeckSystemConfig
from feathersdk.robot.actuators.robstride import RobstrideVersion, RobstrideMotorConfig
from feathersdk.robot.actuators import SafeStopPolicy


neck_system_config = NeckSystemConfig(
    safe_stop_policy=SafeStopPolicy.CANNOT_ENTER_SAFE_STOP,
    pitch_motor=RobstrideMotorConfig(
        id=0x30,
        name="neck_pitch",
        requires_calibration=True,
        version=RobstrideVersion.RS05,
        direction=1,
        max_angle_dx=0.1,
        max_torque=5.5,
        max_velocity=10.47,
        max_acceleration=10.0,
        angle_range=NumericRange(-2.20, 0.15),
        calibration_config=RobstrideCalibrationConfig(
            speed=0.4,
            torque_threshold=2.0,
            fast_find_speed_mult=2.0,
            allow_load_calibration=True,
        ),
        calibration_timeout=20.0,
        compliance_mode_torque_threshold=1.5,
        compliance_mode_update_dx=0.001,
        compliance_mode_max_velocity=1.0,
        compliance_mode_max_acceleration=10.0,
    ),
    yaw_motor=RobstrideMotorConfig(
        id=0x31,
        name="neck_yaw",
        requires_calibration=True,
        version=RobstrideVersion.RS05,
        direction=1,
        max_angle_dx=0.1,
        max_torque=5.5,
        max_velocity=10.47,
        max_acceleration=10.0,
        angle_range=NumericRange(-1.66, 1.70),
        calibration_config=RobstrideCalibrationConfig(
            speed=0.4,
            torque_threshold=2.0,
            fast_find_speed_mult=2.0,
            allow_load_calibration=True,
        ),
        calibration_timeout=40.0,
        compliance_mode_torque_threshold=1.5,
        compliance_mode_update_dx=0.001,
        compliance_mode_max_velocity=1.0,
        compliance_mode_max_acceleration=10.0,
    ),
    multithreaded_calibration=True,
)
