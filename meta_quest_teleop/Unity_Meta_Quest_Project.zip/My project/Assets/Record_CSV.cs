using UnityEngine;
using UnityEngine.XR;
#if UNITY_ANDROID
using UnityEngine.Android; // Required for Quest 3S permissions
#endif
using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.IO;

public class Record_CSV : MonoBehaviour
{
    [System.Serializable]
    public struct RobotDataPoint
    {
        public float time;
        public Vector3 lPos; public Vector3 lRot;
        public Vector3 rPos; public Vector3 rRot;
        public Vector3 hPos; public Vector3 hRot;
    }

    [Header("Tracking References")]
    public Transform leftController;
    public Transform rightController;
    public Transform mainCamera;
    public Transform robotBase;

    [Header("Feedback")]
    [Tooltip("Attach an AudioSource with a short 'beep' AudioClip assigned to it.")]
    public AudioSource beepAudioSource;

    [Header("BLE Settings")]
    public string targetDeviceName = "ESP32_Writer";
    public string serviceUUID = "4fafc201-1fb5-459e-8fcc-c5c9c331914b";
    public string characteristicUUID = "beb5483e-36e1-4688-b7f5-ea07361b26a8";

    // Private State Variables
    private List<RobotDataPoint> sessionData = new List<RobotDataPoint>();
    private bool isRecording = false;
    private float timer = 0f;
    private float hz = 30f;
    private bool wasButtonAPressed = false;

    // BLE State Variables
    private string _deviceAddress;
    private bool _connected = false;
    private string currentSessionFileName = "";

    void Start()
    {
#if UNITY_ANDROID
        if (!Permission.HasUserAuthorizedPermission("android.permission.BLUETOOTH_SCAN") ||
            !Permission.HasUserAuthorizedPermission("android.permission.BLUETOOTH_CONNECT"))
        {
            Permission.RequestUserPermissions(new string[] {
                "android.permission.BLUETOOTH_SCAN",
                "android.permission.BLUETOOTH_CONNECT",
                "android.permission.ACCESS_FINE_LOCATION"
            });
        }
#endif

        BluetoothLEHardwareInterface.Initialize(true, false, () => {
            Debug.Log("BLE Initialized. Waiting to start scan...");
            StartCoroutine(WaitAndStartScan());
        }, (error) => {
            Debug.LogError("BLE Init Error: " + error);
        });
    }

    IEnumerator WaitAndStartScan()
    {
        yield return new WaitForSeconds(1.5f);
        StartScan();
    }

    void StartScan()
    {
        Debug.Log("Starting BLE Scan...");

        BluetoothLEHardwareInterface.ScanForPeripheralsWithServices(null, (address, name) => {
            Debug.Log("C# Scanner saw a device named: " + name);

            if (!string.IsNullOrEmpty(name) && name.Contains(targetDeviceName))
            {
                _deviceAddress = address;
                BluetoothLEHardwareInterface.StopScan();
                Debug.Log("!!! MATCH FOUND !!! Found ESP32 at: " + address + ". Connecting...");
                Connect();
            }
        }, null, false, false);
    }

    void Connect()
    {
        BluetoothLEHardwareInterface.ConnectToPeripheral(_deviceAddress, null, null, (address, service, characteristic) => {
            if (characteristic.ToLower() == characteristicUUID.ToLower())
            {
                _connected = true;
                Debug.Log("BLE Ready: Connected to ESP32 Characteristic!");
            }
        }, (disconnectedAddress) => {
            _connected = false;
            Debug.Log("BLE Disconnected. Restarting Scan...");
            StartCoroutine(WaitAndStartScan());
        });
    }

    void Update()
    {
        InputDevice rightDevice = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);

        if (rightDevice.TryGetFeatureValue(CommonUsages.primaryButton, out bool isButtonAPressed))
        {
            if (isButtonAPressed && !wasButtonAPressed)
            {
                if (!isRecording) StartRecording();
                else StopRecording();
            }
            wasButtonAPressed = isButtonAPressed;
        }

        if (isRecording)
        {
            timer += Time.deltaTime;
            if (timer >= (1f / hz))
            {
                RecordFrame();
                timer = 0;
            }
        }
    }

    void StartRecording()
    {
        sessionData.Clear();
        isRecording = true;

        // 1. Generate the file name right when you START recording
        currentSessionFileName = "RobotTrainingData_" + System.DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".csv";

        string startTimeStr = Time.time.ToString("F2");
        Debug.Log("RECORDING STARTED. Filename: " + currentSessionFileName);

        // 2. Send the filename to the ESP32 FIRST so it can create the file
        SendBLEMessage($"file {currentSessionFileName}");

        // 3. Send the start command on a slight delay so the ESP32 has time to open the file
        StartCoroutine(SendDelayedBLEMessage($"start {startTimeStr}", 0.3f));

        StartCoroutine(PlayBeeps(1));
    }

    void StopRecording()
    {
        isRecording = false;

        string endTimeStr = Time.time.ToString("F2");
        Debug.Log("RECORDING STOPPED at " + endTimeStr);

        // 1. Tell the ESP32 to stop (so it can close the SD card file safely)
        SendBLEMessage($"stop {endTimeStr}");

        StartCoroutine(PlayBeeps(2));

        // 2. Save the Unity CSV using the name we generated at the beginning
        SaveDataToCSV(currentSessionFileName);
    }

    // --- NEW HELPER TO DELAY BLUETOOTH MESSAGES ---
    IEnumerator SendDelayedBLEMessage(string message, float delay)
    {
        yield return new WaitForSeconds(delay);
        SendBLEMessage(message);
    }

    void SendBLEMessage(string message)
    {
        if (!_connected)
        {
            Debug.LogWarning("Cannot send message, ESP32 is not connected: " + message);
            return;
        }

        byte[] data = Encoding.UTF8.GetBytes(message);

        BluetoothLEHardwareInterface.WriteCharacteristic(
            _deviceAddress,
            serviceUUID,
            characteristicUUID,
            data,
            data.Length,
            true,
            (charUUID) => {
                Debug.Log("Successfully sent BLE message: " + message);
            }
        );
    }

    IEnumerator PlayBeeps(int beepCount)
    {
        if (beepAudioSource == null)
        {
            Debug.LogWarning("Beep Audio Source is missing! Cannot play sound.");
            yield break;
        }

        for (int i = 0; i < beepCount; i++)
        {
            beepAudioSource.Play();
            yield return new WaitForSeconds(0.3f);
        }
    }

    void RecordFrame()
    {
        RobotDataPoint point = new RobotDataPoint();
        point.time = Time.time;

        point.lPos = robotBase.InverseTransformPoint(leftController.position);
        point.lRot = GetRelativeRotation(leftController);

        point.rPos = robotBase.InverseTransformPoint(rightController.position);
        point.rRot = GetRelativeRotation(rightController);

        if (mainCamera != null)
        {
            point.hPos = robotBase.InverseTransformPoint(mainCamera.position);
            point.hRot = GetRelativeRotation(mainCamera);
        }

        sessionData.Add(point);
    }

    Vector3 GetRelativeRotation(Transform target)
    {
        Vector3 rot = target.eulerAngles;
        return new Vector3(NormalizeAngle(rot.x), NormalizeAngle(rot.y), NormalizeAngle(rot.z));
    }

    // Modified to accept the file name we generated in StopRecording()
    void SaveDataToCSV(string fileName)
    {
        string filePath = Path.Combine(Application.persistentDataPath, fileName);

        using (StreamWriter writer = new StreamWriter(filePath))
        {
            writer.WriteLine("Time,L_PosX,L_PosY,L_PosZ,L_RotX,L_RotY,L_RotZ,R_PosX,R_PosY,R_PosZ,R_RotX,R_RotY,R_RotZ,H_PosX,H_PosY,H_PosZ,H_RotX,H_RotY,H_RotZ");

            foreach (var d in sessionData)
            {
                writer.WriteLine($"{d.time},{d.lPos.x},{d.lPos.y},{d.lPos.z},{d.lRot.x},{d.lRot.y},{d.lRot.z},{d.rPos.x},{d.rPos.y},{d.rPos.z},{d.rRot.x},{d.rRot.y},{d.rRot.z},{d.hPos.x},{d.hPos.y},{d.hPos.z},{d.hRot.x},{d.hRot.y},{d.hRot.z}");
            }
        }
        Debug.Log("FILE SAVED TO: " + filePath);
    }

    float NormalizeAngle(float a) => (a > 180) ? a - 360 : a;

    private void OnApplicationQuit()
    {
        BluetoothLEHardwareInterface.DeInitialize(() => { });
    }
}