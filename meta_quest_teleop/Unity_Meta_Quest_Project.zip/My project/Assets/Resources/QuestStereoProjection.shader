Shader "Quest/CalibratedStereoProjection"
{
    Properties { _MainTex ("Video", 2D) = "black" {} }
    SubShader
    {
        Cull Off ZWrite Off ZTest Always
        Pass
        {
            CGPROGRAM
            #pragma vertex vert_img
            #pragma fragment frag
            #include "UnityCG.cginc"
            sampler2D _MainTex;
            float4 _UvOffset;
            fixed4 frag(v2f_img input) : SV_Target
            {
                float2 uv = input.uv + _UvOffset.xy;
                if (any(uv < 0) || any(uv > 1)) return fixed4(0,0,0,1);
                return fixed4(tex2D(_MainTex, uv).rgb, 1);
            }
            ENDCG
        }
    }
    Fallback Off
}
