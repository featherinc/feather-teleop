using UnityEngine;
using UnityEngine.Android;

public class BLEPermissionRequest : MonoBehaviour
{
    void Start()
    {
        // Android 12+ requires explicit runtime permission for Bluetooth
        string[] permissions = new string[]
        {
            "android.permission.BLUETOOTH_CONNECT",
            "android.permission.BLUETOOTH_SCAN"
        };

        bool needsPermission = false;
        foreach (string permission in permissions)
        {
            // Check if the user has already authorized the specific permission
            if (!Permission.HasUserAuthorizedPermission(permission))
            {
                needsPermission = true;
                break;
            }
        }

        if (needsPermission)
        {
            // Triggers the system dialog asking the user to grant the app permission to discover and connect to nearby devices
            Permission.RequestUserPermissions(permissions);
        }
        else
        {
            Debug.Log("Bluetooth permissions already granted!");
        }
    }
}