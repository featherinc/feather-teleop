using UnityEngine;
using UnityEngine.XR;

public class HelloWorld : MonoBehaviour
{
    [Header("Assign Transforms")]
    public Transform leftControllerTransform;
    public Transform rightControllerTransform;
    public Transform robotBase;

    [Header("Settings")]
    public float targetHz = 30f;
    private float timer = 0f;
    private bool isRunning = false;

    void Update()
    {
        InputDevice rightDevice = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);

        // A Button to Start
        if (rightDevice.TryGetFeatureValue(CommonUsages.primaryButton, out bool aPressed) && aPressed)
        {
            isRunning = true;
        }

        // B Button to Stop
        if (rightDevice.TryGetFeatureValue(CommonUsages.secondaryButton, out bool bPressed) && bPressed)
        {
            isRunning = false;
        }

        if (isRunning)
        {
            // Increment timer by the time passed since last frame
            timer += Time.deltaTime;

            // Check if it's time to send data (1/30 = 0.0333s)
            if (timer >= (1f / targetHz))
            {
                ProcessHandData(leftControllerTransform, "LEFT");
                ProcessHandData(rightControllerTransform, "RIGHT");

                // Reset timer but keep the "extra" time for accuracy
                timer -= (1f / targetHz);
            }
        }
    }

    void ProcessHandData(Transform handTransform, string label)
    {
        if (handTransform == null) return;

        Vector3 targetPos = robotBase.InverseTransformPoint(handTransform.position);
        Vector3 wristEuler = handTransform.localEulerAngles;

        float pitch = NormalizeAngle(wristEuler.x);
        float roll = NormalizeAngle(wristEuler.z);
        float yaw = NormalizeAngle(wristEuler.y);

        Debug.Log($"{label} @ 30Hz - POS:{targetPos:F2} | ROT:{pitch:F0},{roll:F0},{yaw:F0}");
    }

    float NormalizeAngle(float angle)
    {
        if (angle > 180) angle -= 360;
        return angle;
    }
}