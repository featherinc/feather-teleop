using UnityEngine;
using UnityEngine.XR;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.IO;

public class Record_CSV_BLE : MonoBehaviour
{
    [System.Serializable]
    public struct RobotDataPoint
    {
        public float time;
        public Vector3 lPos; public Vector3 lRot;
        public Vector3 rPos; public Vector3 rRot;
        public Vector3 hPos; public Vector3 hRot;
    }

    [Header("Tracking References")]
    public Transform leftController;
    public Transform rightController;
    public Transform mainCamera;
    public Transform robotBase;

    [Header("Feedback Audio")]
    public AudioSource startAudioSource;
    public AudioSource stopAudioSource;

    [Header("BLE Settings")]
    public string targetDeviceName = "ESP32_Master";
    public string serviceUUID = "4fafc201-1fb5-459e-8fcc-c5c9c331914b";
    public string characteristicUUID = "beb5483e-36e1-4688-b7f5-ea07361b26a8";

    // --- Throttle Control Variables ---
    private float lastSentThrottle = -1f;
    private float nextThrottleSendTime = 0f;
    private float throttleSendRate = 0.033f; // Max ~30 times a second

    // --- Trigger (Front Button) Control Variables ---
    private float lastSentTrigger = -1f;
    private float nextTriggerSendTime = 0f;

    // --- B Button State Variable ---
    private bool wasSecondaryButtonPressed = false;

    private List<RobotDataPoint> sessionData = new List<RobotDataPoint>();
    private bool isRecording = false;
    private bool wasButtonPressed = false;
    private bool _connected = false;
    private string _deviceAddress;
    private string currentSessionFileName = "";

    void Start()
    {
        BluetoothLEHardwareInterface.Initialize(true, false, () => {
            StartCoroutine(ScanRoutine());
        }, (error) => Debug.LogError("BLE Error: " + error));
    }

    IEnumerator ScanRoutine()
    {
        yield return new WaitForSeconds(1.0f);
        BluetoothLEHardwareInterface.ScanForPeripheralsWithServices(null, (address, name) => {
            if (name == targetDeviceName)
            {
                _deviceAddress = address;
                BluetoothLEHardwareInterface.StopScan();
                Connect();
            }
        });
    }

    void Connect()
    {
        BluetoothLEHardwareInterface.ConnectToPeripheral(_deviceAddress, null, null, (address, service, charac) => {
            if (charac.ToLower() == characteristicUUID.ToLower())
            {
                _connected = true;

                BluetoothLEHardwareInterface.RequestMtu(_deviceAddress, 256, (addr, newMtu) => {
                    Debug.Log("BLE MTU successfully increased to: " + newMtu);
                });

                if (startAudioSource != null) startAudioSource.Play();
            }
        });
    }

    void Update()
    {
        InputDevice device = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);

        // --- 1. Primary Button (A Button) Logic: Start / Stop (Success) ---
        if (device.TryGetFeatureValue(CommonUsages.primaryButton, out bool isPressed))
        {
            if (isPressed && !wasButtonPressed)
            {
                if (_connected)
                {
                    if (!isRecording)
                    {
                        StartRecording();
                    }
                    else
                    {
                        StopRecording(true); // true = SUCCESS
                    }
                }
                else
                {
                    Debug.LogWarning("Ignored Start Command: ESP32 is not connected yet.");
                }
            }
            wasButtonPressed = isPressed;
        }

        // --- 2. Secondary Button (B Button) Logic: BLE + Stop (Failure) ---
        if (_connected && device.TryGetFeatureValue(CommonUsages.secondaryButton, out bool isBPressed))
        {
            if (isBPressed != wasSecondaryButtonPressed)
            {
                // Send BLE status for B button
                string bMsg = $"B|{(isBPressed ? "1" : "0")}";
                SendBLEMessage(bMsg);

                // If pressed DURING recording, stop and mark as FAILURE
                if (isBPressed && isRecording)
                {
                    StopRecording(false); // false = FAILURE
                }

                wasSecondaryButtonPressed = isBPressed;
            }
        }

        // --- 3. Middle Finger Grip Logic ---
        if (_connected && device.TryGetFeatureValue(CommonUsages.grip, out float squeezeValue))
        {
            if (Time.time >= nextThrottleSendTime && Mathf.Abs(squeezeValue - lastSentThrottle) > 0.01f)
            {
                string throttleMsg = $"T|{squeezeValue:F2}";
                SendBLEMessage(throttleMsg);
                lastSentThrottle = squeezeValue;
                nextThrottleSendTime = Time.time + throttleSendRate;
            }
        }

        // --- 4. Index Finger Trigger (Front Button) Logic ---
        if (_connected && device.TryGetFeatureValue(CommonUsages.trigger, out float triggerValue))
        {
            if (Time.time >= nextTriggerSendTime && Mathf.Abs(triggerValue - lastSentTrigger) > 0.01f)
            {
                string triggerMsg = $"F|{triggerValue:F2}";
                SendBLEMessage(triggerMsg);
                lastSentTrigger = triggerValue;
                nextTriggerSendTime = Time.time + throttleSendRate;
            }
        }

        if (isRecording) RecordFrame();
    }

    void StartRecording()
    {
        sessionData.Clear();
        isRecording = true;

        // Base filename without the success/failure tag yet
        currentSessionFileName = "Log_" + System.DateTime.Now.ToString("yyyyMMdd_HHmmss");

        string message = $"START|{currentSessionFileName}|{Time.time}";
        Debug.Log("Sending BLE Command: " + message);
        SendBLEMessage(message);

        if (startAudioSource != null) startAudioSource.Play();
    }

    // Updated to accept a boolean for success/failure
    void StopRecording(bool isSuccess)
    {
        isRecording = false;

        // Append the outcome to the filename
        if (isSuccess)
        {
            currentSessionFileName += "_SUCCESS";
        }
        else
        {
            currentSessionFileName += "_FAILURE";
        }

        string message = $"STOP|{Time.time}";
        Debug.Log("Sending BLE Command: " + message);
        SendBLEMessage(message);

        if (stopAudioSource != null) stopAudioSource.Play();

        // Save using the updated filename
        SaveDataToCSV(currentSessionFileName + ".csv");
    }

    void SendBLEMessage(string message, bool withResponse = false)
    {
        if (!_connected) return;
        byte[] data = Encoding.UTF8.GetBytes(message);

        BluetoothLEHardwareInterface.WriteCharacteristic(
            _deviceAddress,
            serviceUUID,
            characteristicUUID,
            data,
            data.Length,
            withResponse,
            (uuid) => { }
        );
    }

    void RecordFrame()
    {
        RobotDataPoint point = new RobotDataPoint();
        point.time = Time.time;
        point.lPos = robotBase.InverseTransformPoint(leftController.position);
        point.lRot = GetRelativeRotation(leftController);
        point.rPos = robotBase.InverseTransformPoint(rightController.position);
        point.rRot = GetRelativeRotation(rightController);

        if (mainCamera != null)
        {
            point.hPos = robotBase.InverseTransformPoint(mainCamera.position);
            point.hRot = GetRelativeRotation(mainCamera);
        }
        sessionData.Add(point);
    }

    Vector3 GetRelativeRotation(Transform target)
    {
        Vector3 rot = target.eulerAngles;
        return new Vector3(NormalizeAngle(rot.x), NormalizeAngle(rot.y), NormalizeAngle(rot.z));
    }

    void SaveDataToCSV(string fileName)
    {
        string filePath = Path.Combine(Application.persistentDataPath, fileName);
        using (StreamWriter writer = new StreamWriter(filePath))
        {
            writer.WriteLine("Time,L_PosX,L_PosY,L_PosZ,L_RotX,L_RotY,L_RotZ,R_PosX,R_PosY,R_PosZ,R_RotX,R_RotY,R_RotZ,H_PosX,H_PosY,H_PosZ,H_RotX,H_RotY,H_RotZ");
            foreach (var d in sessionData)
            {
                writer.WriteLine($"{d.time},{d.lPos.x},{d.lPos.y},{d.lPos.z},{d.lRot.x},{d.lRot.y},{d.lRot.z},{d.rPos.x},{d.rPos.y},{d.rPos.z},{d.rRot.x},{d.rRot.y},{d.rRot.z},{d.hPos.x},{d.hPos.y},{d.hPos.z},{d.hRot.x},{d.hRot.y},{d.hRot.z}");
            }
        }
        Debug.Log("FILE SAVED TO: " + filePath);
    }

    float NormalizeAngle(float a) => (a > 180) ? a - 360 : a;

    private void OnApplicationQuit()
    {
        BluetoothLEHardwareInterface.DeInitialize(() => { });
    }
}