using UnityEngine;
using UnityEngine.XR;
#if UNITY_ANDROID
using UnityEngine.Android; 
#endif
using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.IO;

public class Record_CSV_HAND : MonoBehaviour
{
    [System.Serializable]
    public struct RobotDataPoint
    {
        public float time;
        public Vector3 lPos; public Vector3 lRot;
        public Vector3 rPos; public Vector3 rRot;
        public Vector3 hPos; public Vector3 hRot;
    }

    [Header("Tracking References")]
    public Transform leftController;
    public Transform rightController;
    public Transform mainCamera;
    public Transform robotBase;

    [Header("Audio Feedback")]
    public AudioSource startAudioSource;
    public AudioSource stopAudioSource;

    [Header("BLE Device Names")]
    public string masterDeviceName = "ESP32_Master";
    public string slaveDeviceName = "ESP32_Slave";

    [Header("Master BLE UUIDs")]
    public string masterServiceUUID = "4fafc201-1fb5-459e-8fcc-c5c9c331914b";
    public string masterCharUUID = "beb5483e-36e1-4688-b7f5-ea07361b26a8";

    [Header("Slave BLE UUIDs")]
    public string slaveServiceUUID = "4fafc201-1fb5-459e-8fcc-c5c9c331914c";
    public string slaveCharUUID = "beb5483e-36e1-4688-b7f5-ea07361b26a9";

    // Private State
    private List<RobotDataPoint> sessionData = new List<RobotDataPoint>();
    private bool isRecording = false;
    private float timer = 0f;
    private float hz = 30f;
    private bool wasButtonAPressed = false;
    private string currentSessionFileName = "";

    // Dual BLE State
    private string _masterAddress = null;
    private string _slaveAddress = null;
    private bool _masterConnected = false;
    private bool _slaveConnected = false;
    private bool _isScanning = false;

    private bool BothConnected => _masterConnected && _slaveConnected;

    void Start()
    {
#if UNITY_ANDROID
        RequestAndroidPermissions();
#endif
        BluetoothLEHardwareInterface.Initialize(true, false, () => {
            Debug.Log("BLE Initialized. Starting Scan...");
            StartCoroutine(WaitAndStartScan());
        }, (error) => {
            Debug.LogError("BLE Init Error: " + error);
        });
    }

    private void RequestAndroidPermissions()
    {
#if UNITY_ANDROID
        if (!Permission.HasUserAuthorizedPermission("android.permission.BLUETOOTH_SCAN") ||
            !Permission.HasUserAuthorizedPermission("android.permission.BLUETOOTH_CONNECT"))
        {
            Permission.RequestUserPermissions(new string[] {
                "android.permission.BLUETOOTH_SCAN",
                "android.permission.BLUETOOTH_CONNECT",
                "android.permission.ACCESS_FINE_LOCATION"
            });
        }
#endif
    }

    IEnumerator WaitAndStartScan()
    {
        yield return new WaitForSeconds(1.0f);
        if (!_isScanning && !BothConnected)
        {
            StartScan();
        }
    }

    void StartScan()
    {
        _isScanning = true;
        string[] uuids = new string[] { masterServiceUUID, slaveServiceUUID };

        BluetoothLEHardwareInterface.ScanForPeripheralsWithServices(uuids, (address, name) => {
            if (string.IsNullOrEmpty(name) || name == "No Name") return;

            if (name.Contains(masterDeviceName) && string.IsNullOrEmpty(_masterAddress))
            {
                _masterAddress = address;
                Debug.Log($"Found MASTER at: {address}");
            }
            else if (name.Contains(slaveDeviceName) && string.IsNullOrEmpty(_slaveAddress))
            {
                _slaveAddress = address;
                Debug.Log($"Found SLAVE at: {address}");
            }

            if (!string.IsNullOrEmpty(_masterAddress) && !string.IsNullOrEmpty(_slaveAddress) && _isScanning)
            {
                _isScanning = false;
                BluetoothLEHardwareInterface.StopScan();
                StartCoroutine(ConnectToDevicesSequentially());
            }
        }, null, false, false);
    }

    IEnumerator ConnectToDevicesSequentially()
    {
        Debug.Log("Connecting to MASTER first...");
        ConnectToDevice(_masterAddress, true);

        float timeout = 10f;
        while (!_masterConnected && timeout > 0)
        {
            timeout -= Time.deltaTime;
            yield return null;
        }

        if (_masterConnected)
        {
            yield return new WaitForSeconds(2.0f);
            Debug.Log("Connecting to SLAVE...");
            ConnectToDevice(_slaveAddress, false);
        }
        else
        {
            _masterAddress = null; _slaveAddress = null;
            StartCoroutine(WaitAndStartScan());
        }
    }

    void ConnectToDevice(string address, bool isMaster)
    {
        string targetService = isMaster ? masterServiceUUID : slaveServiceUUID;
        string targetChar = isMaster ? masterCharUUID : slaveCharUUID;

        BluetoothLEHardwareInterface.ConnectToPeripheral(address, null, null, (addr, service, characteristic) => {
            if (characteristic.ToLower() == targetChar.ToLower())
            {
                if (isMaster) _masterConnected = true;
                else _slaveConnected = true;
                Debug.Log($"Handshake Complete: {(isMaster ? "MASTER" : "SLAVE")}");
            }
        }, (disconnectedAddress) => {
            if (isMaster) { _masterConnected = false; _masterAddress = null; }
            else { _slaveConnected = false; _slaveAddress = null; }
            if (!_isScanning) StartCoroutine(WaitAndStartScan());
        });
    }

    void Update()
    {
        HandleInput();

        if (isRecording)
        {
            timer += Time.deltaTime;
            if (timer >= (1f / hz))
            {
                RecordFrame();
                timer = 0;
            }
        }
    }

    private void HandleInput()
    {
        InputDevice rightDevice = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
        if (rightDevice.TryGetFeatureValue(CommonUsages.primaryButton, out bool isButtonAPressed))
        {
            if (isButtonAPressed && !wasButtonAPressed)
            {
                if (!BothConnected) Debug.LogWarning("Waiting for both ESP32s...");
                else
                {
                    if (!isRecording) StartRecording();
                    else StopRecording();
                }
            }
            wasButtonAPressed = isButtonAPressed;
        }
    }

    void StartRecording()
    {
        sessionData.Clear();
        isRecording = true;
        string fileID = DateTime.Now.ToString("HHmmss");
        currentSessionFileName = $"Robot_{DateTime.Now:yyyyMMdd_HHmmss}_Quest.csv";
        if (startAudioSource) startAudioSource.Play();

        string payload = $"START|{fileID}|{Time.time:F1}"; // [cite: 11, 78]
        SendBLEMessageToAll(payload);
    }

    void StopRecording()
    {
        isRecording = false;
        if (stopAudioSource) stopAudioSource.Play();
        string payload = $"STOP|{Time.time:F1}"; // [cite: 13, 80]
        SendBLEMessageToAll(payload);
        SaveDataToCSV(currentSessionFileName);
    }

    void SendBLEMessageToAll(string message)
    {
        byte[] data = Encoding.UTF8.GetBytes(message);
        if (_masterConnected) BluetoothLEHardwareInterface.WriteCharacteristic(_masterAddress, masterServiceUUID, masterCharUUID, data, data.Length, false, (uuid) => { });
        if (_slaveConnected) BluetoothLEHardwareInterface.WriteCharacteristic(_slaveAddress, slaveServiceUUID, slaveCharUUID, data, data.Length, false, (uuid) => { });
    }

    void RecordFrame()
    {
        RobotDataPoint point = new RobotDataPoint { time = Time.time };
        if (leftController)
        {
            point.lPos = robotBase ? robotBase.InverseTransformPoint(leftController.position) : leftController.position;
            point.lRot = GetRelativeRotation(leftController);
        }
        if (rightController)
        {
            point.rPos = robotBase ? robotBase.InverseTransformPoint(rightController.position) : rightController.position;
            point.rRot = GetRelativeRotation(rightController);
        }
        if (mainCamera)
        {
            point.hPos = robotBase ? robotBase.InverseTransformPoint(mainCamera.position) : mainCamera.position;
            point.hRot = GetRelativeRotation(mainCamera);
        }
        sessionData.Add(point);
    }

    Vector3 GetRelativeRotation(Transform target)
    {
        Vector3 rot = target.eulerAngles;
        return new Vector3(NormalizeAngle(rot.x), NormalizeAngle(rot.y), NormalizeAngle(rot.z));
    }

    float NormalizeAngle(float a) => (a > 180) ? a - 360 : a;

    void SaveDataToCSV(string fileName)
    {
        string filePath = Path.Combine(Application.persistentDataPath, fileName);
        using (StreamWriter writer = new StreamWriter(filePath))
        {
            writer.WriteLine("Time,L_PosX,L_PosY,L_PosZ,L_RotX,L_RotY,L_RotZ,R_PosX,R_PosY,R_PosZ,R_RotX,R_RotY,R_RotZ,H_PosX,H_PosY,H_PosZ,H_RotX,H_RotY,H_RotZ");
            foreach (var d in sessionData)
            {
                writer.WriteLine($"{d.time:F3},{d.lPos.x:F3},{d.lPos.y:F3},{d.lPos.z:F3},{d.lRot.x:F1},{d.lRot.y:F1},{d.lRot.z:F1}," +
                                 $"{d.rPos.x:F3},{d.rPos.y:F3},{d.rPos.z:F3},{d.rRot.x:F1},{d.rRot.y:F1},{d.rRot.z:F1}," +
                                 $"{d.hPos.x:F3},{d.hPos.y:F3},{d.hPos.z:F3},{d.hRot.x:F1},{d.hRot.y:F1},{d.hRot.z:F1}");
            }
        }
        Debug.Log($"Quest CSV Saved: {filePath}");
    }

    private void OnApplicationQuit()
    {
        BluetoothLEHardwareInterface.DeInitialize(() => { });
    }
}