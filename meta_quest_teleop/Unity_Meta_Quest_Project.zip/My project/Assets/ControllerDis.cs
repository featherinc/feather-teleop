using UnityEngine;
using UnityEngine.XR;
using System.Collections.Generic; // Required for Lists

public class ControllerDis : MonoBehaviour
{
    [System.Serializable]
    public struct RobotDataPoint
    {
        public float timestamp;
        public string hand;
        public Vector3 pos;
        public Vector3 rot;
    }

    [Header("Assign Transforms")]
    public Transform leftControllerTransform;
    public Transform rightControllerTransform;
    public Transform robotBase;

    [Header("Settings")]
    public float targetHz = 30f;
    private float timer = 0f;
    private bool isRunning = false;

    // The storage for our recorded data
    private List<RobotDataPoint> recordedData = new List<RobotDataPoint>();

    void Update()
    {
        InputDevice rightDevice = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);

        // A Button to START Recording
        if (rightDevice.TryGetFeatureValue(CommonUsages.primaryButton, out bool aPressed) && aPressed && !isRunning)
        {
            recordedData.Clear(); // Clear old data before starting new recording
            isRunning = true;
            Debug.Log("Recording Started...");
        }

        // B Button to STOP and SHOW data
        if (rightDevice.TryGetFeatureValue(CommonUsages.secondaryButton, out bool bPressed) && bPressed && isRunning)
        {
            isRunning = false;
            PrintRecordedData();
        }

        if (isRunning)
        {
            timer += Time.deltaTime;

            if (timer >= (1f / targetHz))
            {
                RecordHandData(leftControllerTransform, "LEFT");
                RecordHandData(rightControllerTransform, "RIGHT");
                timer -= (1f / targetHz);
            }
        }
    }

    void RecordHandData(Transform handTransform, string label)
    {
        if (handTransform == null) return;

        RobotDataPoint point = new RobotDataPoint();
        point.timestamp = Time.time;
        point.hand = label;
        point.pos = robotBase.InverseTransformPoint(handTransform.position);

        Vector3 rot = handTransform.localEulerAngles;
        point.rot = new Vector3(NormalizeAngle(rot.x), NormalizeAngle(rot.y), NormalizeAngle(rot.z));

        recordedData.Add(point);
    }

    void PrintRecordedData()
    {
        Debug.Log($"Recording Stopped. Total Points: {recordedData.Count}");

        foreach (var data in recordedData)
        {
            Debug.Log($"T:{data.timestamp:F2} | {data.hand} | P:{data.pos:F2} | R:{data.rot:F0}");
        }
    }

    float NormalizeAngle(float angle)
    {
        if (angle > 180) angle -= 360;
        return angle;
    }
}