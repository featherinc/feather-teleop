using System;
using System.Linq;
using UnityEditor;
using UnityEditor.Build.Reporting;

public static class QuestBaseBuild
{
    public static void Build()
    {
        var args = Environment.GetCommandLineArgs();
        int index = Array.IndexOf(args, "-questOutput");
        if (index < 0 || index + 1 >= args.Length) throw new Exception("Missing -questOutput");
        var scenes = EditorBuildSettings.scenes.Where(s => s.enabled).Select(s => s.path).ToArray();
        var report = BuildPipeline.BuildPlayer(new BuildPlayerOptions {
            scenes = scenes, locationPathName = args[index + 1],
            target = BuildTarget.Android, options = BuildOptions.None
        });
        if (report.summary.result != BuildResult.Succeeded)
            throw new Exception("Quest build failed: " + report.summary.result);
    }
}
