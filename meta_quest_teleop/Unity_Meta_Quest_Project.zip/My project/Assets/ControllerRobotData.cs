using UnityEngine;

public class ControllerRobotData : MonoBehaviour
{
    // Drag your "CenterEyeAnchor" or a specific "ControllerAnchor" here
    public Transform controllerTransform;
    public Transform robotBase;

    void Update()
    {
        // 1. POSITION & ROTATION (Same as before)
        Vector3 targetPos = robotBase.InverseTransformPoint(controllerTransform.position);
        Vector3 wristEuler = controllerTransform.localEulerAngles;

        float servoPitch = NormalizeAngle(wristEuler.x);
        float servoRoll = NormalizeAngle(wristEuler.z);
        float servoYaw = NormalizeAngle(wristEuler.y);


        // Print Data
        Debug.Log($"POS:{targetPos:F2} | ROT:{servoPitch:F0},{servoRoll:F0},{servoYaw:F0}");


    }

    float NormalizeAngle(float angle)
    {
        if (angle > 180) angle -= 360;
        return angle;
    }
}